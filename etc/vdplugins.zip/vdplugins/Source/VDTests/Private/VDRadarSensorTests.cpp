﻿#include "VDCommonHeader.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(VDRadarSensorTests, "VDPlugin.ModuleTests.VDRadarSensorTests",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool VDRadarSensorTests::RunTest(const FString& Parameters)
{
	// Make the test pass by returning true, or fail by returning false.
	return true;
}
