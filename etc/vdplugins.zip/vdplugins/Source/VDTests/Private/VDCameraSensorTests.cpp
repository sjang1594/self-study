﻿#include "VDCommonHeader.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(VDCameraSensorTests, "VDPlugin.ModuleTests.VDCameraSensorTests",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool VDCameraSensorTests::RunTest(const FString& Parameters)
{
	return true;
}
