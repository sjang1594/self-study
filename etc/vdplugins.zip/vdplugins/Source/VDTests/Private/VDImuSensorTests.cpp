﻿#include "VDCommonHeader.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(VDImuSensorTests, "VDPlugin.ModuleTests.VDImuSensorTests",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool VDImuSensorTests::RunTest(const FString& Parameters)
{
	// Make the test pass by returning true, or fail by returning false.
	return true;
}
