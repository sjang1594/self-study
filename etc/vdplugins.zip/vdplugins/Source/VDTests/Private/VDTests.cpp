﻿#include "VDTests.h"

#define LOCTEXT_NAMESPACE "FVDTestsModule"

void FVDTestsModule::StartupModule() {}

void FVDTestsModule::ShutdownModule() {}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FVDTestsModule, VDTests)
