﻿#include "VDCommonHeader.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(VDGnssSensorTests, "VDPlugin.ModuleTests.VDGnssSensorTests",
	EAutomationTestFlags::EditorContext | EAutomationTestFlags::EngineFilter)

bool VDGnssSensorTests::RunTest(const FString& Parameters)
{
	// Make the test pass by returning true, or fail by returning false.
	return true;
}
