﻿#include "VDCommonHeader.h"
#include "MORAISensorModule/Public/VDAltimeter/VDSensorAltimeter.h"
#include "MORAISensorModule/Public/VDCamera/VDSensorCamera.h"
#include "MORAISensorModule/Public/VDIMU/VDSensorIMU.h"
#include "MORAISensorModule/Public/VDGNSS/VDSensorGNSS.h"
#include "MORAISensorModule/Public/VDLiDAR/VDSensorLiDAR.h"
#include "MORAISensorModule/Public/VDRADAR/VDSensorRADAR.h"

template <typename sensorT>
ASensorActor<sensorT>::ASensorActor()
{
	PrimaryActorTick.bCanEverTick = true;
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
}

template <typename sensorT>
void ASensorActor<sensorT>::BeginPlay()
{
	AActor::BeginPlay();
}

template <typename sensorT>
void ASensorActor<sensorT>::Tick(float deltaTime)
{
	AActor::Tick(deltaTime);
}

template <typename sensorT>
void ASensorActor<sensorT>::Initialize()
{
	if (sensor != nullptr)
	{
		if (std::is_same_v<sensorT, VDSensorAltimeter>)
		{
			sensor->Initialize();
		}
		else if (std::is_same_v<sensorT, VDSensorCamera>)
		{
			sensor->Initialize();
		}
		else if (std::is_same_v<sensorT, VDSensorIMU>)
		{
			sensor->Initialize();
		}
		else if (std::is_same_v<sensorT, VDSensorGNSS>)
		{
			sensor->Initialize();
		}
		else if (std::is_same_v<sensorT, VDSensorLiDAR>)
		{
			sensor->Initialize();
		}
		else if (std::is_same_v<sensorT, VDSensorRADAR>)
		{
			sensor->Initialize();
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("This sensor is not supported."));
		}
	}
}

template <typename sensorT>
void ASensorActor<sensorT>::SetSensor(sensorT sensorType)
{
	sensor = sensorType;
}

template <typename sensorT>
void ASensorActor<sensorT>::SendData()
{
}

template <typename sensorT>
void ASensorActor<sensorT>::SetWorld(const UWorld* world)
{
}

template <typename sensorT>
void ASensorActor<sensorT>::SetRootComponent(const USceneComponent* root)
{
}

UWorld* GetTestWorld()
{
	const TIndirectArray<FWorldContext>& worldContexts = GEngine->GetWorldContexts();
	for (const FWorldContext& context : worldContexts)
	{
		if (((context.WorldType == EWorldType::PIE || context.WorldType == EWorldType::Game))
			&& (context.World() != nullptr))
		{
			return context.World();
		}
	}
	return nullptr;
}
