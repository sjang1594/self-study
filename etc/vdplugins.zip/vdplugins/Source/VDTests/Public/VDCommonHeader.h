﻿#pragma once

#include "CoreMinimal.h"

#include "Misc/AutomationTest.h"

/* To be able to simulate */
#include "Tests/AutomationCommon.h"
#include "Tests/AutomationEditorCommon.h"
#include "Kismet/GameplayStatics.h"
#include "Editor.h"

/* To be able to process inputs */
#include "GameFramework/PlayerInput.h"
#include "GameFramework/GameMode.h"
#include "GameFramework/Actor.h"

template <typename sensorT>
class VDTESTS_API ASensorActor : public AActor
{
public:
	ASensorActor();
	virtual void BeginPlay() override;
	virtual void Tick(float deltaTime) override;
	virtual void EndPlay(const EEndPlayReason::Type endPlayReason) override {};
	virtual void Release() {};

	void Initialize();
	void SendData();
	void SetSensor(sensorT sensorType);

	sensorT GetSensor() const { return sensor; }

	USceneComponent* GetRootComponent() const { return RootComponent; };

	FVector GetWorldLocation() const { return RootComponent->GetRelativeLocation(); }

	FRotator GetWorldRotator() const { return RootComponent->GetRelativeRotation(); }

	void SetWorldLocation(const FVector& location) const { RootComponent->SetRelativeLocation(location); }

	void SetWorldRotator(const FRotator& rotator) const { RootComponent->SetRelativeRotation(rotator); }

	void SetWorld(const UWorld* world);
	void SetRootComponent(const USceneComponent* root);

private:
	sensorT* sensor = nullptr;
};

class VDTESTS_API VDCommonHeader
{
public:
	VDCommonHeader() {}

	~VDCommonHeader() {}

	static UWorld* GetWorld();
};
