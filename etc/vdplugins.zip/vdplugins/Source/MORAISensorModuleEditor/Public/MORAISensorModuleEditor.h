﻿#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class FToolBarBuilder;
class FMenuBuilder;

class FMORAISensorModuleEditorModule : public IModuleInterface
{
public:
	static inline FMORAISensorModuleEditorModule& Get()
	{
		return FModuleManager::LoadModuleChecked<FMORAISensorModuleEditorModule>("MORAISensorModuleEditor");
	}

	static inline bool IsAvailable() { return FModuleManager::Get().IsModuleLoaded("MORAISensorModuleEditor"); }

	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	void PluginButtonClicked();

private:
	void RegisterMenus();
	TSharedRef<class SDockTab> OnSpawnPluginTab(const class FSpawnTabArgs& SpawnTabArgs);

	TSharedPtr<class FUICommandList> pluginCommands;
	TSharedPtr<class FSceneViewport> screenViewPort;
	TSharedPtr<class SViewport> viewPortWidget;
	TSharedPtr<class FMORAISensorModuleViewportClient> viewPortClient;
};
