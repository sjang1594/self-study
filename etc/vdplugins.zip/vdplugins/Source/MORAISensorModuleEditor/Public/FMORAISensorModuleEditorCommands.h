﻿#pragma once

#include "CoreMinimal.h"
#include "FMORAISensorModuleEditorStyle.h"

class FMORAISensorModuleEditorCommands : public TCommands<FMORAISensorModuleEditorCommands>
{
public:
	FMORAISensorModuleEditorCommands() :
	TCommands<FMORAISensorModuleEditorCommands>(TEXT("MORAISensorModuleEditor"),
		NSLOCTEXT("Contexts", "MORAISensorModuleEditor", "MORAISensorModuleEditor Plugin"), NAME_None,
		FMORAISensorModuleEditorStyle::GetStyleSetName())
	{
	}

	// TCommands<> interface
	virtual void RegisterCommands() override;

	TSharedPtr<FUICommandInfo> OpenPluginWindow;
};
