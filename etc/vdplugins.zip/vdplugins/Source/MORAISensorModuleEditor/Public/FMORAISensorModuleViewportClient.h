﻿#pragma once

#include "CoreMinimal.h"

class UTextureRenderTarget2D;

class MORAISENSORMODULEEDITOR_API FMORAISensorModuleViewportClient :
public FCommonViewportClient,
	public FViewElementDrawer
{
public:
	FMORAISensorModuleViewportClient(FEditorModeTools* inModeTools, FPreviewScene* previewScene = nullptr,
		const TWeakPtr<SEditorViewport>& inEditorViewPortWidget = nullptr);

	// FMORAISensorModuleViewportClient(const FEditorViewportClient&) = delete;
	// FMORAISensorModuleViewportClient& operator=(const FEditorViewportClient&) = delete;

	virtual void Draw(const FSceneView* View, FPrimitiveDrawInterface* PDI) override;
	virtual void Draw(FViewport* Viewport, FCanvas* Canvas) override;
	virtual void Tick(float deltaTime);

	FEditorModeTools* GetModeTools() const { return modeTools.Get(); }

	virtual FSceneInterface* GetScene() const;

	FViewport* viewPort;
	ELevelViewportType viewportType;

	// Viewport's current horizontal field of view (can be modified by locked cameras etc.)
	float viewFov;
	float aspectRatio;

	/** The Scene used for the view port */
	FPreviewScene* previewScene;

protected:
	TSharedPtr<FEditorModeTools> modeTools;

private:
	TObjectPtr<UTextureRenderTarget2D> renderTarget;
};
