﻿
#include "FMORAISensorModuleEditorCommands.h"

#define LOCTEXT_NAMESPACE "FMORAISensorModuleEditorModule"

void FMORAISensorModuleEditorCommands::RegisterCommands()
{
	UI_COMMAND(OpenPluginWindow, "VDSensor Module Visualizer", "Bring up VDSensor Module Visualizer window",
		EUserInterfaceActionType::Button, FInputChord());
}

#undef LOCTEXT_NAMESPACE
