﻿#include "../Public/FMORAISensorModuleViewportClient.h"
#include "CanvasItem.h"
#include "CanvasTypes.h"
#include "Engine/TextureRenderTarget2D.h"

// FMORAISensorModuleViewportClient::FMORAISensorModuleViewportClient()
// {
// 	renderTarget = NewObject<UTextureRenderTarget2D>(GetTransientPackage(), NAME_None, RF_Transient);
// 	renderTarget->RenderTargetFormat = RTF_RGBA8;
// 	renderTarget->InitAutoFormat(1024, 1024);
// 	renderTarget->ClearColor = FLinearColor::Blue;
// 	renderTarget->UpdateResource();
// }

FMORAISensorModuleViewportClient::FMORAISensorModuleViewportClient(FEditorModeTools* inModeTools,
	FPreviewScene* previewScene, const TWeakPtr<SEditorViewport>& inEditorViewPortWidget) :
viewPort(nullptr),
viewportType(LVT_Perspective),
viewFov(EditorViewportDefs::DefaultPerspectiveFOVAngle),
aspectRatio(1.777777f),
previewScene(previewScene)
{
	renderTarget = NewObject<UTextureRenderTarget2D>(GetTransientPackage(), NAME_None, RF_Transient);
	renderTarget->RenderTargetFormat = RTF_RGBA8;
	renderTarget->InitAutoFormat(1024, 1024);
	renderTarget->ClearColor = FLinearColor::Blue;
	renderTarget->UpdateResource();
}

void FMORAISensorModuleViewportClient::Draw(const FSceneView* viewPortIn, FPrimitiveDrawInterface* pdiIn)
{
	FViewElementDrawer::Draw(viewPortIn, pdiIn);
}

void FMORAISensorModuleViewportClient::Draw(FViewport* viewPortIn, FCanvas* canvasIn)
{
	FViewport* viewportBackup = viewPort;
	viewPort = viewPortIn ? viewPortIn : viewPort;

	UWorld* world = GetWorld();
	FGameTime time;
	if (!world || (GetScene() != world->Scene))
	{
		time = FGameTime::GetTimeSinceAppStart();
	}
	else
	{
		time = world->GetTime();
	}

	if (!renderTarget) return;
	// canvasIn->Clear(FLinearColor::Black);
	// FCanvasTileItem Tile(
	// 	FVector2D::ZeroVector, renderTarget->GetRenderTargetResource(), Viewport->GetSizeXY(), FLinearColor::White);
	// Canvas->DrawItem(Tile);
}

void FMORAISensorModuleViewportClient::Tick(float deltaTime) {}

FSceneInterface* FMORAISensorModuleViewportClient::GetScene() const
{
	UWorld* world = GetWorld();
	if (world)
	{
		return world->Scene;
	}

	return nullptr;
}