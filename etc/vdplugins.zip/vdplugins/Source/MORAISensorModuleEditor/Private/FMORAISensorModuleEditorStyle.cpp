﻿
#include "FMORAISensorModuleEditorStyle.h"
#include "Styling/SlateStyleRegistry.h"
#include "Framework/Application/SlateApplication.h"
#include "Interfaces/IPluginManager.h"
#include "Slate/SlateGameResources.h"
#include "Styling/SlateStyleMacros.h"

#define RootToContentDir Style->RootToContentDir
TSharedPtr<FSlateStyleSet> FMORAISensorModuleEditorStyle::styleInstance = nullptr;

void FMORAISensorModuleEditorStyle::Initialize()
{
	if (!styleInstance.IsValid())
	{
		styleInstance = Create();
		FSlateStyleRegistry::RegisterSlateStyle(*styleInstance);
	}
}

void FMORAISensorModuleEditorStyle::Shutdown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*styleInstance);
	ensure(styleInstance.IsUnique());
	styleInstance.Reset();
}

FName FMORAISensorModuleEditorStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("FMORAISensorModuleEditorStyle"));
	return StyleSetName;
}

const FVector2D Icon16x16(16.0f, 16.0f);
const FVector2D Icon20x20(20.0f, 20.0f);

TSharedRef<FSlateStyleSet> FMORAISensorModuleEditorStyle::Create()
{
	TSharedRef<FSlateStyleSet> Style = MakeShareable(new FSlateStyleSet("FMORAISensorModuleEditorStyle"));
	Style->SetContentRoot(IPluginManager::Get().FindPlugin("vdplugins")->GetBaseDir() / TEXT("Resources"));

	Style->Set("FMORAISensorModuleEditorStyle.OpenPluginWindow",
		new IMAGE_BRUSH_SVG(TEXT("PlaceholderButtonIcon"), Icon20x20));

	return Style;
}

// #define IMAGE_BRUSH( RelativePath, ... ) FSlateImageBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ),
// __VA_ARGS__ ) #define BOX_BRUSH( RelativePath, ... ) FSlateBoxBrush( Style->RootToContentDir( RelativePath,
// TEXT(".png") ), __VA_ARGS__ ) #define BORDER_BRUSH( RelativePath, ... ) FSlateBorderBrush( Style->RootToContentDir(
// RelativePath, TEXT(".png") ), __VA_ARGS__ ) #define TTF_FONT( RelativePath, ... ) FSlateFontInfo(
// Style->RootToContentDir( RelativePath, TEXT(".ttf") ), __VA_ARGS__ ) #define OTF_FONT( RelativePath, ... )
// FSlateFontInfo( Style->RootToContentDir( RelativePath, TEXT(".otf") ), __VA_ARGS__ )

void FMORAISensorModuleEditorStyle::ReloadTextures()
{
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().GetRenderer()->ReloadTextureResources();
	}
}
