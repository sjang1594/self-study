﻿#include "MORAISensorModuleEditor.h"

#include "FMORAISensorModuleEditorCommands.h"
#include "FMORAISensorModuleEditorStyle.h"
#include "FMORAISensorModuleViewportClient.h"
#include "LevelEditor.h"
#include "Widgets/SViewport.h"
#include "Slate/SceneViewport.h"
#include "FunctionalUIScreenshotTest.h"
#include "Widgets/Docking/SDockTab.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Text/STextBlock.h"
#include "ToolMenus.h"

#define LOCTEXT_NAMESPACE "FMORAISensorModuleEditorModule"

static const FName FMORAISensorModuleEditorModuleTabName("RenderTest");

void FMORAISensorModuleEditorModule::StartupModule()
{
	FMORAISensorModuleEditorStyle::Initialize();
	FMORAISensorModuleEditorStyle::ReloadTextures();
	FMORAISensorModuleEditorCommands::Register();

	pluginCommands = MakeShareable(new FUICommandList);

	pluginCommands->MapAction(FMORAISensorModuleEditorCommands::Get().OpenPluginWindow,
		FExecuteAction::CreateRaw(this, &FMORAISensorModuleEditorModule::PluginButtonClicked), FCanExecuteAction());

	UToolMenus::RegisterStartupCallback(
		FSimpleMulticastDelegate::FDelegate::CreateRaw(this, &FMORAISensorModuleEditorModule::RegisterMenus));

	FGlobalTabmanager::Get()
		->RegisterNomadTabSpawner(FMORAISensorModuleEditorModuleTabName,
			FOnSpawnTab::CreateRaw(this, &FMORAISensorModuleEditorModule::OnSpawnPluginTab))
		.SetDisplayName(LOCTEXT("FMORAISensorModuleEditorModuleTabTitle", "MORAI-SensorEditorModule"))
		.SetMenuType(ETabSpawnerMenuType::Hidden);
}

void FMORAISensorModuleEditorModule::ShutdownModule()
{
	UToolMenus::UnRegisterStartupCallback(this);
	UToolMenus::UnregisterOwner(this);
	FMORAISensorModuleEditorStyle::Shutdown();
	FMORAISensorModuleEditorCommands::Unregister();
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(FMORAISensorModuleEditorModuleTabName);
}

void FMORAISensorModuleEditorModule::PluginButtonClicked()
{
	FGlobalTabmanager::Get()->TryInvokeTab(FMORAISensorModuleEditorModuleTabName);
}

void FMORAISensorModuleEditorModule::RegisterMenus()
{
	// Owner will be used for cleanup in call to UToolMenus::UnregisterOwner
	FToolMenuOwnerScoped OwnerScoped(this);

	UToolMenu* menu = UToolMenus::Get()->ExtendMenu("LevelEditor.MainMenu.Window");
	{
		FToolMenuSection& Section = menu->FindOrAddSection("WindowLayout");
		Section.AddMenuEntryWithCommandList(FMORAISensorModuleEditorCommands::Get().OpenPluginWindow, pluginCommands);
	}

	UToolMenu* toolbarMenu = UToolMenus::Get()->ExtendMenu("LevelEditor.LevelEditorToolBar");
	{
		FToolMenuSection& section = toolbarMenu->FindOrAddSection("Settings");
		{
			FToolMenuEntry& Entry = section.AddEntry(
				FToolMenuEntry::InitToolBarButton(FMORAISensorModuleEditorCommands::Get().OpenPluginWindow));
			Entry.SetCommandList(pluginCommands);
		}
	}
}

TSharedRef<SDockTab> FMORAISensorModuleEditorModule::OnSpawnPluginTab(const FSpawnTabArgs& SpawnTabArgs)
{
	TSharedRef<SDockTab> Tab = SNew(SDockTab).TabRole(
		ETabRole::NomadTab)[SNew(SBox).HAlign(HAlign_Fill).VAlign(VAlign_Fill)[SAssignNew(viewPortWidget, SViewport)]];

	viewPortClient = MakeShareable(new FMORAISensorModuleViewportClient(nullptr));
	screenViewPort = MakeShareable(new FSceneViewport(viewPortClient.Get(), viewPortWidget));
	viewPortWidget->SetViewportInterface(screenViewPort.ToSharedRef());
	return Tab;
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FMORAISensorModuleEditorModule, MORAISensorModuleEditor)