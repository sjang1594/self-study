﻿using System.IO;
using UnrealBuildTool;

public class ShaderBasedSensor : ModuleRules
{
	public ShaderBasedSensor(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Projects",
				"Core",
				"CoreUObject",
				"Engine",
				"Renderer",
				"RenderCore",
				"RHI"
			}
		);

		string enginePath = Path.GetFullPath(Target.RelativeEnginePath);
		PublicIncludePaths.Add(enginePath + "Source/Runtime/Renderer/Private");

		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"Slate",
				"SlateCore"
			}
		);
	}
}