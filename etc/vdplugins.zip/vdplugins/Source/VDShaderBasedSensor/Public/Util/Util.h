﻿#pragma once

#include "CoreMinimal.h"
#include "ScreenPass.h"

inline FScreenPassTextureViewportParameters GetTextureViewportParameters(const FScreenPassTextureViewport& inViewPort)
{
	/* Populates the ViewParams struct with appropriate values. */
	const FVector2f extent(inViewPort.Extent);
	const FVector2f viewportMin(inViewPort.Rect.Min.X, inViewPort.Rect.Min.Y);
	const FVector2f viewportMax(inViewPort.Rect.Max.X, inViewPort.Rect.Max.Y);
	const FVector2f viewportSize = viewportMax - viewportMin;

	FScreenPassTextureViewportParameters parameters;

	if (!inViewPort.IsEmpty())
	{
		parameters.Extent = FVector2f(extent);
		parameters.ExtentInverse = FVector2f(1.0f / extent.X, 1.0f / extent.Y);

		parameters.ScreenPosToViewportScale = FVector2f(0.5f, -0.5f) * viewportSize;
		parameters.ScreenPosToViewportBias = (0.5f * viewportSize) + viewportMin;

		parameters.ViewportMin = inViewPort.Rect.Min;
		parameters.ViewportMax = inViewPort.Rect.Max;

		parameters.ViewportSize = viewportSize;
		parameters.ViewportSizeInverse = FVector2f(1.0f / parameters.ViewportSize.X, 1.0f / parameters.ViewportSize.Y);

		parameters.UVViewportMin = viewportMin * parameters.ExtentInverse;
		parameters.UVViewportMax = viewportMax * parameters.ExtentInverse;

		parameters.UVViewportSize = parameters.UVViewportMax - parameters.UVViewportMin;
		parameters.UVViewportSizeInverse =
			FVector2f(1.0f / parameters.UVViewportSize.X, 1.0f / parameters.UVViewportSize.Y);

		parameters.UVViewportBilinearMin = parameters.UVViewportMin + 0.5f * parameters.ExtentInverse;
		parameters.UVViewportBilinearMax = parameters.UVViewportMax - 0.5f * parameters.ExtentInverse;
	}

	return parameters;
}

