﻿#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class ShaderBasedSensorModule : public IModuleInterface
{
public:
	static inline ShaderBasedSensorModule& Get()
	{
		return FModuleManager::LoadModuleChecked<FShaderBasedSensorModule>("ShaderBasedSensor");
	}

	static inline bool IsAvailable() { return FModuleManager::Get().IsModuleLoaded("ShaderBasedSensor"); }

	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};
