﻿#pragma once

#include "CoreMinimal.h"
#include "FVDRadarSceneViewExtension.h"
#include "SceneViewExtension.h"
#include "ShaderParameterStruct.h"
#include "RenderGraphUtils.h"
#include "PostProcess/PostProcessing.h"
#include "GlobalShader.h"
#include "ShaderParameterUtils.h"
#include "RHIStaticStates.h"
#include "ScreenPass.h"
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 4
	#include "DataDrivenShaderPlatformInfo.h"
#endif


// 1024 is the max for CS_5_0
class UCameraComponent;
class SHADERBASEDSENSOR_API RadarSceneViewExtension : public ISceneViewExtension
{
public:
	// RadarSceneViewExtension(const FAutoRegister& AutoRegister);
	// RadarSceneViewExtension(const FAutoRegister&) {}
	// virtual ~RadarSceneViewExtension() {}
	virtual void SetupViewFamily(FSceneViewFamily& InViewFamily) override {}
	virtual void SetupView(FSceneViewFamily& InViewFamily, FSceneView& InView) override;
	virtual void BeginRenderViewFamily(FSceneViewFamily& InViewFamily) override {}
	virtual void PreRenderView_RenderThread(FRDGBuilder& GraphBuilder, FSceneView& InView) override {}
	virtual void PrePostProcessPass_RenderThread(
		FRDGBuilder& GraphBuilder, const FSceneView& View, const FPostProcessingInputs& Inputs) override;
	virtual void PostRenderBasePass_RenderThread(FRHICommandListImmediate& RHICmdList, FSceneView& InView) override {}
	// Hooks
	virtual void SubscribeToPostProcessingPass(
		EPostProcessingPass Pass, FAfterPassCallbackDelegateArray& InOutPassCallbacks, bool bIsPassEnabled) override;
	void PrepareRender(const TSoftObjectPtr<UCameraComponent>& cameraComponentIn, bool bInFollowSceneCaptureRenderPath);
	//FScreenPassTexture PostProcessRender(
	//	FRDGBuilder& graphBuilder, const FSceneView& sceneView, const FPostProcessMaterialInputs& inputs);

	void SetFrameDeltaTime(float inDeltaTime) { deltaTime = inDeltaTime; }
	
private:
	virtual bool IsActiveThisFrame_Internal(const FSceneViewExtensionContext& Context) const override;

	float deltaTime = 0.0f;
	bool bIsFirstFrame = true;
	bool bFollowSceneCaptureRenderPath = true;
	TSoftObjectPtr<UCameraComponent> cameraComponent = nullptr;

	/* Track Previous and Current Depth Render Target */
	TRefCountPtr<IPooledRenderTarget> previousDepthRenderTarget;
	TRefCountPtr<IPooledRenderTarget> currentDepthRenderTarget;
};

// Radar Shader Declaration
class SHADERBASEDSENSOR_API FRadarShaderCS : public FGlobalShader
{
public:
	DECLARE_GLOBAL_SHADER(FRadarShaderCS);
	SHADER_USE_PARAMETER_STRUCT(FRadarShaderCS, FGlobalShader);
	BEGIN_SHADER_PARAMETER_STRUCT(FParameters, )
	SHADER_PARAMETER_STRUCT_INCLUDE(FCommonShaderParameters, CommonShaderParameters)
	SHADER_PARAMETER_RDG_UNIFORM_BUFFER(FSceneTextureUniformParameters, SceneTextures) // For GBuffer Access
	
	SHADER_PARAMETER(int, width)
	SHADER_PARAMETER(int, height)
	SHADER_PARAMETER(float, chirpsNumber)
	SHADER_PARAMETER(float, samplesNumber)
	SHADER_PARAMETER(float, chirpRate)
	SHADER_PARAMETER(FVector3f, viewDir)
	SHADER_PARAMETER(float, radarFov)
	SHADER_PARAMETER(float, lowerChirpFrequency)
	SHADER_PARAMETER(float, bandwidthOfTheChirp)
	SHADER_PARAMETER(float, deltaSeconds)
	SHADER_PARAMETER(float, maxDistance)
	SHADER_PARAMETER(float, maxVelocity)
	SHADER_PARAMETER_RDG_TEXTURE(Texture2D, SceneColorTexture)
	SHADER_PARAMETER_RDG_TEXTURE(Texture2D, CurrentSceneDepthTexture)
	SHADER_PARAMETER_RDG_TEXTURE(Texture2D, PreviousSceneDepthTexture)
	SHADER_PARAMETER_SAMPLER(SamplerState, InputSampler)
	SHADER_PARAMETER_RDG_TEXTURE(Texture2D, RadiationTexture)

	// Viewport
	SHADER_PARAMETER(FIntRect, ViewportRect)
	SHADER_PARAMETER(FVector2f, ViewportInvSize)
	SHADER_PARAMETER(FVector2f, SceneColorUVScale)

	// RADAR OUTPUT DATA
	SHADER_PARAMETER_RDG_BUFFER_UAV(RWStructuredBuffer<float2>, RWRadarData1)
	SHADER_PARAMETER_RDG_BUFFER_UAV(RWStructuredBuffer<float2>, RWRadarData2)
	SHADER_PARAMETER_RDG_BUFFER_UAV(RWStructuredBuffer<float3>, DebugData)
	SHADER_PARAMETER_RDG_TEXTURE_UAV(RWTexture2D<float4>, Output)
	END_SHADER_PARAMETER_STRUCT()

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters& Parameters)
	{
		return IsFeatureLevelSupported(Parameters.Platform, ERHIFeatureLevel::SM5);
		// const FPermutationDomain PermutationVector(Parameters.PermutationId);
		// return true;
	}

	static void ModifyCompilationEnvironment(
		const FGlobalShaderPermutationParameters& Parameters, FShaderCompilerEnvironment& OutEnvironment)
	{
		FGlobalShader::ModifyCompilationEnvironment(Parameters, OutEnvironment);
		//const FPermutationDomain PermutationVector(Parameters.PermutationId);
		// OutEnvironment.SetDefine(TEXT("THREADGROUPSIZE_X"), GROUP_BORDER_SIZE);
		// OutEnvironment.SetDefine(TEXT("THREADGROUPSIZE_Y"), GROUP_BORDER_SIZE);
		// OutEnvironment.SetDefine(TEXT("THREADGROUPSIZE_Z"), THREADGROUPSIZE_Z);
	}

	static bool ShouldCache(EShaderPlatform platform)
	{
		return IsFeatureLevelSupported(platform, ERHIFeatureLevel::SM5);
	}
};
