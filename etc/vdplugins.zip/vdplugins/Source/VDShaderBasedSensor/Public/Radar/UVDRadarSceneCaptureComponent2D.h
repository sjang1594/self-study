﻿#pragma once

#include "CoreMinimal.h"
#include "Components/SceneCaptureComponent2D.h"
#include "UVDRadarSceneCaptureComponent2D.generated.h"

class UCameraComponent;
struct RadarShaderParam;
UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))

class SHADERBASEDSENSOR_API UUVDRadarSceneCaptureComponent2D : public USceneCaptureComponent2D
{
	GENERATED_BODY()

public:
	UUVDRadarSceneCaptureComponent2D(const FObjectInitializer& ObjectInitializer);

	/* ~Begin Interface */
	virtual void UpdateSceneCaptureContents(FSceneInterface* Scene) override;
	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void OnAttachmentChanged() override;
	virtual void TickComponent(
		float deltaTime, ELevelTick tickType, FActorComponentTickFunction* ThisTickFunction) override;
	/* ~End Interface */
	void SetRadarShaderParameters(RadarShaderParam* paramIn) { radarParam = paramIn; }
	
	UPROPERTY()
	TSoftObjectPtr<UCameraComponent> cameraComponent;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Capture Settings",
		meta = (ClampMin = "1", ClampMax = "8192", UIMin = "1", UIMax = "8192"))
	int32 renderTargetHighestDimension;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Capture Settings", AdvancedDisplay)
	bool bFollowSceneCaptureRenderPath;
	
protected:
	virtual void BeginPlay() override;

private:
	void ValidateCameraComponent();
	void CheckResizeRenderTarget() const;

	RadarShaderParam* radarParam = nullptr;
	TSoftObjectPtr<UTexture2D> radiationPattenMaskTexture = nullptr;
	TSharedPtr<class RadarSceneViewExtension, ESPMode::ThreadSafe> radarSceneViewExtension;
};