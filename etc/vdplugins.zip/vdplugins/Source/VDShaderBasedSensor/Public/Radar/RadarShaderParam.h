﻿#pragma once

#include "CoreMinimal.h"

struct RadarShaderParam
{
	// Shader Input Values
	float fovAngle = 0.0f;					// field-of-view of radar sensor
	int chirpsNumber = 1;					// number of chirps
	float bandWidth = 0.0f;						// bandwidth of the chirp	
	const int numOfReceiverAntennas = 4;	// number of receiver antennas
	int samplesNumber = 3;						// number of samples
	float lowerFrequency;					// lower frequency of the chirp	
	float samplingFrequency = 10000.0;
	int receiverConfig;
	float maxRange = 100.0f;
	float maxVelocity = 100.0f;

	UTexture2D* radiationPatternMaskTexture;
	
	bool operator!=(const RadarShaderParam& other) const
	{
		return *this != other;
	}

	bool operator==(const RadarShaderParam& other) const
	{
		return *this == other;
	}
};
