﻿#pragma once

#include "CoreMinimal.h"
#include "DataDrivenShaderPlatformInfo.h"
#include "SceneViewExtension.h"
#include "ScreenPass.h"
#include "GlobalShader.h"
#include "ShaderParameterUtils.h"
#include "RHIStaticStates.h"
#include "ShaderParameterStruct.h"

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 4
	#include "DataDrivenShaderPlatformInfo.h"
#endif

class UCameraComponent;
struct RadarShaderParam;
class SHADERBASEDSENSOR_API FVDRadarSceneViewExtension : public ISceneViewExtension
{
public:
	// Begin FVDRadarSceneViewExtensionBase interface
	virtual void SetupViewFamily(FSceneViewFamily& inViewFamily) override {}
	virtual void SetupView(FSceneViewFamily& inViewFamily, FSceneView& inView) override;
	virtual void BeginRenderViewFamily(FSceneViewFamily& inViewFamily) override {}
	virtual void PreRenderViewFamily_RenderThread(
		FRHICommandListImmediate& rhiCmdList, FSceneViewFamily& inViewFamily) override {};
	virtual void PreRenderView_RenderThread(FRHICommandListImmediate& rhiCmdList, FSceneView& inView) override {};
	virtual void PostRenderBasePass_RenderThread(FRHICommandListImmediate& rhiCmdList, FSceneView& inView) override {};
	virtual void PrePostProcessPass_RenderThread(
		FRDGBuilder& graphBuilder, const FSceneView& view, const FPostProcessingInputs& inputs) override;
	// End FVDRadarSceneViewExtensionBase interface

	// In case of post processing pass, we need to subscribe to the pass
	virtual void SubscribeToPostProcessingPass(
		EPostProcessingPass passID, FAfterPassCallbackDelegateArray& InOutPassCallbacks, bool bIsPassEnabled) override
	{
	}

	void SetFrameDeltaTime(float inDeltaTime) { deltaTime = inDeltaTime; }

	void PrepareRender(const TSoftObjectPtr<UCameraComponent>& cameraComponentIn, bool bInFollowSceneCaptureRenderPath);

	void SetRadarShaderParameters(RadarShaderParam* paramIn) { radarParam = paramIn; }

	void SetCameraPixelSize(const int& widthIn, const int& heightIn)
	{
		width = widthIn;
		height = heightIn;
	}

private:
	virtual bool IsActiveThisFrame_Internal(const FSceneViewExtensionContext& Context) const override;

	int width = 0;
	int height = 0;

	/* Delta time between frames */
	float deltaTime = 0.0f;
	
	/* A Transient Property that is used to deliver setting from Camera Components to view that re related to capture*/
	TSoftObjectPtr<UCameraComponent> cameraComponent = nullptr;

	/* Traslates to View.bIsSceneCapture */
	bool bFollowSceneCaptureRenderPath = true;

	/* Radar Param */
	RadarShaderParam* radarParam = nullptr;

	bool bIsFirstFrame = true;

	/* In order to avoid copying / swapping the rendertarget frequently */ 
	TRefCountPtr<IPooledRenderTarget> previousDepthRenderTarget;
	TRefCountPtr<IPooledRenderTarget> currentDepthRenderTarget;

	uint32 timeStamp = 0;
};

// Shader Declaration
BEGIN_SHADER_PARAMETER_STRUCT(FCommonShaderParameters, )
SHADER_PARAMETER_STRUCT_REF(FViewUniformShaderParameters, ViewUniformBuffer)
END_SHADER_PARAMETER_STRUCT()

// Util Shader Declaration
class SHADERBASEDSENSOR_API CopyDepthShader : public FGlobalShader
{
public:
	DECLARE_GLOBAL_SHADER(CopyDepthShader)
	SHADER_USE_PARAMETER_STRUCT(CopyDepthShader, FGlobalShader);
	BEGIN_SHADER_PARAMETER_STRUCT(FParameters, )
	SHADER_PARAMETER_STRUCT_INCLUDE(FCommonShaderParameters, CommonParameters)
	SHADER_PARAMETER_RDG_TEXTURE(Texture2D, CameraDepthTexture)
	SHADER_PARAMETER_STRUCT(FScreenPassTextureViewportParameters, ViewParams)
	SHADER_PARAMETER_RDG_UNIFORM_BUFFER(FSceneTextureUniformParameters, SceneTextures)
	RENDER_TARGET_BINDING_SLOTS()
	END_SHADER_PARAMETER_STRUCT()

	// Compile and Caching depending on the FGlobalShaderPermutationParameters.
	static bool ShouldCompilerPermutation(const FGlobalShaderPermutationParameters& parameters)
	{
		return IsFeatureLevelSupported(parameters.Platform, ERHIFeatureLevel::SM5);
	}

	// Compile Environment
	static void ModifyCompilationEnvironment(
		const FGlobalShaderPermutationParameters& Parameters, FShaderCompilerEnvironment& OutEnvironment)
	{
		FGlobalShader::ModifyCompilationEnvironment(Parameters, OutEnvironment);
		OutEnvironment.SetDefine(TEXT("ENTRY_POINT"), TEXT("MainPS"));
	}

	void SetParameters(FRHIBatchedShaderParameters& batchedParameters, const FSceneView* view)
	{
		FGlobalShader::SetParameters<FViewUniformShaderParameters>(batchedParameters, view->ViewUniformBuffer);
	}

	static bool ShouldCache(EShaderPlatform platform) { return true; }
};

// Radar Shader Declaration
class SHADERBASEDSENSOR_API FScreenSpaceRadarShader : public FGlobalShader
{
public:
	DECLARE_GLOBAL_SHADER(FScreenSpaceRadarShader)
	SHADER_USE_PARAMETER_STRUCT(FScreenSpaceRadarShader, FGlobalShader);
	BEGIN_SHADER_PARAMETER_STRUCT(FParameters, )
	SHADER_PARAMETER_STRUCT_INCLUDE(FCommonShaderParameters, CommonParameters)
	SHADER_PARAMETER_STRUCT(FScreenPassTextureViewportParameters, ViewParams)
	SHADER_PARAMETER_RDG_UNIFORM_BUFFER(FSceneTextureUniformParameters, SceneTextures)

	SHADER_PARAMETER_RDG_TEXTURE(Texture2D, SceneColorTexture)
	SHADER_PARAMETER_RDG_TEXTURE(Texture2D, CurrentSceneDepthTexture)
	SHADER_PARAMETER_RDG_TEXTURE(Texture2D, PreviousSceneDepthTexture)
	SHADER_PARAMETER_SAMPLER(SamplerState, InputSampler)
	SHADER_PARAMETER_RDG_TEXTURE(Texture2D, RadiationPatternMask)
	
	SHADER_PARAMETER(int, width)
	SHADER_PARAMETER(int, height)
	SHADER_PARAMETER(float, chirpsNumber)
	SHADER_PARAMETER(float, samplesNumber)
	SHADER_PARAMETER(int, nrAntennas)
	SHADER_PARAMETER(FVector3f, viewDir)
	SHADER_PARAMETER(float, fov)
	SHADER_PARAMETER(float, centerFrequency)
	SHADER_PARAMETER(float, lowerChirpFrequency)
	SHADER_PARAMETER(float, bandwidthOfTheChirp)
	SHADER_PARAMETER(float, deltaSeconds)
	SHADER_PARAMETER(float, maxDistance)
	SHADER_PARAMETER(float, maxVelocity)
	// Lerp Param
	SHADER_PARAMETER(float, lerpSpecular)
	SHADER_PARAMETER(float, lerpNormal)

	// TODO: Check the different between RWTexture2D
	SHADER_PARAMETER_RDG_BUFFER_UAV(RWStructuredBuffer<float2>, rwRadarData1)
	SHADER_PARAMETER_RDG_BUFFER_UAV(RWStructuredBuffer<float2>, rwRadarData2)

	RENDER_TARGET_BINDING_SLOTS()
	END_SHADER_PARAMETER_STRUCT()

	// Compile and Caching depending on the FGlobalShaderPermutationParameters.
	static bool ShouldCompilerPermutation(const FGlobalShaderPermutationParameters& parameters)
	{
		return IsFeatureLevelSupported(parameters.Platform, ERHIFeatureLevel::SM5);
	}

	// Compile Environment
	static void ModifyCompilationEnvironment(
		const FGlobalShaderPermutationParameters& Parameters, FShaderCompilerEnvironment& OutEnvironment)
	{
		FGlobalShader::ModifyCompilationEnvironment(Parameters, OutEnvironment);
		OutEnvironment.SetDefine(TEXT("ENTRY_POINT"), TEXT("MainPS"));
	}

	void SetParameters(FRHIBatchedShaderParameters& batchedParameters, const FSceneView* view)
	{
		FGlobalShader::SetParameters<FViewUniformShaderParameters>(batchedParameters, view->ViewUniformBuffer);
	}

	static bool ShouldCache(EShaderPlatform platform) { return true; }
};