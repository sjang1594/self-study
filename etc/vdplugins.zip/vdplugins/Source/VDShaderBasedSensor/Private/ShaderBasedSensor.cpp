﻿#include "ShaderBasedSensor.h"
#include "Interfaces/IPluginManager.h"

#define LOCTEXT_NAMESPACE "ShaderBasedSensorModule"

void ShaderBasedSensorModule::StartupModule()
{
	/* Load shaders from the plugin's into virtual directory */
	const FString pluginShaderDir =
		FPaths::Combine(IPluginManager::Get().FindPlugin(TEXT("vdplugins"))->GetBaseDir(), TEXT("Shaders/Private"));
	AddShaderSourceDirectoryMapping(TEXT("/Plugin/vdplugins"), pluginShaderDir);
}

void ShaderBasedSensorModule::ShutdownModule() {}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(ShaderBasedSensorModule, RadarShaderSensor)
