﻿#include "Radar/RadarSceneViewExtension.h"
#include "Camera/CameraComponent.h"

// Shader
#include "RenderTargetPool.h"
#include "ScreenPass.h"
#include "PostProcess/PostProcessMaterialInputs.h"
#include "Util/Util.h"

IMPLEMENT_GLOBAL_SHADER(FRadarShaderCS, "/Plugin/vdplugins/RadarShader.usf", "MainCS", SF_Compute);

void RadarSceneViewExtension::SetupView(FSceneViewFamily& InViewFamily, FSceneView& InView)
{
	if (!cameraComponent.IsValid()) return;
	// RadarParam
	FMinimalViewInfo desiredView;
	cameraComponent->GetCameraView(deltaTime, desiredView);
	const FTransform transform = cameraComponent->GetComponentToWorld();
	const FVector viewLocation = transform.GetTranslation();
	InView.StartFinalPostprocessSettings(viewLocation);
	InView.OverridePostProcessSettings(desiredView.PostProcessSettings, 0.0);
	const FSceneViewInitOptions ViewInitOptions;
	InView.EndFinalPostprocessSettings(ViewInitOptions);
	InView.bIsSceneCapture = bFollowSceneCaptureRenderPath;
}

void RadarSceneViewExtension::PrePostProcessPass_RenderThread(
	FRDGBuilder& graphBuilder, const FSceneView& View, const FPostProcessingInputs& Inputs)
{
	QUICK_SCOPE_CYCLE_COUNTER(STAT_ShaderPlugin_ComputeShader)			 // CPU Profile Stat
	SCOPED_DRAW_EVENT(graphBuilder.RHICmdList, ShaderPlugin_RenderRadar) // GPU Profile Stat
	checkSlow(sceneView.bIsViewInfo);
	Inputs.Validate();
	
	if (!cameraComponent.IsValid()) return;

	const FVector radarForwardVec = cameraComponent->GetForwardVector();
	// Print
	// UE_LOG(LogTemp, Warning, TEXT("Radar Forward Vector: %s"), *radarForwardVec.ToString());
	FIntRect viewport = FIntRect(FIntPoint(0, 0), FIntPoint(1024, 768));

	const FSceneViewFamily& viewFamily = *View.Family;
	const ERHIFeatureLevel::Type featureLevel = View.GetFeatureLevel();
	FScreenPassTexture sceneColor((*Inputs.SceneTextures)->SceneColorTexture);
	FScreenPassRenderTarget sceneColorCopyRenderTarget;
	sceneColorCopyRenderTarget.Texture =
		graphBuilder.CreateTexture(sceneColor.Texture->Desc, TEXT("Scene Color Texture"));

	FScreenPassTexture sceneDepth((*Inputs.SceneTextures)->SceneDepthTexture, viewport);
	const FGlobalShaderMap* globalShaderMap = GetGlobalShaderMap(viewFamily.GetFeatureLevel());
	check(globalShaderMap);

	RDG_EVENT_SCOPE(graphBuilder, "RADAR_SENSOR");
	const FScreenPassTextureViewport sceneDepthTextureViewport(sceneDepth);
	const FScreenPassTextureViewportParameters sceneDepthTextureViewportParams =
		GetTextureViewportParameters(sceneDepthTextureViewport);
	FSceneTextureShaderParameters scene = GetSceneTextureShaderParameters(View);
	if(!previousDepthRenderTarget.IsValid() && !currentDepthRenderTarget.IsValid())
	{
		FPooledRenderTargetDesc depthDesc =
			FPooledRenderTargetDesc::Create2DDesc(sceneDepth.Texture->Desc.Extent, sceneDepth.Texture->Desc.Format,
				FClearValueBinding::DepthNear, TexCreate_None, TexCreate_DepthStencilTargetable | TexCreate_ShaderResource, false);

		// FSceneRenderTargetItem depthRendserTargetItem;
		GRenderTargetPool.FindFreeElement(
			graphBuilder.RHICmdList, depthDesc, previousDepthRenderTarget, TEXT("Previous Depth"));
		GRenderTargetPool.FindFreeElement(
			graphBuilder.RHICmdList, depthDesc, currentDepthRenderTarget, TEXT("Current Depth"));
	}

	// Convert IPooledRenderTarget to FRHITexture
	FRDGTextureRef previousDepthRDGTexture = graphBuilder.RegisterExternalTexture(previousDepthRenderTarget);
	FRDGTextureRef currentDepthRDGTexture = graphBuilder.RegisterExternalTexture(currentDepthRenderTarget);

	if (!bIsFirstFrame)
	{
		// UE_LOG(LogTemp, Warning, TEXT("COPY CURRENT TO PREVIOUS"));
		AddCopyTexturePass(graphBuilder, currentDepthRDGTexture, previousDepthRDGTexture);
	}
	else
	{
		bIsFirstFrame = false;
	}

	AddCopyTexturePass(graphBuilder, sceneDepth.Texture, currentDepthRDGTexture);
	
	TShaderMapRef<FRadarShaderCS> ComputeShader(globalShaderMap);
	const bool bIsShaderValid = ComputeShader.IsValid();
	if (bIsShaderValid)
	{
		// ************************************ [DEBUG] ************************************ //
		FRDGTextureDesc OutputDesc;
		{
			OutputDesc = sceneColor.Texture->Desc;

			OutputDesc.Reset();
			OutputDesc.Flags |= TexCreate_UAV;
			OutputDesc.Flags &= ~(TexCreate_RenderTargetable | TexCreate_FastVRAM);

			FLinearColor ClearColor(0., 0., 0., 0.);
			OutputDesc.ClearValue = FClearValueBinding(ClearColor);
		}
		FRDGTextureRef OutputTexture = graphBuilder.CreateTexture(OutputDesc, TEXT("Custom Effect Output Texture"));
		// ********************************************************************************  //

		FRadarShaderCS::FParameters* passParameters = graphBuilder.AllocParameters<FRadarShaderCS::FParameters>();
		// Uniform Buffer
		FCommonShaderParameters CommonParameters;
		CommonParameters.ViewUniformBuffer = View.ViewUniformBuffer;
		passParameters->CommonShaderParameters = CommonParameters;

		// [DEBUG] OUTPUT TEXTURE // 
		passParameters->Output = graphBuilder.CreateUAV(FRDGTextureUAVDesc(OutputTexture));
		passParameters->SceneTextures = scene.SceneTextures;
		passParameters->SceneColorTexture = sceneColor.Texture;
		passParameters->CurrentSceneDepthTexture = currentDepthRDGTexture;
		passParameters->PreviousSceneDepthTexture = previousDepthRDGTexture;
		passParameters->InputSampler = TStaticSamplerState<SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();
		
		FIntRect PassViewSize = sceneColor.ViewRect;
		FIntPoint SrcTextureSize = sceneColor.Texture->Desc.Extent;
		passParameters->ViewportRect = PassViewSize;
		passParameters->ViewportInvSize = FVector2f(1.0f / PassViewSize.Width(), 1.0f / PassViewSize.Height());
		passParameters->SceneColorUVScale = FVector2f(SrcTextureSize.X / static_cast<float>(PassViewSize.Width()),
			SrcTextureSize.Y / static_cast<float>(PassViewSize.Height()));
		
		// For Radar Output Data
		// 1024(width) * 768(height) * 20(chirpNumber) * 300(sampleNumber)
		uint32 numElement = 1024  * 768 * 4 * 170;
		// Buffer Creation & Description
		FRDGBufferDesc outputDesc = FRDGBufferDesc::CreateStructuredDesc(
			2 * sizeof(float), numElement);

		// Debug Data
		FRDGBufferDesc debugDataDesc = FRDGBufferDesc::CreateStructuredDesc(
			sizeof(FVector3f), 10);
		FRDGBufferRef radarDataBuffer1 = graphBuilder.CreateBuffer(outputDesc, TEXT("Radar Data 1"));
		FRDGBufferRef radarDataBuffer2 = graphBuilder.CreateBuffer(outputDesc, TEXT("Radar Data 2"));
		FRDGBufferRef debugDataBuffer = graphBuilder.CreateBuffer(debugDataDesc, TEXT("Debug Data"));
		
		// Print DeltaSecond 
		// UE_LOG(LogTemp, Warning, TEXT("Delta Second: %f"), deltaTime);
		passParameters->width = 1024;
		passParameters->height = 768;
		passParameters->chirpsNumber = 20;
		passParameters->samplesNumber = 300;
		passParameters->viewDir = FVector3f(radarForwardVec);
		passParameters->chirpRate =  6.08e10 *  (300 / 1e9);
		passParameters->radarFov = 90.0f;
		passParameters->lowerChirpFrequency = 6.08e10;
		passParameters->bandwidthOfTheChirp = 4e08;
		passParameters->deltaSeconds = deltaTime;
		float ts = 300 / 1e9;
		float c0 = 299792458.0f;
		float centerFrequency = 6.08e10 + (4e08 * 0.5f);
		float lambda = c0 / centerFrequency;
		passParameters->maxDistance = c0 * 300 / (4.0f * 4e08);
		passParameters->maxVelocity = lambda / (4.0f * ts);
		passParameters->RWRadarData1 = graphBuilder.CreateUAV(radarDataBuffer1);
		passParameters->RWRadarData2 = graphBuilder.CreateUAV(radarDataBuffer2);
		passParameters->DebugData = graphBuilder.CreateUAV(debugDataBuffer);
		
		/* Set Compute Shader and Execute */
		const int32 kDefaultGroupSize = 8;
		FIntPoint GroupSize(kDefaultGroupSize, kDefaultGroupSize);
		FIntVector GroupCount = FComputeShaderUtils::GetGroupCount(PassViewSize.Size(), GroupSize);

		// Print PassViewSize
		UE_LOG(LogTemp, Warning, TEXT("PassViewSize: %s"), *PassViewSize.ToString());
		FComputeShaderUtils::AddPass(graphBuilder,
			RDG_EVENT_NAME("Custom SceneViewExtension Post Processing CS Shader %dx%d", PassViewSize.Width(),
				PassViewSize.Height()),
			ComputeShader, passParameters, GroupCount);

		AddCopyTexturePass(graphBuilder, OutputTexture, sceneColor.Texture);

		TResourceArray<FVector2D> cpuBuffer1;
		// TResourceArray<FVector2D> cpuBuffer2;

		// DO NOT INITIALIZE THE BUFFER
		// cpuBuffer1.SetNumZeroed(numElement); // This will make things slow.
		// cpuBuffer2.SetNumZeroed(numElement);
		// // Create the buffer for GPU -> CPU
		FRHIGPUBufferReadback* readBackResources1 = new FRHIGPUBufferReadback(TEXT("RadarDataReadBack1"));
		FRHIGPUBufferReadback* readBackResources2 = new FRHIGPUBufferReadback(TEXT("RadarDataReadBack2"));
		FRHIGPUBufferReadback* debugDataGPU = new FRHIGPUBufferReadback(TEXT("DebugDataGPU"));

		AddEnqueueCopyPass(graphBuilder, debugDataGPU, debugDataBuffer, 10);
		// AddEnqueueCopyPass(graphBuilder, readBackResources2, radarDataBuffer2, numElement);

		auto RunnerFunc = [debugDataGPU, this](auto && RunnerFunc) -> void {
			if(debugDataGPU->IsReady())
			{
				FVector3f* BufferData = static_cast<FVector3f*>(debugDataGPU->Lock(10 * sizeof(FVector3f)));
				UE_LOG(LogTemp, Warning, TEXT("Radar Data received from GPU"));
				UE_LOG(LogTemp, Warning, TEXT("First Radar Data: %s"), *BufferData[0].ToString());
				debugDataGPU->Unlock();
				AsyncTask(ENamedThreads::GameThread_Local, [BufferData]() {
					delete BufferData;
				});
				delete debugDataGPU;
			}
			else
			{
				AsyncTask(ENamedThreads::ActualRenderingThread, [RunnerFunc]()
				{
					RunnerFunc(RunnerFunc);
				});
			}
		};

		AsyncTask(ENamedThreads::ActualRenderingThread, [RunnerFunc]() {
			RunnerFunc(RunnerFunc);
		});
		
	}
	else
	{
		// ERROR
	}
	
}

void RadarSceneViewExtension::PrepareRender(
	const TSoftObjectPtr<UCameraComponent>& cameraComponentIn, bool bInFollowSceneCaptureRenderPath)
{
	cameraComponent = cameraComponentIn;
	bFollowSceneCaptureRenderPath = bInFollowSceneCaptureRenderPath;
}

bool RadarSceneViewExtension::IsActiveThisFrame_Internal(const FSceneViewExtensionContext& Context) const
{
	return ISceneViewExtension::IsActiveThisFrame_Internal(Context);
}

void RadarSceneViewExtension::SubscribeToPostProcessingPass(
	EPostProcessingPass PassID, FAfterPassCallbackDelegateArray& InOutPassCallbacks, bool bIsPassEnabled)
{
}