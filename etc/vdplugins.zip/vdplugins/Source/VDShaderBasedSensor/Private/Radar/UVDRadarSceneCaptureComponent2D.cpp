﻿#include "Radar/UVDRadarSceneCaptureComponent2D.h"
#include "Camera/CameraComponent.h"
#include "Radar/RadarShaderParam.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Radar/RadarSceneViewExtension.h"

UUVDRadarSceneCaptureComponent2D::UUVDRadarSceneCaptureComponent2D(const FObjectInitializer& ObjectInitializer) :
Super(ObjectInitializer),
renderTargetHighestDimension(1024),
bFollowSceneCaptureRenderPath(true)
{
	CaptureSource = ESceneCaptureSource::SCS_FinalColorLDR;
	bAlwaysPersistRenderingState = true;
	PrimaryComponentTick.bCanEverTick = true;
}

void UUVDRadarSceneCaptureComponent2D::UpdateSceneCaptureContents(FSceneInterface* Scene)
{
	// UpdateSceneCaptureContents (CaptureComponent Tick) (3)
	// UE_LOG(LogTemp, Warning, TEXT("EVENT: UpdateSceneCaptureContents"));
	if (!cameraComponent.IsValid() || !radarSceneViewExtension.IsValid()) return;
	if(!radarParam) return;
	SetRelativeTransform(FTransform::Identity);
	PostProcessSettings = cameraComponent->PostProcessSettings;
	FOVAngle = cameraComponent->FieldOfView;
	// bOverride_CustomNearClippingPlane = cameraComponent->bOverride_CustomNearClippingPlane;
	radarSceneViewExtension->PrepareRender(cameraComponent, bFollowSceneCaptureRenderPath);

	// TEMP
	CheckResizeRenderTarget();
	// radarSceneViewExtension->SetCameraPixelSize(this->TextureTarget->SizeX, this->TextureTarget->SizeY);
	// radarSceneViewExtension->SetRadarShaderParameters(radarParam);
	Scene->UpdateSceneCaptureContents(this);
}

void UUVDRadarSceneCaptureComponent2D::OnRegister()
{
	Super::OnRegister();

#if WITH_EDITORONLY_DATA
	ProxyMeshComponent->DestroyComponent();
	ProxyMeshComponent = nullptr;
#endif
	if (!radarSceneViewExtension.IsValid())
	{
		radarSceneViewExtension = MakeShared<RadarSceneViewExtension>();
		SceneViewExtensions.Add(radarSceneViewExtension);
	}
	ValidateCameraComponent();
}

void UUVDRadarSceneCaptureComponent2D::OnUnregister()
{
	Super::OnUnregister();

	if (radarSceneViewExtension.IsValid())
	{
		SceneViewExtensions.Remove(radarSceneViewExtension);
		radarSceneViewExtension.Reset();
	}
	
	cameraComponent = nullptr;
	delete radarParam;
	radarParam = nullptr;
}

void UUVDRadarSceneCaptureComponent2D::OnAttachmentChanged()
{
	if (USceneComponent* ParentComponent = GetAttachParent())
	{
		ValidateCameraComponent();
	}
}

void UUVDRadarSceneCaptureComponent2D::BeginPlay()
{
	Super::BeginPlay();
}

void UUVDRadarSceneCaptureComponent2D::TickComponent(
	float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	// UE_LOG(LogTemp, Warning, TEXT("EVENT: TickComponent"));
	// Run Every Frame in the first beginning (1)
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	if (radarSceneViewExtension.IsValid())
	{
		radarSceneViewExtension->SetFrameDeltaTime(DeltaTime);
	}

	if (cameraComponent.IsValid())
	{
		CheckResizeRenderTarget();
	}
}

void UUVDRadarSceneCaptureComponent2D::ValidateCameraComponent()
{
	if (!IsValid(this)) return;
	cameraComponent = Cast<UCameraComponent>(GetAttachParent());
	if (cameraComponent.IsValid())
	{
		// TODO: Log
	}
}

void UUVDRadarSceneCaptureComponent2D::CheckResizeRenderTarget() const
{
	if(TextureTarget)
	{
		float Ratio = TextureTarget->GetSurfaceWidth() / TextureTarget->GetSurfaceHeight();
		const float SmallNum = 1e-3;
		if ((FMath::Abs(Ratio - cameraComponent->AspectRatio) > SmallNum)
			|| (FMath::Max(TextureTarget->GetSurfaceWidth(), TextureTarget->GetSurfaceHeight()) != renderTargetHighestDimension))
		{
			if (cameraComponent->AspectRatio >= 1.)
			{
				int32 LowestDim = FMath::Max(renderTargetHighestDimension / cameraComponent->AspectRatio, 1);
				TextureTarget->ResizeTarget(renderTargetHighestDimension, LowestDim);
			}
			else
			{
				int32 LowestDim = FMath::Max(renderTargetHighestDimension * cameraComponent->AspectRatio, 1);
				TextureTarget->ResizeTarget(LowestDim, renderTargetHighestDimension);
			}
		}
	}
}