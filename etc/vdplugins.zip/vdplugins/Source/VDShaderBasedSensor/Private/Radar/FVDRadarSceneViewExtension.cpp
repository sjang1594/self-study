﻿#include "Radar/FVDRadarSceneViewExtension.h"
#include "PixelShaderUtils.h"
#include "SceneRendering.h"
#include "Camera/CameraComponent.h"
#include "PostProcess/PostProcessing.h"
#include "PipelineStateCache.h"
#include "SceneRenderTargetParameters.h"
#include "Radar/RadarShaderParam.h"
#include "RenderGraphUtils.h"
#include "RenderGraphBuilder.h"
#include "RenderTargetPool.h"
#include "Util/Util.h"

// IMPLEMENT_SHADER_TYPE(, CopyDepthShader, TEXT("/Plugin/vdplugins/CopyDepthShader.usf"), TEXT("CopyDepthPS"), SF_Pixel);

IMPLEMENT_SHADER_TYPE(
	, FScreenSpaceRadarShader, TEXT("/Plugin/vdplugins/FScreenSpaceRadarShader.usf"), TEXT("MainPS"), SF_Pixel);

// Called Every Frame
void FVDRadarSceneViewExtension::SetupView(FSceneViewFamily& inViewFamily, FSceneView& InView)
{
	if (!cameraComponent.IsValid()) return;
	if (!radarParam) return;
	FMinimalViewInfo DesiredView;
	cameraComponent->GetCameraView(deltaTime, DesiredView);
	const FTransform transform = cameraComponent->GetComponentToWorld();
	const FVector viewLocation = transform.GetTranslation();
	InView.StartFinalPostprocessSettings(viewLocation);
	InView.OverridePostProcessSettings(DesiredView.PostProcessSettings, 1.0);
	const FSceneViewInitOptions viewInitOptions;
	InView.EndFinalPostprocessSettings(viewInitOptions);
	InView.bIsSceneCapture = bFollowSceneCaptureRenderPath;
}

void FVDRadarSceneViewExtension::PrepareRender(
	const TSoftObjectPtr<UCameraComponent>& cameraComponentIn, bool bInFollowSceneCaptureRenderPath)
{
	// PrepareRender (SceneView Extension Tick) (4)
	// UE_LOG(LogTemp, Warning, TEXT("EVENT: PrepareRender"));
	cameraComponent = cameraComponentIn;
	bFollowSceneCaptureRenderPath = bInFollowSceneCaptureRenderPath;
}

/* Two ways to amke the this extension ineffective in the current frame.
 * 1. `IsActiveThisFrame_Internal` return the function false, then the extension will not be register in the view family
 *     in the current frame.
 * 2. The `IsActiveThisFrame_Internal` return the function true, but `SubscribeToPostProcessingPass` do not register any
 *     call back function, so that the extension will not take effect.*/
bool FVDRadarSceneViewExtension::IsActiveThisFrame_Internal(const FSceneViewExtensionContext& Context) const
{
	return ISceneViewExtension::IsActiveThisFrame_Internal(Context);
}

void FVDRadarSceneViewExtension::PrePostProcessPass_RenderThread(
	FRDGBuilder& graphBuilder, const FSceneView& view, const FPostProcessingInputs& inputs)
{
	// PrePostProcessPass_RenderThread (SceneView Extension Tick) (5)
	timeStamp++;

	// Print the delta time
	// UE_LOG(LogTemp, Warning, TEXT("FVDRadarSceneViewExtension::%u"), timeStamp);

	// UE_LOG(LogTemp, Warning, TEXT("FVDRadarSceneViewExtension::PrePostProcessPass_RenderThread"));
	QUICK_SCOPE_CYCLE_COUNTER(STAT_FRadarSceneViewExtension_PrePostProcessPass_RenderThread);
	checkSlow(View.bIsViewInfo);
	if (!radarParam) return;
	check(view.bIsViewInfo);
	inputs.Validate();

	// Get the sensor's view direction
	if (!cameraComponent.IsValid()) return;
	const FVector forwardVec = cameraComponent->GetForwardVector();
	const FIntRect viewport = static_cast<const FViewInfo&>(view).ViewRect;

	// can't do dynamic_cast because FViewInfo doesn't have any virtual functions.
	FScreenPassTexture sceneDepth((*inputs.SceneTextures)->SceneDepthTexture, viewport);
	FSceneTextureShaderParameters scene = GetSceneTextureShaderParameters(view);
	// FSceneTextureShaderParameters scene = CreateSceneTextureShaderParameters(
	// 	graphBuilder, view, ESceneTextureSetupMode::SceneColor | ESceneTextureSetupMode::GBuffers);
	
	const FGlobalShaderMap* globalShaderMap = GetGlobalShaderMap(GMaxRHIFeatureLevel);

	const FScreenPassTextureViewport sceneDepthTextureViewport(sceneDepth);
	const FScreenPassTextureViewportParameters sceneDepthTextureViewportParams =
		GetTextureViewportParameters(sceneDepthTextureViewport);

	check(globalShaderMap);
	RDG_EVENT_SCOPE(graphBuilder, "RADAR_SENSOR"); // Render Doc
	if (!previousDepthRenderTarget.IsValid() && !currentDepthRenderTarget.IsValid())
	{
		FPooledRenderTargetDesc depthDesc =
			FPooledRenderTargetDesc::Create2DDesc(sceneDepth.Texture->Desc.Extent, sceneDepth.Texture->Desc.Format,
				FClearValueBinding::White, TexCreate_None, TexCreate_DepthStencilTargetable, false);

		// FSceneRenderTargetItem depthRenderTargetItem;
		GRenderTargetPool.FindFreeElement(
			graphBuilder.RHICmdList, depthDesc, previousDepthRenderTarget, TEXT("Previous Depth"));
		GRenderTargetPool.FindFreeElement(
			graphBuilder.RHICmdList, depthDesc, currentDepthRenderTarget, TEXT("Current Depth"));
	}

	// Convert IPooledRenderTarget to FRHITexture
	FRDGTextureRef previousDepthRDGTexture = graphBuilder.RegisterExternalTexture(previousDepthRenderTarget);
	FRDGTextureRef currentDepthRDGTexture = graphBuilder.RegisterExternalTexture(currentDepthRenderTarget);

	if (!bIsFirstFrame)
	{
		UE_LOG(LogTemp, Warning, TEXT("COPY CURRENT TO PREVIOUS"));
		AddCopyTexturePass(graphBuilder, currentDepthRDGTexture, previousDepthRDGTexture);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("IsFirstFrame"));
		bIsFirstFrame = false;
	}

	AddCopyTexturePass(graphBuilder, sceneDepth.Texture, currentDepthRDGTexture);

	/* Calculate the Radar Data */
	FScreenPassTexture sceneColor((*inputs.SceneTextures)->SceneColorTexture, viewport);
	FScreenPassRenderTarget sceneColorCopyRenderTarget;
	sceneColorCopyRenderTarget.Texture = graphBuilder.CreateTexture(sceneColor.Texture->Desc, TEXT("Scene Color"));

	TShaderMapRef<FScreenSpaceRadarShader> FScreenSpaceRadarShader(globalShaderMap);
	FScreenSpaceRadarShader::FParameters* param = graphBuilder.AllocParameters<FScreenSpaceRadarShader::FParameters>();

	// Buffer Usage & Description
	FRDGBufferDesc outputDesc = FRDGBufferDesc::CreateStructuredDesc(
		2 * sizeof(float), width * height * radarParam->chirpsNumber * radarParam->samplesNumber);

	FRDGBufferRef radarDataBuffer1 = graphBuilder.CreateBuffer(outputDesc, TEXT("Radar Data 1"));
	FRDGBufferRef radarDataBuffer2 = graphBuilder.CreateBuffer(outputDesc, TEXT("Radar Data 2"));

	// Radiation Pattern Mask
	FRDGTexture* radiationPatternMaskTexture = RegisterExternalTexture(graphBuilder,
		radarParam->radiationPatternMaskTexture->GetResource()->GetTextureRHI(), TEXT("RadiationPatternMask"));

	FCommonShaderParameters commonShaderParameters;
	commonShaderParameters.ViewUniformBuffer = view.ViewUniformBuffer;
	param->CommonParameters = commonShaderParameters;
	param->SceneColorTexture = (*inputs.SceneTextures)->SceneColorTexture;
	param->SceneTextures = scene.SceneTextures;
	param->CurrentSceneDepthTexture = currentDepthRDGTexture;	// Current
	param->PreviousSceneDepthTexture = previousDepthRDGTexture; // Previous
	param->width = width;
	param->height = height;
	param->InputSampler = TStaticSamplerState<SF_Point, AM_Clamp, AM_Clamp, AM_Clamp>::GetRHI();
	param->ViewParams = sceneDepthTextureViewportParams;
	param->rwRadarData1 = graphBuilder.CreateUAV(radarDataBuffer1);
	param->rwRadarData2 = graphBuilder.CreateUAV(radarDataBuffer2);
	param->deltaSeconds = deltaTime;
	param->RadiationPatternMask = radiationPatternMaskTexture;
	param->RenderTargets[0] = FRenderTargetBinding(sceneColor.Texture, ERenderTargetLoadAction::ELoad);

	// Radar Parameters
	param->chirpsNumber = radarParam->chirpsNumber;
	param->samplesNumber = radarParam->samplesNumber;
	param->lowerChirpFrequency = radarParam->lowerFrequency;
	param->bandwidthOfTheChirp = radarParam->bandWidth;
	param->nrAntennas = radarParam->numOfReceiverAntennas;
	param->viewDir = FVector3f(forwardVec);
	param->maxDistance = radarParam->maxRange;
	param->maxVelocity = radarParam->maxVelocity;

	// Lerp Param (Specular and Normal)
	param->lerpSpecular = 1;
	param->lerpNormal = 1;

	FPixelShaderUtils::AddFullscreenPass(graphBuilder, globalShaderMap, FRDGEventName(TEXT("Calculate Radar Data")),
		FScreenSpaceRadarShader, param, viewport);

	FRHIGPUBufferReadback* readBackResources1 = new FRHIGPUBufferReadback(TEXT("RadarDataReadBack1"));
	FRHIGPUBufferReadback* readBackResources2 = new FRHIGPUBufferReadback(TEXT("RadarDataReadBack2"));
	// AddEnqueueCopyPass(graphBuilder, )
	//
	// auto RunnerFunc = [readBackResources1, this](auto && RunnerFunc) -> void {
	// 	if(readBackResources1->IsReady())
	// 	{
	// 		FVector3f* BufferData = static_cast<FVector3f*>(readBackResources1->Lock(10 * sizeof(FVector3f)));
	// 		UE_LOG(LogTemp, Warning, TEXT("Radar Data received from GPU"));
	// 		UE_LOG(LogTemp, Warning, TEXT("First Radar Data: %s"), *BufferData[0].ToString());
	// 		readBackResources1->Unlock();
	// 		AsyncTask(ENamedThreads::GameThread_Local, [BufferData]() {
	// 			delete BufferData;
	// 		});
	// 		delete readBackResources1;
	// 	}
	// 	else
	// 	{
	// 		AsyncTask(ENamedThreads::ActualRenderingThread, [RunnerFunc]()
	// 		{
	// 			RunnerFunc(RunnerFunc);
	// 		});
	// 	}
	// };
	//
	// AsyncTask(ENamedThreads::ActualRenderingThread, [RunnerFunc]() {
	// 	RunnerFunc(RunnerFunc);
	// });
}
