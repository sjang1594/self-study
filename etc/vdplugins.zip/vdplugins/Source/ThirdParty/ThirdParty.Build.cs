﻿using UnrealBuildTool;
using System.IO;

public class ThirdParty : ModuleRules
{
	private string ModulePath
	{
		get { return ModuleDirectory; }
	}

	public ThirdParty(ReadOnlyTargetRules Target) : base(Target)
	{
		// Tell Unreal that this Module only imports Third-Party-Assets
		Type = ModuleType.External;

		PublicIncludePaths.Add(Path.Combine(ModulePath, "eigen3"));
		PublicSystemIncludePaths.Add(Path.Combine(ModulePath, "geographiclib", "include"));

		// Link Lib
		string libPath = Path.Combine(ModulePath, "geographiclib", "lib");

		if (Target.Platform == UnrealTargetPlatform.Win64)
		{
			string win64LibPath = Path.Combine(libPath, "Win64");
			// Stage DLL along the binaries files
			string dllFullPath = Path.Combine(win64LibPath, "GeographicLib.dll");
			string libFullPath = Path.Combine(win64LibPath, "GeographicLib-i.lib");
			if (!File.Exists(dllFullPath))
			{
				string err = string.Format("GeographicLib.dll not found in {0}", win64LibPath);
				System.Console.WriteLine(err);
				throw new BuildException(err);
			}

			if (!File.Exists(libFullPath))
			{
				string err = string.Format("GeographicLib-i.lib not found in {0}", win64LibPath);
				System.Console.WriteLine(err);
				throw new BuildException(err);
			}

			string targetDir = "$(BinaryOutputDir)/";
			PublicAdditionalLibraries.Add(libFullPath);
			RuntimeDependencies.Add(targetDir + "GeographicLib.dll", dllFullPath);
		}
		else if (Target.Platform == UnrealTargetPlatform.Linux)
		{
			string linuxLibPath = Path.Combine(libPath, "Debian");
			// Stage DLL along the binaries files
			string dllFullPath = Path.Combine(linuxLibPath, "libGeographicLib.so.24.1.0");
			string libFullPath = Path.Combine(linuxLibPath, "libGeographicLib.a");
			if (!File.Exists(dllFullPath))
			{
				string err = string.Format("libGeographicLib.so not found in {0}", linuxLibPath);
				System.Console.WriteLine(err);
				throw new BuildException(err);
			}

			if (!File.Exists(libFullPath))
			{
				string err = string.Format("GeographicLib-i.lib not found in {0}", linuxLibPath);
				System.Console.WriteLine(err);
				throw new BuildException(err);
			}

			string targetDir = "$(BinaryOutputDir)/";
			PublicAdditionalLibraries.Add(libFullPath);
			RuntimeDependencies.Add(targetDir + "libGeographicLib.so", dllFullPath);
		}
		else
		{
			string err =
				string.Format("GeographicLib is not supported on your OS. Please put your dynamic library on {0}",
					libPath);
			System.Console.WriteLine(err);
			throw new BuildException(err);
		}
	}

	public string GetUProjectPath()
	{
		return Directory.GetParent(ModuleDirectory).Parent.ToString();
	}
}