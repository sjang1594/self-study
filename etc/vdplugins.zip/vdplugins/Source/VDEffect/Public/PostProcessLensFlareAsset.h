﻿#pragma once
#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "PostProcessLensFlareAsset.generated.h"

USTRUCT(BlueprintType)
struct FLensFlareGhostSettings
{
	GENERATED_BODY()
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "LensFlare")
	FLinearColor color = FLinearColor::White;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "LensFlare")
	float scale = 1.0f;
};


UCLASS()
class VDEFFECT_API UPostProcessLensFlareAsset : public UDataAsset
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, Category = "General", meta = (UIMin = "0.0", UIMax = "10.0"))
	float intensity = 1.0f;

	UPROPERTY(EditAnywhere, Category = "General")
	FLinearColor tint = FLinearColor(1.0f, 0.85f, 0.7f, 1.0f);

	UPROPERTY(EditAnywhere, Category = "General")
	UTexture2D* gradient = nullptr;

	UPROPERTY(EditAnywhere, Category = "Threshold", meta = (UIMin = "0.0", UIMax = "10.0"))
	float thresholdLevel = 1.0f;

	UPROPERTY(EditAnywhere, Category = "Threshold", meta = (UIMin = "0.01", UIMax = "10.0"))
	float thresholdRange = 1.0f;

	UPROPERTY(EditAnywhere, Category = "Ghosts", meta = (UIMin = "0.0", UIMax = "1.0"))
	float ghostIntensity = 1.0f;

	UPROPERTY(EditAnywhere, Category = "Ghosts", meta = (UIMin = "0.0", UIMax = "1.0"))
	float ghostChromaShift = 0.015f;

	UPROPERTY(EditAnywhere, Category = "Ghosts")
	FLensFlareGhostSettings ghost1 = { FLinearColor(1.0f, 0.8f, 0.4f, 1.0f), -1.5 };

	UPROPERTY(EditAnywhere, Category = "Ghosts")
	FLensFlareGhostSettings ghost2 = { FLinearColor(1.0f, 1.0f, 0.6f, 1.0f), 2.5 };

	UPROPERTY(EditAnywhere, Category = "Ghosts")
	FLensFlareGhostSettings ghost3 = { FLinearColor(0.8f, 0.8f, 1.0f, 1.0f), -5.0 };

	UPROPERTY(EditAnywhere, Category = "Ghosts")
	FLensFlareGhostSettings ghost4 = { FLinearColor(0.5f, 1.0f, 0.4f, 1.0f), 10.0 };

	UPROPERTY(EditAnywhere, Category = "Ghosts")
	FLensFlareGhostSettings ghost5 = { FLinearColor(0.5f, 0.8f, 1.0f, 1.0f), 0.7 };

	UPROPERTY(EditAnywhere, Category = "Ghosts")
	FLensFlareGhostSettings ghost6 = { FLinearColor(0.9f, 1.0f, 0.8f, 1.0f), -0.4 };

	UPROPERTY(EditAnywhere, Category = "Ghosts")
	FLensFlareGhostSettings ghost7 = { FLinearColor(1.0f, 0.8f, 0.4f, 1.0f), -0.2 };

	UPROPERTY(EditAnywhere, Category = "Ghosts")
	FLensFlareGhostSettings ghost8 = { FLinearColor(0.9f, 0.7f, 0.7f, 1.0f), -0.1 };

	UPROPERTY(EditAnywhere, Category = "Halo", meta = (UIMin = "0.0", UIMax = "1.0"))
	float haloIntensity = 1.0f;

	UPROPERTY(EditAnywhere, Category = "Halo", meta = (UIMin = "0.0", UIMax = "1.0"))
	float haloWidth = 0.6f;

	UPROPERTY(EditAnywhere, Category = "Halo", meta = (UIMin = "0.0", UIMax = "1.0"))
	float haloMask = 0.5f;

	UPROPERTY(EditAnywhere, Category = "Halo", meta = (UIMin = "0.0", UIMax = "1.0"))
	float haloCompression = 0.65f;

	UPROPERTY(EditAnywhere, Category = "Halo", meta = (UIMin = "0.0", UIMax = "1.0"))
	float haloChromaShift = 0.015f;

	UPROPERTY(EditAnywhere, Category = "Glare", meta = (UIMin = "0", UIMax = "10"))
	float glareIntensity = 0.02f;

	UPROPERTY(EditAnywhere, Category = "Glare", meta = (UIMin = "0.01", UIMax = "200"))
	float glareDivider = 60.0f;

	UPROPERTY(EditAnywhere, Category = "Glare", meta = (UIMin = "0.0", UIMax = "10.0"))
	FVector glareScale = FVector(1.0f, 1.0f, 1.0f);

	UPROPERTY(EditAnywhere, Category = "Glare")
	FLinearColor glareTint = FLinearColor(1.0f, 1.0f, 1.0f, 1.0f);

	UPROPERTY(EditAnywhere, Category = "Glare")
	UTexture2D* glareLineMask = nullptr;
};
