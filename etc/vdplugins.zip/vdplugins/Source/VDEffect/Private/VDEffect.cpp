﻿#include "VDEffect.h"

#define LOCTEXT_NAMESPACE "FVDEffectModule"

void FVDEffectModule::StartupModule()
{
    
}

void FVDEffectModule::ShutdownModule()
{
    
}

#undef LOCTEXT_NAMESPACE
    
IMPLEMENT_MODULE(FVDEffectModule, VDEffect)