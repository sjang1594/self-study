﻿#include "VDCoordinateConverter.h"
#include "common.h"
#include "EnuTransform.h"
#include "NedTransform.h"

#define LOCTEXT_NAMESPACE "FVDCoordinateConverter"

void FVDCoordinateConverter::StartupModule()
{
	UE_LOG(LogTemp, Display, TEXT("VD Coordinate Converter Loaded"));

	// TODO: How to avoid using the default constructor?
}

void FVDCoordinateConverter::ShutdownModule()
{
	UE_LOG(LogTemp, Display, TEXT("VD Coordinate Converter Shutted Down"));
}

#undef LOCTEXT_NAMESPACE
IMPLEMENT_MODULE(FVDCoordinateConverter, VDCoordinateConverter)
