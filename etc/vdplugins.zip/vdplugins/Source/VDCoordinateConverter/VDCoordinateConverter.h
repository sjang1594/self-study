﻿#pragma once
#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

class NedTransform;
class EnuTransform;

/*
	Note on coordinate system
	-------------------------
	UU or Unreal Units or Unreal Coordinate system
	Global ENU/NED: This is ENU/NED transformation of UU with origin set to 0,0,0
	Local ENU/NED: This is ENU/NED transformation of UU with origin set to vehicle's spawning UU location
	Vehicles are spawned at position specified in settings in global ENU/NED

	REMARKs: ENU / NED Follows the Right Hand Rule
	* ASL Coordinate Convent : x-forward, y-left, z-up

	Resource :
	* https://github.com/dpq/pysatel/blob/master/pysatel/coord.py#L37
	* https://microsoft.github.io/AirSim/
	*
	* Azimuth Elevation-Range Coordinate System
	* Earth Centered Earth & Fixed Coordinate System
	* Image Plane from Sensor.
*/

class FVDCoordinateConverter : public IModuleInterface
{
public:
	static inline FVDCoordinateConverter& Get()
	{
		return FModuleManager::LoadModuleChecked<FVDCoordinateConverter>("VDCoordinateConverter");
	}

	static inline FVDCoordinateConverter* GetPtr()
	{
		return FModuleManager::LoadModulePtr<FVDCoordinateConverter>("VDCoordinateConverter");
	}

	static inline bool IsAvailable() { return FModuleManager::Get().IsModuleLoaded("VDCoordinateConverter"); }

	// TODO MAP Everythiing for CoordSystemTransform.h
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};
