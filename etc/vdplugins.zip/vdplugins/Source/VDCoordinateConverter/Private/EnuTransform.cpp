﻿#include "EnuTransform.h"

EnuTransform::EnuTransform()
{
	world_to_meters_ = 0.0f;
	global_transform_ = FTransform::Identity;
	local_enu_offset_ = FVector::ZeroVector;
}

EnuTransform::EnuTransform(const FTransform& transform, float world_to_meters) :
EnuTransform(nullptr, transform, world_to_meters)
{
}

EnuTransform::EnuTransform(const AActor* pivot, const EnuTransform& transform) :
EnuTransform(pivot, transform.global_transform_, transform.world_to_meters_)
{
}

void EnuTransform::SetTransform(const FTransform& transform, float world_to_meters, const FVector& local_off_set)
{
	global_transform_ = transform;
	world_to_meters_ = world_to_meters;
	local_enu_offset_ = local_off_set;
}

EnuTransform::EnuTransform(const AActor* pivot, const FTransform& global_transform, float world_to_meters) :
global_transform_(global_transform),
world_to_meters_(world_to_meters)
{
	if (pivot != nullptr)
	{
		FVector mesh_origin, mesh_bounds;
		pivot->GetActorBounds(true, mesh_origin, mesh_bounds);
		const FVector ground_offset = FVector(0, 0, mesh_bounds.Z);
		local_enu_offset_ = pivot->GetActorLocation() - ground_offset;
	}
	else
		local_enu_offset_ = FVector::ZeroVector;
}

FVector EnuTransform::toFVector(const Vector3r& vec, float scale, bool convert_from_enu) const
{
	return FVector(vec.x() * scale, (convert_from_enu ? -vec.y() : vec.y()) * scale, vec.z() * scale);
}

EnuTransform::Vector3r EnuTransform::toVector3r(const FVector& vec, float scale, bool convert_to_enu) const
{
	return Vector3r(vec.X * scale, (convert_to_enu ? -vec.Y : vec.Y) * scale, vec.Z * scale);
}

// UU -> Local Enu
EnuTransform::Vector3r EnuTransform::toLocalEnu(const FVector& pos) const
{
	return toVector3r(pos - local_enu_offset_, 1 / world_to_meters_, true);
}

EnuTransform::Vector3r EnuTransform::toLocalEnuVelocity(const FVector& vel) const
{
	return toVector3r(vel, 1 / world_to_meters_, true);
}

EnuTransform::Vector3r EnuTransform::toGlobalEnu(const FVector& pos) const
{
	return toVector3r(pos - global_transform_.GetLocation(), 1 / world_to_meters_, true);
}

EnuTransform::Quaternionr EnuTransform::toEnu(const FQuat& q) const
{
	return Quaternionr(q.W, q.Y, q.X, q.Z);
}

float EnuTransform::toEnu(float length) const
{
	return length / world_to_meters_;
}

EnuTransform::Pose EnuTransform::toLocalEnu(const FTransform& pose) const
{
	return Pose(toLocalEnu(pose.GetLocation()), toEnu(pose.GetRotation()));
}

EnuTransform::Pose EnuTransform::toGlobalEnu(const FTransform& pose) const
{
	return Pose(toGlobalEnu(pose.GetLocation()), toEnu(pose.GetRotation()));
}

// Local Enu -> UU
FVector EnuTransform::fromLocalEnu(const Vector3r& pos) const
{
	return toFVector(pos, world_to_meters_, true) + local_enu_offset_;
}

FVector EnuTransform::fromGlobalEnu(const Vector3r& pos) const
{
	return toFVector(pos, world_to_meters_, true) + global_transform_.GetLocation();
}

FQuat EnuTransform::fromEnu(const Quaternionr& q) const
{
	return FQuat(q.y(), q.x(), q.z(), q.w());
}

float EnuTransform::fromEnu(float length) const
{
	return length * world_to_meters_;
}

FVector EnuTransform::fromRelativeEnu(const Vector3r& pos) const
{
	return toFVector(pos, world_to_meters_, true);
}

FTransform EnuTransform::fromRelativeEnu(const Pose& pose) const
{
	return FTransform(fromEnu(pose.orientation), fromRelativeEnu(pose.position));
}

FTransform EnuTransform::fromLocalEnu(const Pose& pose) const
{
	return FTransform(fromEnu(pose.orientation), fromLocalEnu(pose.position));
}

FTransform EnuTransform::fromGlobalEnu(const Pose& pose) const
{
	return FTransform(fromEnu(pose.orientation), fromGlobalEnu(pose.position));
}
