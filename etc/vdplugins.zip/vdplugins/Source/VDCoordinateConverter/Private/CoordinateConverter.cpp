﻿#include "CoordinateConverter.h"
#include "EnuTransform.h"
#include "NedTransform.h"
#include "common.h"

CoordinateConverter::CoordinateConverter() {}

CoordinateConverter::~CoordinateConverter() {}

bool CoordinateConverter::ConvertEnuToNed(EnuTransform* _enu, NedTransform* _ned)
{
	const FTransform global_transform = _enu->getGlobalTransform();
	const FVector converted_loc = ConvertPosEnutoNed(global_transform.GetLocation());
	const FQuat converted_rot = ConvertRotEnutoNed(global_transform.GetRotation());
	_ned->SetTransform(FTransform(converted_rot, converted_loc), _enu->getWorldToMeter(), _enu->getLocalOffset());
	return true;
}

FVector CoordinateConverter::ConvertPosEnutoNed(const FVector& enu_pos)
{
	return FVector(enu_pos.Y, enu_pos.X, -enu_pos.Z);
}

FQuat CoordinateConverter::ConvertRotEnutoNed(const FQuat& enu_rot)
{
	// Rotate around Z axis by 90 degrees
	const FQuat zRot(FVector(0, 0, 1), FMath::DegreesToRadians(90.0f));
	// Rotate around Y-axis by -90 degrees
	const FQuat yRot(FVector(0, 1, 0), FMath::DegreesToRadians(-90.0f));
	return yRot * zRot * enu_rot;
}

bool CoordinateConverter::ConvertNedToEnu(NedTransform* _ned, EnuTransform* _enu)
{
	const FTransform global_transform = _ned->getGlobalTransform();
	const FVector converted_loc = ConvertPosNedtoEnu(global_transform.GetLocation());
	const FQuat converted_rot = ConvertRotNedtoEnu(global_transform.GetRotation());
	_enu->SetTransform(FTransform(converted_rot, converted_loc), _ned->getWorldToMeter(), _ned->getLocalOffset());
	return true;
}

FVector CoordinateConverter::ConvertPosNedtoEnu(const FVector& ned_pos)
{
	return FVector(ned_pos.Y, ned_pos.X, -ned_pos.Z);
}

FQuat CoordinateConverter::ConvertRotNedtoEnu(const FQuat& ned_rot)
{
	const FQuat yRot(FVector(0, 1, 0), FMath::DegreesToRadians(90.0f));
	const FQuat zRot(FVector(0, 0, 1), FMath::DegreesToRadians(-90.0f));
	return zRot * yRot * ned_rot;
}
