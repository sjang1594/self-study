﻿#pragma once
#include "CoreMinimal.h"
#include "common.h"

class VDCOORDINATECONVERTER_API NedTransform
{
public:
	typedef common::Vector3r Vector3r;
	typedef common::Quaternionr Quaternionr;
	typedef common::Pose Pose;

public:
	NedTransform();
	NedTransform(const FTransform& transform, float world_to_meters);
	NedTransform(const AActor* pivot, const NedTransform& transform);

	virtual ~NedTransform() {}

	// Init
	void SetTransform(const FTransform& transform, float world_to_meters, const FVector& local_off_set);

	// UU -> Local NED
	Vector3r toLocalNed(const FVector& pos) const;
	Vector3r toLocalNedVelocity(const FVector& vel) const;
	Vector3r toGlobalNed(const FVector& pos) const;
	Quaternionr toNed(const FQuat& q) const;
	float toNed(float length) const;
	Pose toLocalNed(const FTransform& pose) const;
	Pose toGlobalNed(const FTransform& pose) const;

	// Local Ned -> UU
	FVector fromLocalNed(const Vector3r& pos) const;
	FVector fromGlobalNed(const Vector3r& pos) const;
	FQuat fromNed(const Quaternionr& q) const;
	float fromNed(float length) const;
	FVector fromRelativeNed(const Vector3r& pos) const;
	FTransform fromRelativeNed(const Pose& pose) const;
	FTransform fromLocalNed(const Pose& pose) const;
	FTransform fromGlobalNed(const Pose& pose) const;

	// TODO: is Unity coordinate system is needed or ROS coordinate system is needed?

	FVector getGlobalOffset() const { return global_transform_.GetLocation(); }

	FVector getLocalOffset() const { return local_ned_offset_; }

	FTransform getGlobalTransform() const { return global_transform_; }

	float getWorldToMeter() const { return world_to_meters_; }

private:
	NedTransform(const AActor* pivot, const FTransform& global_transform, float world_to_meters);
	FVector toFVector(const Vector3r& vec, float scale, bool convert_from_ned) const;
	Vector3r toVector3r(const FVector& vec, float scale, bool convert_to_ned) const;

private:
	FTransform global_transform_;
	float world_to_meters_;
	FVector local_ned_offset_;
};
