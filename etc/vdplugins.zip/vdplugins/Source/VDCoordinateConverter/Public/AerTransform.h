﻿#pragma once

#include "CoreMinimal.h"
#include "common.h"

/*
 * AerTransform can be either ENU / NED
 */

UENUM()
enum class ECoordinateType : uint8
{
	ENU,
	NED
};

class VDCOORDINATECONVERTER_API AerTransform
{
public:
	typedef common::Vector3r Vector3r;
	typedef common::Quaternionr Quaternionr;
	typedef const common::Pose Pose;

	AerTransform(const FTransform& transform, float world_to_meters);
	AerTransform(const AActor* pivot, const AerTransform& transform);

	// UU -> Local Aer
	Vector3r toLocalAer(const FVector& pos) const;
	Vector3r toLocalAerVelocity(const FVector& vel) const;
	Vector3r toGlobalAer(const FVector& pos) const;
	Quaternionr toAer(const FQuat& q) const;
	float toAer(float length) const;
	Pose toLocalAer(const FTransform& pose) const;
	Pose toGlobalAer(const FTransform& pose) const;

	// Local Aer -> uu
	FVector fromLocalAer(const Vector3r& pos) const;
	FVector fromGlobalAer(const Vector3r& pos) const;
	FQuat fromAer(const Quaternionr& q) const;
	float fromAer(float length) const;
	FVector fromRelativeAer(const Vector3r& pos) const;
	FTransform fromRelativeAer(const Pose& pose) const;
	FTransform fromLocalAer(const Pose& pose) const;
	FTransform fromGlobalAer(const Pose& pose) const;

	FVector getGlobalOffset() const { return global_transform_.GetLocation(); }

	FVector getLocalOffset() const { return local_Aer_offset_; }

	FTransform getGlobalTransform() const { return global_transform_; }

private:
	AerTransform(const AActor* pivot, const FTransform& global_transform, float world_to_meters);
	FVector toFVector(const Vector3r& vec, float scale, bool convert_from_Aer) const;
	Vector3r toVector3r(const FVector& vec, float scale, bool convert_to_Aer) const;

private:
	FTransform global_transform_;
	float world_to_meters_;
	FVector local_Aer_offset_;
};
