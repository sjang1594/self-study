﻿#pragma once

#include <string>
#include <memory>
#include <vector>
#include <unordered_map>
#include <unordered_set>

#include <iostream>
#include "vectorMath.h"

namespace common
{
	using VectorMath = vdVectorMath::VectorMathf;
	// VectorMath
	using VectorMath = vdVectorMath::VectorMathf;
	using Vector3r = VectorMath::Vector3f;
	using Vector2r = VectorMath::Vector2f;
	using Vector1r = VectorMath::Vector1f;
	using Array3r = VectorMath::Array3f;

	using Pose = VectorMath::Pose;
	using Quaternionr = VectorMath::Quaternionf;
	using Matrix3x3r = VectorMath::Matrix3x3f;
	//	using Matrix4x4r = VectorMath::Matrix4x4f;
	using AngleAxisr = VectorMath::AngleAxisf;

	// Standard Lib
	using string = std::string;

	template <typename T>
	using Vector = std::vector<T>;

	template <typename TKey, typename TValue>
	using Unordered_map = std::unordered_map<TKey, TValue>;

	template <typename TKey>
	using Unordered_set = std::unordered_set<TKey>;

	template <typename T>
	using unique_ptr = std::unique_ptr<T>;

	template <typename T>
	using shared_ptr = std::shared_ptr<T>;

	template <typename T>
	using vector_size_type = typename std::vector<T>::size_type;

	// util inline functions
	inline std::ostream& operator<<(std::ostream& os, Quaternionr const& q)
	{
		float pitch, roll, yaw;
		VectorMath::toEulerAngle(q, pitch, roll, yaw);
		return os << "(" << pitch << ", " << roll << ", " << yaw << ")" << q.w() << q.x() << "\t" << q.y() << "\t"
				  << q.z() << "\t";
	}

	inline std::ostream& operator<<(std::ostream& os, Vector3r const& v)
	{
		return os << v.x() << "\t" << v.y() << "\t" << v.z() << "\t";
	}
} // namespace common
