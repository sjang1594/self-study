﻿#pragma once

#include "CoreMinimal.h"
#include "common.h"

class VDCOORDINATECONVERTER_API EnuTransform
{
public:
	typedef common::Vector3r Vector3r;
	typedef common::Quaternionr Quaternionr;
	typedef common::Pose Pose;

public:
	EnuTransform();
	EnuTransform(const FTransform& transform, float world_to_meters);
	EnuTransform(const AActor* pivot, const EnuTransform& transform);

	virtual ~EnuTransform() {}

	// Init
	void SetTransform(const FTransform& transform, float world_to_meters, const FVector& local_off_set);

	// UU -> Local Enu
	Vector3r toLocalEnu(const FVector& pos) const;
	Vector3r toLocalEnuVelocity(const FVector& vel) const;
	Vector3r toGlobalEnu(const FVector& pos) const;
	Quaternionr toEnu(const FQuat& q) const;
	float toEnu(float length) const;
	Pose toLocalEnu(const FTransform& pose) const;
	Pose toGlobalEnu(const FTransform& pose) const;

	// Local Enu -> UU
	FVector fromLocalEnu(const Vector3r& pos) const;
	FVector fromGlobalEnu(const Vector3r& pos) const;
	FQuat fromEnu(const Quaternionr& q) const;
	float fromEnu(float length) const;
	FVector fromRelativeEnu(const Vector3r& pos) const;
	FTransform fromRelativeEnu(const Pose& pose) const;
	FTransform fromLocalEnu(const Pose& pose) const;
	FTransform fromGlobalEnu(const Pose& pose) const;

	FVector getGlobalOffset() const { return global_transform_.GetLocation(); }

	FVector getLocalOffset() const { return local_enu_offset_; }

	FTransform getGlobalTransform() const { return global_transform_; }

	float getWorldToMeter() const { return world_to_meters_; }

private:
	EnuTransform(const AActor* pivot, const FTransform& global_transform, float world_to_meters);
	FVector toFVector(const Vector3r& vec, float scale, bool convert_from_enu) const;
	Vector3r toVector3r(const FVector& vec, float scale, bool convert_to_enu) const;

private:
	FTransform global_transform_;
	float world_to_meters_;
	FVector local_enu_offset_;
};
