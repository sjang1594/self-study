﻿#pragma once

#include "CoreMinimal.h"

class VDCOORDINATECONVERTER_API CylindricalTransform
{
public:
	CylindricalTransform();
	~CylindricalTransform();
};
