﻿#pragma once

#include "CoreMinimal.h"

class EnuTransform;
class NedTransform;

class VDCOORDINATECONVERTER_API CoordinateConverter
{
public:
	CoordinateConverter();
	~CoordinateConverter();

	static bool ConvertEnuToNed(EnuTransform* enu, NedTransform* ned);
	static FVector ConvertPosEnutoNed(const FVector& enu_pos);
	static FQuat ConvertRotEnutoNed(const FQuat& enu_rot);

	static bool ConvertNedToEnu(NedTransform* ned, EnuTransform* enu);
	static FVector ConvertPosNedtoEnu(const FVector& ned_pos);
	static FQuat ConvertRotNedtoEnu(const FQuat& ned_rot);
};
