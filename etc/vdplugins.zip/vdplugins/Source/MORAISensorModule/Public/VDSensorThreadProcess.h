﻿#pragma once

#include "VDSensorThreadBase.h"

class VDSensorBase;

class MORAISENSORMODULE_API VDSensorThreadProcess : public VDSensorThreadBase
{
public:
	VDSensorThreadProcess(const FTimespan& threadSleepTimeIn, const TCHAR* threadNameIn, VDSensorBase* vdSensorIn);

	virtual ~VDSensorThreadProcess() override;

	virtual void Process() override;

	bool SensorWorkerThreadInit();
	void SensorThreadShutdown();

protected:
	VDSensorBase* vdSensor = nullptr;
};
