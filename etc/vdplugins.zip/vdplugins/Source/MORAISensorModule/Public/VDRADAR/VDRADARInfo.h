#pragma once

#include <cstdint>

#include "VDGNSS/VDEllipsoidModel.h"
#include "VDGNSS/VDGNSSConverter.h"

// TODO: macro to constexpr
#define METERTOFEET 3.28084
#define FEETTOMETER 0.3048
#define CMTOMETER 0.01
#define METERTOCM 100
#define NMITOMETER 1852
#define METERTONMI 0.000539957
#define TOMETER 0.01
#define MPSTOKNOT 1.943845249221964 // meter per seconds to knot
#define KNOTTOCMPS 51.4444
#define KNOTTOMPS 0.514444

#define DEGTORAD PI / 180

#define NUMATAR 64
#define NUMEOIR 64
#define NUMGROUNDRADAR 64
#define NUMADSB 64

#define CLASSIFICATION_NONE 0
#define CLASSIFICATION_MANNED 1
#define CLASSIFICATION_UNMANNED 2
#define CLASSIFICATION_SMALL_UNMANNED 3
#define CLASSIFICATION_POINT_OBSTACLE 100
#define CLASSIFICATION_GROUND 101

#pragma pack(push, 1)

struct OwnShipInfo
{
	int Address;
	float heading_true_rad; // # clockwise from north #example data, update with your own data links
	bool heading_degraded; // # If false, it indicates that input is valid true heading(진북).If true, it indicates that
	// input is track angle.
	float alt_pres_ft;		// # ownship Pressure Altitude
	float lat_deg;			// # Ownship latitude
	float lon_deg;			// # Ownship longitude
	float vel_ew_kts;		// # Ownship velocity in east - west direction, true east is positive
	float vel_ns_kts;		// # Ownship velocity in north - south direction, true north is positive
	float alt_hae_ft;		// # Ownship geodetic height - above - ellipsoid(HAE) altitude
	float alt_rate_hae_fps; // # Ownship geodetic height - above - ellipsoid(HAE) altitude rate
	uint8_t nacp;			// # Ownship Navigation Accuracy Category for Position(NACp) (0 - 11)
	uint8_t nacv;			// # Ownship Navigation Accuracy Category for Velocity(NACv) (0 - 4)
	float vfom_m;			// # Ownship Vertical Figure of Merit(VFOM) - vertical position uncertainty
	float alt_agl_ft;		// # Ownship height above - ground - level(AGL) altitude
};

struct IntruderDetectionInfo
{
	int Address;
	float heading_true_rad; // # clockwise from north #example data, update with your own data links
	bool heading_degraded; // # If false, it indicates that input is valid true heading(진북).If true, it indicates that
	// input is track angle.
	float alt_pres_ft;		// # ownship Pressure Altitude
	float lat_deg;			// # Ownship latitude
	float lon_deg;			// # Ownship longitude
	float vel_ew_kts;		// # Ownship velocity in east - west direction, true east is positive
	float vel_ns_kts;		// # Ownship velocity in north - south direction, true north is positive
	float alt_hae_ft;		// # Ownship geodetic height - above - ellipsoid(HAE) altitude
	float alt_rate_hae_fps; // # Ownship geodetic height - above - ellipsoid(HAE) altitude rate
	uint8_t nacp;			// # Ownship Navigation Accuracy Category for Position(NACp) (0 - 11)
	uint8_t nacv;			// # Ownship Navigation Accuracy Category for Velocity(NACv) (0 - 4)
	float vfom_m;			// # Ownship Vertical Figure of Merit(VFOM) - vertical position uncertainty
	float alt_agl_ft;		// # Ownship height above - ground - level(AGL) altitude
	uint8_t UniqueID;
};

struct IntruderDetectionPacket
{
	IntruderDetectionInfo IntruderDetectionInfo[64];
};

struct ATARInfo
{
	uint8_t trackId;		// # TrackID
	uint8_t track_status;	// # Status of incoming track report
	uint8_t classification; // # Intruder Classification Types
	// # global const CLASSIFICATION_NONE = UInt8(0)
	// # global const CLASSIFICATION_MANNED = UInt8(1)
	// # global const CLASSIFICATION_UNMANNED = UInt8(2)
	// # global const CLASSIFICATION_SMALL_UNMANNED = UInt8(3)
	// # global const CLASSIFICATION_POINT_OBSTACLE = UInt8(100)
	// # global const CLASSIFICATION_GROUND = UInt8(101)

	float range_ft;	   // # eIntruder horizontal range
	float azimuth_rad; // # Frame rotation angle from North(True North is 0, True East is π / 2)
	float dgr_fps;	   // # Intruder horizontal range rate(diverging is positive)
	float dxgr_fps; // # Intruder cross horizontal range rate(perpendicular to dgr_fps, positive for clockwise movement
	// of intruder relative to ownship)
	float rel_z_ft;	  // # Intruder relative altitude(intruder above is positive)
	float rel_dz_fps; // # Intruder relative altitude rate(intruder above is positive)

	// If EO / IR and Radar sensor are used together, the data should be fused to update the tracking information via
	// the function 'ReceiveOwnRelNonCoopTrack' in ACAS Xr. The list of information should be available from both EO /
	// IR and Radar in Simulator.
};

struct ATARPacket
{
	ATARInfo ATARInfo[NUMATAR];
};

struct EOIRInfo
{
	uint8_t trackId;		// # TrackID
	uint8_t track_status;	// # Status of incoming track report
	uint8_t classification; // # Intruder Classification Types
	// # global const CLASSIFICATION_NONE = UInt8(0)
	// # global const CLASSIFICATION_MANNED = UInt8(1)
	// # global const CLASSIFICATION_UNMANNED = UInt8(2)
	// # global const CLASSIFICATION_SMALL_UNMANNED = UInt8(3)
	// # global const CLASSIFICATION_POINT_OBSTACLE = UInt8(100)
	// # global const CLASSIFICATION_GROUND = UInt8(101)

	float range_ft;	   // # eIntruder horizontal range
	float azimuth_rad; // # Frame rotation angle from North(True North is 0, True East is π / 2)
	float dgr_fps;	   // # Intruder horizontal range rate(diverging is positive)
	float dxgr_fps; // # Intruder cross horizontal range rate(perpendicular to dgr_fps, positive for clockwise movement
					// of intruder relative to ownship)
	float rel_z_ft;	  // # Intruder relative altitude(intruder above is positive)
	float rel_dz_fps; // # Intruder relative altitude rate(intruder above is positive)

	// If EO / IR and Radar sensor are used together, the data should be fused to update the tracking information via
	// the function 'ReceiveOwnRelNonCoopTrack' in ACAS Xr. The list of information should be available from both EO /
	// IR and Radar in Simulator.
};

struct EOIRPacket
{
	EOIRInfo EOIRInfo[NUMEOIR];
};

struct GroundRADARInfo
{
	uint8_t track_id;
	uint8_t track_status;		  // # Status of incoming track report
	uint8_t externally_validated; // # Indication that the surveillance source of the intruder is externally validated
	uint8_t classification;		  // # Intruder Classification Types
								  // # global const CLASSIFICATION_NONE = UInt8(0)
								  // # global const CLASSIFICATION_MANNED = UInt8(1)
								  // # global const CLASSIFICATION_UNMANNED = UInt8(2)
								  // # global const CLASSIFICATION_SMALL_UNMANNED = UInt8(3)
								  // # global const CLASSIFICATION_POINT_OBSTACLE = UInt8(100)
								  // # global const CLASSIFICATION_GROUND = UInt8(101)
	float lat_deg;				  // # Intruder Latitude
	float lon_deg;				  // # Intruder Longitude
	float vel_ew_kts;			  // # velocity in east - west direction, true east is positive
	float vel_ns_kts;			  // # velocity in north - sout direction, true north is positive
	float baro_alt_ft;			  // # Pressure altitude
	float baro_alt_rate_fps;	  // # Pressure altitude rate
	float geo_hae_ft;			  // # geodetic height - above - ellipsoid(HAE) altitude
	float geo_hae_rate_fps;		  // # geodetic height - above - ellipsoid(HAE) altitude rate
};

struct GroundRADARPacket
{
	GroundRADARInfo GroundRADARInfo[NUMGROUNDRADAR];
};

struct ADSBInfo
{
	int Address;
	uint8_t non_icao;	  // # Flag to indicate that the address is a non - ICAO 24 - bit aircraft address(anonymous
						  // address)
	float lat_deg;		  // # Intruder Latitude
	float lon_deg;		  // # Intruder Longitude
	float vel_ew_kts;	  // # velocity in east - west direction, true east is positive
	float vel_ns_kts;	  // # velocity in north - sout direction, true north is positive
	float baro_alt_ft;	  // # Pressure altitude
	float is_alt_geo_hae; // # Intruder reporting geodetic height - above - ellipsoid(HAE) altitude
	uint8_t quant_ft;	  // # altitude quantization(25 or 100)
	uint8_t nic;		  // # Navigation Integrity Category(NIC)
	uint8_t externally_validated; // # Flag to indicate ADSB intruder has been validated by an external source
	float r_slant;
	float Chi_rel;
	uint8_t UniqueID;
};

struct ADSBPacket
{
	ADSBInfo ADSBInfo[NUMADSB];
};

struct ModeCInfo
{
	uint32 mode_c;		// # Intruder ICAO 24-bit Aircraft Address
	uint32 external_ID; // # Track Number assigned by a front-end Mode C tracker (Optional for ReceiveModeCReplies)
	int coded_alt;		// # Reported Gillham altitude code
	int conf;			// # Altitude confidence bits
	float r_slant;		// # Raw slant-range (always positive)
	float Chi_rel;		// # Raw bearing to inturder (nose is 0, right is pi/2)
	float toa;			// # Time of applicability
};

struct ModeCPacket
{
	ModeCInfo ModeCInfo[NUMADSB];
};

struct ModeSInfo
{
	float r_slant;	  // # Raw slant-range (always positive)
	float Chi_rel;	  // # Raw bearing to inturder (nose is 0, right is pi/2)
	float z_baro;	  // # Intruder barometric altitude
	uint32 mode_s;	  // # Intruder ICAO 24-bit Aircraft Address
	uint32 q_int;	  // # Intruder altitude quantization (25,100 or 0 for NAR)
	uint32 ri;		  // # Intruder reply information (i.e equipage, see RI_FIELD constants)
	uint32 surv_mode; // # Type of surveillance (0/Normal; 1/Reduced; 2/Hybrid; 3/Extended Hybrid or Dropped active
					  // track, see SURVEILLANCE_REGION constnts)
	float toa;		  // # Time of applicability
};

struct ModeSPacket
{
	ModeSInfo modeSInfo[NUMADSB];
};

#pragma pack(pop)
