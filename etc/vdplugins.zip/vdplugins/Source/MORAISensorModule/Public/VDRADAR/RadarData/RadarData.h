﻿#pragma once

#include "CoreMinimal.h"

struct RadarSensorDetection
{
	uint16_t detectionId;
	float positionX;
	float positionY;
	float altitude;
	float azimuth;
	float distance;
};
