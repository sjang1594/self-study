﻿#pragma once
#include <cmath>
#include <vector>

#include "CoreMinimal.h"
#include "Utils/VDCommon.h"

// Define the cosine pattern for the azimuth and elevation angles
#define COSINE_AZIMUTH_PATTERN(angle) (20 * log10(pow(cos(Deg2Rad(angle)), 4)) + 6)
#define COSINE_ELEVATION_PATTERN(angle) (20 * log10(pow(cos(Deg2Rad(angle)), 20)) + 6)

namespace VD_SENSOR
{
	struct VDRadarTransmitter
	{
		VDRadarTransmitter();
		~VDRadarTransmitter();
	};

	struct VDRadarTransmitterChannel
	{
		VDRadarTransmitterChannel(
			float azimuthAngleStartIn, float azimuthAngleEndIn, float elevationAngleStartIn, float elevationAngleEndIn)
		{
			for (float i = azimuthAngleStartIn; i <= azimuthAngleStartIn; i++)
			{
				azimuthAngles.push_back(i);
				azimuthPattern.push_back(COSINE_AZIMUTH_PATTERN(i));
			}

			for (float i = elevationAngleStartIn; i <= elevationAngleEndIn; i++)
			{
				elevationAngles.push_back(i);
				elevationPattern.push_back(COSINE_ELEVATION_PATTERN(i));
			}
		}

		~VDRadarTransmitterChannel() {};

		std::vector<float> azimuthAngles;
		std::vector<float> azimuthPattern;

		std::vector<float> elevationAngles;
		std::vector<float> elevationPattern;
	};
} // namespace VD_SENSOR
