#pragma once

#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"

#include "Utils/VDALG.h"

#include "VDRADARInfo.h"
#include "VDNoise/VDNoise.h"

class MORAISENSORMODULE_API VDSensorGRADAR
{
public:
	VDSensorGRADAR() :
	ellipsoidModelId(),
	groundRadarPacket_(),
	algObject_(),
	groundRadarNoise(nullptr),
	mapUtmOrigin(nullptr),
	rootComponent(nullptr),
	world(nullptr),
	dot(0.0),
	angle(0.0),
	distance(0.0),
	numObj(0),
	turnAngle(0.0) {};

	~VDSensorGRADAR();

	void Initialize();
	void Release();
	void Update(const float deltaTimeIn);
	void SetWorld(const UWorld* worldIn);
	void SetRootComponent(const USceneComponent* rootIn);

	/* SensorData 출력 필요 시 호출 */
	GroundRADARPacket GetGroundRadarData() { return groundRadarPacket_; }

	WGSData CalculateLongLat(const FVector* mapOriginIn, FVector targetPoseIn, WGSData* wgsPositionIn);

private:
	void SetEllipsoidModel(EllipsoidModel ellipsoidIdIn) { ellipsoidModelId = ellipsoidIdIn; }

	bool HasRootComponent();
	bool HasWorld();

	// For DebugLog
	void InfoLog(const FString logIn);
	void WarningLog(const FString logIn);
	void ErrorLog(const FString logIn);

	EllipsoidModel ellipsoidModelId;
	GroundRADARPacket groundRadarPacket_;
	AlgObject algObject_;
	VDNoise* groundRadarNoise;

	const FVector* mapUtmOrigin;
	const USceneComponent* rootComponent;
	const UWorld* world;

	FVector location_;
	FVector rot_;
	FQuat quat_;
	FVector velocity_;
	FVector acceleration_;
	FVector angularVelocity_;
	FVector angularAcceleration_;

	TArray<AActor*> ignoreActors;
	TArray<AActor*> outActors;
	TArray<AActor*> attachedActors;

	FVector sensorOrigin_;
	FVector sensorForwardVector_;
	FVector closestPoint_;

	float dot;
	float angle;
	float distance;
	int numObj;
	float turnAngle;
};
