#pragma once

#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"

#include "VDSensorBase.h"
#include "VDRADARInfo.h"

class AGeoReferencingSystem;

class MORAISENSORMODULE_API VDSensorADSB : public VDSensorBase
{
	using arrayFVector_t = std::array<FVector, 2>; // Array of FVector, length 2.
	using arrayInt = std::array<int, 64>;		   // Array of int, length 64.
public:
	VDSensorADSB() :
	mean(0),
	stdev(0),
	geoReferencingSystem(nullptr),
	mapUtmOrigin(nullptr),
	ellipsoidModelId(),
	adsbNoise(nullptr),
	prevDeltaTime(0),
	icaoIntruder(),
	adsbPacket_(),
	algObject_(),
	ownshipInfo_(),
	bDebugAdsb(false),
	jsbSimYaw(nullptr),
	jsbSimAltitudeAslFt(nullptr),
	jsbSimLatitude(nullptr),
	jsbSimLongitude(nullptr),
	jsbSimVelocityNorthFps(nullptr),
	jsbSimVelocityEastFps(nullptr),
	jsbSimAltitudeRateFps(nullptr),
	jsbSimAltitudeAglFt(nullptr),
	radius(3.7f * NMITOMETER),
	dot(0.0f),
	angle(0.0f),
	distance(0.0f),
	numObj(0),
	turnAngle(0.0f),
	hDot(0.0f),
	hAngle(0.0f),
	horizontalAngle(0.0f)
	{
	}

	virtual ~VDSensorADSB() override;

	virtual void Initialize() override;
	virtual void Release() override;
	virtual void Update(const float deltaTimeIn) override;

	/* SensorData 출력 필요 시 호출 */
	ADSBPacket GetAdsbData() { return adsbPacket_; }

	void SetDynamicsModel(const double* yawIn, const double* altitudeASLftIn, const double* latIn, const double* longIn,
		const double* velNorthFpsIn, const double* velEastFpsIn, const double* altitudeRateFpsIn,
		const double* altitudeAglFtIn);

	float mean;
	float stdev;

private:
	WGSData CalculateLongLat(const FVector* mapOriginIn, FVector targetPoseIn, WGSData* wgsPositionIn);

	void SetEllipsoidModel(EllipsoidModel ellipsoidIdIn) { ellipsoidModelId = ellipsoidIdIn; }

	bool IsJsbSimResourceLoad();

	AGeoReferencingSystem* geoReferencingSystem;
	const FVector* mapUtmOrigin;
	EllipsoidModel ellipsoidModelId;

	FVector location_;
	FVector rot_;
	FQuat quat_;
	FVector velocity_;
	FVector acceleration_;
	FVector angularVelocity_;
	FVector angularAcceleration_;

	/* Noise */
	VDNoise* adsbNoise;

	float prevDeltaTime;
	arrayInt icaoIntruder;
	arrayFVector_t prevLocation;
	arrayFVector_t prevRotator;

	ADSBPacket adsbPacket_;
	AlgObject algObject_;

	OwnShipInfo ownshipInfo_;

	bool bDebugAdsb;

	const double* jsbSimYaw;
	const double* jsbSimAltitudeAslFt;
	const double* jsbSimLatitude;
	const double* jsbSimLongitude;
	const double* jsbSimVelocityNorthFps;
	const double* jsbSimVelocityEastFps;
	const double* jsbSimAltitudeRateFps;
	const double* jsbSimAltitudeAglFt;

	TArray<AActor*> ignoreActors;
	TArray<AActor*> outActors;
	TArray<AActor*> attachedActors;

	FVector sensorOrigin_;
	FVector sensorForwardVector_;
	FVector closestPoint_;

	float radius;
	float dot; // TODO: check unused variable
	float angle;
	float distance;
	int numObj;
	float turnAngle;

	float hDot;
	float hAngle;
	float horizontalAngle;
};
