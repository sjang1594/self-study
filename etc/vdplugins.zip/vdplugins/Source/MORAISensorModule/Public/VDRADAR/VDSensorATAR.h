#pragma once

#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"

#include "VDSensorBase.h"
#include "VDRADARInfo.h"

class MORAISENSORMODULE_API VDSensorATAR : public VDSensorBase
{
public:
	VDSensorATAR() :
	mean(0.0),
	stdev(0.0),
	farDistance(0.0),
	nearDistance(0.0),
	hFov(0.0),
	vFov(0.0),
	atarPacket_(),
	ownshipInfo_(),
	algObject_(),
	atarNoise(nullptr),
	jsbSimYaw(nullptr),
	jsbSimAltitudeAslFt(nullptr),
	jsbSimLatitude(nullptr),
	jsbSimLongitude(nullptr),
	jsbSimVelocityNorthFps(nullptr),
	jsbSimVelocityEastFps(nullptr),
	jsbSimAltitudeRateFps(nullptr),
	jsbSimAltitudeAglFt(nullptr),
	bDrawFrustum(false),
	hDot(0.0),
	hAngle(0.0),
	vDot(0.0),
	vAngle(0.0),
	distance(0.0),
	numObj(0),
	horizontalAngle(0.0),
	verticalAngle(0.0)
	{
	}

	virtual ~VDSensorATAR() override;

	virtual void Initialize() override;
	virtual void Release() override;
	virtual void Update(const float deltaTimeIn) override;

	/* SensorData 출력 필요 시 호출 */
	ATARPacket GetAtarData() { return atarPacket_; }

	void SetDynamicsModel(const double* yawIn, const double* altitudeAslFtIn, const double* latIn, const double* longIn,
		const double* velNorthFpsIn, const double* velEastFpsIn, const double* altitudeRateFpsIn,
		const double* altitudeAglFtIn);

	float mean;
	float stdev;

	float farDistance;
	float nearDistance;
	float hFov;
	float vFov;

private:
	/** @breif Check JsbSIMResource Load
	 * @return true if jsbsim resource is loaded */
	bool IsJsbSimResourceLoad();

	ATARPacket atarPacket_;
	OwnShipInfo ownshipInfo_;
	AlgObject algObject_;
	VDNoise* atarNoise;

	FVector location_;
	FVector rot_;
	FQuat quat_;
	FVector velocity_;
	FVector acceleration_;
	FVector angularVelocity_;
	FVector angularAcceleration_;

	/* [Description]
	 * JSBSim Info */
	const double* jsbSimYaw;
	const double* jsbSimAltitudeAslFt;
	const double* jsbSimLatitude;
	const double* jsbSimLongitude;
	const double* jsbSimVelocityNorthFps;
	const double* jsbSimVelocityEastFps;
	const double* jsbSimAltitudeRateFps;
	const double* jsbSimAltitudeAglFt;

	TArray<AActor*> ignoreActors;
	TArray<AActor*> outActors;
	TArray<AActor*> attachedActors;

	FVector sensorOrigin_;
	FVector closestPoint_;

	bool bDrawFrustum;

	float hDot;
	float hAngle;
	float vDot;
	float vAngle;
	float distance;
	int numObj;
	float horizontalAngle;
	float verticalAngle;
};
