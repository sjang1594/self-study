#pragma once

#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"

#include "VDSensorBase.h"
#include "VDRADARInfo.h"

class VDGeoGraphic;

class MORAISENSORMODULE_API VDSensorOwnShip : public VDSensorBase
{
public:
	VDSensorOwnShip() :
	mean(0),
	stdev(0),
	bDebugOwnShip(false),
	ownshipNoise(nullptr),
	ownshipInfo_(),
	mapUtmOrigin(nullptr),
	ellipsoidModelId(),
	jsbSimYaw(nullptr),
	jsbSimAltitudeAslFt(nullptr),
	jsbSimLatitude(nullptr),
	jsbSimLongitude(nullptr),
	jsbSimVelocityNorthFps(nullptr),
	jsbSimVelocityEastFps(nullptr),
	jsbSimAltitudeRateFps(nullptr),
	jsbSimAltitudeAglFt(nullptr),
	radius(20000.0f),
	dot(0),
	angle(0),
	distance(0),
	numObj(0),
	turnAngle(0),
	geoidHeight(0.0f)
	{
	}

	virtual ~VDSensorOwnShip() override;

	virtual void Initialize() override;
	virtual void Release() override;
	virtual void Update(const float deltaTimeIn) override;

	/* SensorData 출력 필요 시 호출 */
	OwnShipInfo GetOwnShipInfoData() const { return ownshipInfo_; }

	void SetDynamicsModel(const double* yawIn, const double* altitudeASLftIn, const double* latIn, const double* longIn,
		const double* velNorthFpsIn, const double* velEastFpsIn, const double* altitudeRateFpsIn,
		const double* altitudeAglFtIn);
	WGSData CalculateLongLat(const FVector* mapOriginIn, FVector targetPoseIn, WGSData* wgsPositionIn);
	double CalculatePressure(double altitudeIn);

	float mean;
	float stdev;

private:
	/** @brief Check JsbSIMResource Load
	 * @return true if jsbsim resource is loaded */
	bool IsJsbSimResourceLoad();

	void SetEllipsoidModel(EllipsoidModel ellipsoidIdIn) { ellipsoidModelId = ellipsoidIdIn; }

	bool bDebugOwnShip;
	VDNoise* ownshipNoise;

	OwnShipInfo ownshipInfo_;

	const FVector* mapUtmOrigin;
	EllipsoidModel ellipsoidModelId;

	/* JSB Sim Info */
	const double* jsbSimYaw;
	const double* jsbSimAltitudeAslFt;
	const double* jsbSimLatitude;
	const double* jsbSimLongitude;
	const double* jsbSimVelocityNorthFps;
	const double* jsbSimVelocityEastFps;
	const double* jsbSimAltitudeRateFps;
	const double* jsbSimAltitudeAglFt;

	static inline float maxMidAngle = 45.0f;
	static inline float longRange = 17400.0f;
	static inline float maxLongAngle = 10.0f;
	static inline float midRange = 6000.0f;

	TArray<AActor*> ignoreActors;
	TArray<AActor*> outActors;

	FVector sphereSpawnLocation_;
	FVector sensorForwardVector_;
	FVector closestPoint_;

	float radius;
	float dot;
	float angle;
	float distance;
	int numObj;
	float turnAngle;
	double geoidHeight;
};
