#pragma once

#include "CoreMinimal.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "Components/SceneComponent.h"

#include "Eigen/Dense"

#include "VDSensorBase.h"
#include "VDRADAR/RadarData/RadarData.h"
#include "VDSensorConfig/VDRADARSensorConfig.h"

struct VDRadarDefaultConfig;
struct SensorPose;
class URandomEngine;

struct MORAISENSORMODULE_API VDRadarData
{
	uint32_t id; // [Warning] 0 ~ 256
	uint8_t numDetections;
	RadarSensorDetection detections_[64];
};

struct RayData
{
	float radius;
	float angle;
	bool bHit;
	float relativeVelocity;
	FVector hitLocation;
	FVector2D azimuthAndElevation;
	FLinearColor intensity;
	float distance;
};

class MORAISENSORMODULE_API VDSensorRADAR : public VDSensorBase
{
public:
	VDSensorRADAR() {}

	virtual ~VDSensorRADAR() override;
	virtual void Initialize() override;
	virtual void Release() override;
	virtual void Update(const float deltaTimeIn) override;

	/**
	 * @brief It will initialize the default radar sensor configuration
	 * @remark Look at the configuration file at VDSensorConfig.h */
	void InitConfiguration();

	/**
	 * @brief It will set the noise of the radar sensor */
	void InitNoise();

	/**
	 * @brief It will set the noise of the radar sensor
	 * @param noiseIn: VDNoise* */
	void SetNoise(VDNoise* noiseIn);

	/**
	 * @brief It will return Radar Data
	 * @return VDRadarData */
	VDRadarData GetRadarData() const { return sensorData_; }

	/**
	 * @brief It will return the point cloud data
	 * @return std::vector<float> */
	std::vector<float> GetRadarPointCloud() const { return radarPointCloud_; }

	/**
	 * @brief It will set the radar sensor configuration
	 * @param hFovIn: const float&
	 * @param vFovIn: const float&
	 * @param minDistanceIn: const float&
	 * @param maxDistanceIn: const float& */
	void SetParam(const float& hFovIn, const float& vFovIn, const float& minDistanceIn, const float& maxDistanceIn,
		const float& meanIn, const float& stdDevIn);

	/**
	 * @brief It will set the radar sensor configuration
	 * @param configIn: VDRadarConfig& */
	void SetParam(const VDRadarParam& configIn);

	/**
	 * @brief It will return the radar configuration
	 * @return VDRadarConfig */
	VDRadarParam GetRadarParam() const { return *radarParam; }

	/**
	 * @brief It will set the random engine
	 * @param randomEngineIn: URandomEngine* */
	void SetRandomEngine(URandomEngine* randomEngineIn) { randomEngine = randomEngineIn; }

	/**
	 * @brief It will send the the line traces (Ray Casting), and fill the RADAR data)
	 * @param poseIn : SensorPose&
	 * @param deltaTimeIn : float */
	void SendLineTraces(SensorPose& poseIn, float deltaTimeIn);

	/**
	 * @brief It will set the debug point cloud or able to draw the point cloud
	 * @param bShowPointCloudIn */
	void SetDebugPointCloud(const bool bShowPointCloudIn) { bShowPointCloud = bShowPointCloudIn; }

	void DrawRadarData();

private:
	void CleanUp();
	float CalculateRelativeVelocity(const FHitResult& hitResultIn, const FVector& sensorPoseIn) const;
	void CalculateCurrentVelocity(const float deltaTimeIn);
	void GetMaterialColor(const AActor* actorIn, FLinearColor& colorOut);

	static inline Eigen::Vector3f ToVector3r(const FVector& vecIn, float scaleIn, bool convertToNed)
	{
		return Eigen::Vector3f(vecIn.X * scaleIn, vecIn.Y * scaleIn, (convertToNed ? -vecIn.Z : vecIn.Z) * scaleIn);
	}

	static inline Eigen::Vector3f ToLeftHandToRightHandPosition(const Eigen::Vector3f& vecIn)
	{
		return Eigen::Vector3f(vecIn.x(), -1.0 * vecIn.y(), vecIn.z());
	}

	static inline FVector ToFVector(const Eigen::Vector3f& vecIn, float scaleIn, bool convertFromNed)
	{
		return FVector(vecIn.x() * scaleIn, vecIn.y() * scaleIn, (convertFromNed ? -vecIn.z() : vecIn.z()) * scaleIn);
	}

#pragma region Temp
	// [TEMP] UAM - Sensor Radar Config & Cirrus Radar Config
	static inline float midRange = 6000.0f;
	static inline float maxMidAngle = 45.0f;

	static inline float longRange = 17400.0f;
	static inline float maxLongAngle = 10.0f;
// [TEMP] - UAM - Sensor Radar Config
#pragma endregion

	VDRadarData sensorData_;
	std::vector<float> radarPointCloud_;

	/* CARLA RADAR DATA */
	std::vector<RayData> radarData_;

	/* The Radar Sensor Configuration */
	/* The half-power beam width (-3 dB). [Continential ARS408] */
	float range = 15000.0f;
	float azimuthBeamWidth = 2.2f;
	FCollisionQueryParams traceParams;
	FVector prevLocation_;
	FVector currentVelocity_;
	int pointsPerSecond = 1000;
	/**********************************/

	/* Radar Param */
	VDRadarParam* radarParam = nullptr;
	URandomEngine* randomEngine = nullptr;

	/* VD Noise */
	VDNoise* radarNoise = nullptr;
	bool bShowPointCloud = false;

	TArray<AActor*> ignoreActors;
	TArray<AActor*> outActors;

	int numObj;

	/* Radar Config */
	int totalLaserCount;
	int horizontalLaserCount;
	int verticalLaserCount;
};
