﻿#pragma once

#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"

#include "VDSensorBase.h"
#include "VDRADAR/VDRADARInfo.h"

class MORAISENSORMODULE_API VDSensorEOIR : public VDSensorBase
{
public:
	VDSensorEOIR() :
	mean(0.0f),
	stdev(0.0f),
	eoirPacket_(),
	ownshipInfo_(),
	algObject_(),
	eoirNoise(nullptr),
	alg(nullptr),
	bDrawFrustum(false),
	hDot(0.0f),
	hAngle(0.0f),
	vDot(0.0f),
	vAngle(0.0f),
	distance(0.0f),
	numObj(0),
	horizontalAngle(0.0f),
	verticalAngle(0.0f),
	jsbSimYaw(nullptr),
	jsbSimAltitudeAslFt(nullptr),
	jsbSimLatitude(nullptr),
	jsbSimLongitude(nullptr),
	jsbSimVelocityNorthFps(nullptr),
	jsbSimVelocityEastFps(nullptr),
	jsbSimAltitudeRateFps(nullptr),
	jsbSimAltitudeAglFt(nullptr)
	{
	}

	virtual ~VDSensorEOIR() override;

	virtual void Initialize() override;
	virtual void Release() override;
	virtual void Update(const float deltaTimeIn) override;

	/** SensorData
	 * @brief It will return EOIR Data
	 * @return VDRadarData */
	EOIRPacket GetEoirData() { return eoirPacket_; }

	/** SetDynamicsModel
	 * @brief This will set the dynamic model of the objects
	 * Target Object type will be Airplanes Types
	 * @param yawIn: double* yawIn
	 * @param altitudeASLftIn: double* altitudeASLftIn
	 * @param latitudeIn: double* latitudeIn
	 * @param longitudeIn: double* longitudeIn
	 * @param velNorthFpsIn: double* velNorthFpsIn
	 * @param velEastFpsIn: double* velEastFpsIn
	 * @param altitudeRateFpsIn: double* altitudeRateFpsIn
	 * @param altitudeAglFtIn: double* altitudeAglFtIn */
	void SetDynamicsModel(const double* yawIn, const double* altitudeASLftIn, const double* latitudeIn,
		const double* longitudeIn, const double* velNorthFpsIn, const double* velEastFpsIn,
		const double* altitudeRateFpsIn, const double* altitudeAglFtIn);

	// TODO: Possible to initialize Member Variable Initialization on here //
	float mean;
	float stdev;
	float farDistance = 10000.0f;
	float nearDistance = 100.0f;
	float hFov = 115.0f;
	float vFov = 15.0f;

private:
	/** IsJsbSIMResourceLoad
	 * @brief Check JsbSIMResource Load
	 * @return true if jsbsim resource is loaded */
	bool IsJsbSimResourceLoad();
	bool IsRootComponentAvailable() const;

	/* Define Packet, Algorithm Object, OwnShipInfo, Noise */
	EOIRPacket eoirPacket_;
	OwnShipInfo ownshipInfo_;
	AlgObject algObject_;
	VDNoise* eoirNoise;
	VDALG* alg;

	/* Object Info
	 * Pos, Rot, Velocity,
	 * Acceleration, AngularVelocity, AngularAcceleration, TargetObjRot */
	FVector location_;
	FVector rot_;
	FQuat quat_;
	FVector velocity_;
	FVector acceleration_;
	FVector angularVelocity_;
	FVector angularAcceleration_;
	FRotator targetObjRot_;

	/* Sensor Info & Spec
	 * Sensor Origin, Sensor Forward Vector, Sensor Up Vector, Closest Point
	 * Debug: bDrawFrustum,
	 * hDot, hAngle, vDot, vAngle, distance, numObj, horizontalAngle, verticalAngle */
	FVector sensorOrigin_;
	FVector sensorForwardVector_;
	FVector sensorUpVector_;
	FVector closestPoint_;

	bool bDrawFrustum;
	float hDot;
	float hAngle;
	float vDot;
	float vAngle;
	float distance;
	int numObj;
	float horizontalAngle;
	float verticalAngle;

	/* JSBSim Dynamics Model
	 * aslFt : above sea level
	 * aglFt : above ground level */
	const double* jsbSimYaw;
	const double* jsbSimAltitudeAslFt;
	const double* jsbSimLatitude;
	const double* jsbSimLongitude;
	const double* jsbSimVelocityNorthFps;
	const double* jsbSimVelocityEastFps;
	const double* jsbSimAltitudeRateFps;
	const double* jsbSimAltitudeAglFt;

	// TODO: Question Mark? //
	TArray<AActor*> ignoreActors;
	TArray<AActor*> outActors;
	TArray<AActor*> attachedActors;
};
