#pragma once

#include "Eigen/Eigen"

#include "VDSensorBase.h"
#include "VDSensorConfig/VDCameraSensorConfig.h"
#include "VDCamera/VDCaptureComponent.h"
#include "VDCamera/VDImageExporter.h"

class MORAISENSORMODULE_API VDSensorCamera : public VDSensorBase
{
public:
	VDSensorCamera() :
	resolution_(640u, 480u),
	principalPoint_(320.0f, 240.0f),
	currentFocalLength(20.0f),
	currentAperture(2.8f),
	fieldOfView(0.0f),
	accumulatedDeltaTime(0.0f),
	depthRange(10.0f, 30.0f),
	distortion_(0.0f, 0.0f, 0.0f, 0.0f, 0.0f),
	filmbackSettings_(36.0f, 24.0f),
	currentCFA(VD_SENSOR::ColorFilterArray::NONE),
	currentCameraType(VD_SENSOR::CameraType::RGB)
	{
	}

	virtual ~VDSensorCamera() override;

	virtual void Initialize() override;
	virtual void Release() override;
	virtual void Update(const float deltaTimeIn) override;

	void UpdateDerivedData();
	void UpdateMaterialData() const;

	uint8_t* GetImageByteArray() const
	{
		return imageExporter->EncodeByteArray(sceneCaptureComponent->GetCurrentTextureTarget());
	}

	TObjectPtr<UVDCaptureComponent> GetSceneCaptureComponent() const { return sceneCaptureComponent; }

	TObjectPtr<UTextureRenderTarget2D> GetCurrentTextureTarget() const;

	/**
	 * @brief It will save a rendered texture.
	 */
	void SaveRenderTarget(const FString& pathIn, const FString& fileNameIn) const;

	/**
	 * @brief It will set a texture render target and material instance settings that correspond to the camera type.
	 */
	void SetCameraType(const VD_SENSOR::CameraType& cameraTypeIn);

	/**
	 * @brief It will return current camera type.
	 */
	VD_SENSOR::CameraType GetCameraType() const { return currentCameraType; }

	/**
	 * @brief It will return mathematic camera model for lens distortion/undistortion.
	 *
	 * @return Camera matrix =
	 *  | F.X  0  C.x  0  |
	 *  |  0  F.Y C.Y  0  |
	 *  |  0   0   A   1  |
	 *  |  0   0   B   0  |
	 *
	 *  A = Far clip plane / (Far clip plane - Near clip plane)
	 *  B = -Near clip plane * Far clip plane / (Far clip plane - Near clip plane)
	 */
	Eigen::Matrix4f GetCameraViewIntrinsicMatrix() const;

	/**
	 * @brief It will return the focal length that converted the unit from pixels to millimeters.
	 * Pixel units depend on resolution and sensor size. */
	float ConvertUnitPixel2MM(const float& focalLengthPixelUnitIn) const;

	/**
	 * @brief It will return the focal length that converted the unit from millimeters to pixels.
	 * Pixel units depend on resolution and sensor size. */
	float ConvertUnitMM2Pixel(const float& focalLengthMMUnitIn) const;

	/**
	 * @brief It will set the brown conrady lens distortion parameters from the input radial distortion (k1, k2, k3) and
	 * tangential distortion (p1, p2) parameters. The input struct consists of float[3] and float[2]. */
	void SetBrownConradyLensDistortionParams(const VD_SENSOR::VDBrownConradyLensDistortionParams& distParamsIn);

	/**
	 * @brief It will return the brown conrady lens distortion parameters that contains radial distortion (k1, k2, k3)
	 * and tangential distortion (p1, p2) parameters. */
	VD_SENSOR::VDBrownConradyLensDistortionParams GetBrownConradyLensDistortionParams() const { return distortion_; }

	/**
	 * @brief It will set the width and height of the capture image. (unit = pixels)
	 */
	void SetResolution(const uint32_t& resolutionXIn, const uint32_t& resolutionYIn);

	/**
	 * @brief It will return the current width and height of the capture image. The return struct type consists of two
	 * unsigned integers  (unit = pixels). */
	Eigen::Vector2i GetResolution() { return resolution_; }

	/**
	 * @brief It will set the focal length (unit = pixels). */
	void SetFocalLength(const float& focalLengthIn);

	/**
	 * @brief It will return the current focal length (unit = pixels). */
	float GetFocalLength() const { return ConvertUnitMM2Pixel(currentFocalLength); }

	/**
	 * @brief It will set the field of view (unit = degree). */
	void SetFOV(const float& fieldOfViewIn) { SetHorizontalFov(fieldOfViewIn); }

	/**
	 * @brief It will return current field of view (unit = degree). */
	float GetFOV() const { return GetHorizontalFov(); }

	/**
	 * @brief It will set the width and height of the image center position relative to the projected filmback
	 * (unit = pixels) */
	void SetPrincipalPoints(const float& principalPointsXIn, const float& principalPointsYIn);

	/**
	 * @brief It will return the center position of the image relative to the projected filmback (unit = pixels).
	 * The return struct type consists of two floats (width, height). */
	Eigen::Vector2f GetPrincipalPoints() const { return principalPoint_; }

	/**
	 * @brief It will set the horizontal field of view of the filmback. (unit = degrees).
	 * The input parameter scales the scale of the sensor width to adjust the field of view logarithmically. */
	void SetHorizontalFov(const float& fieldOfViewIn);

	/**
	 * @brief It will return the current horizontal field of view of the filmback. (unit = degrees).
	 * The input parameter scales the scale of the sensor width to adjust the field of view logarithmically. */
	float GetHorizontalFov(const float& scaleIn = 1.0f) const;

	/**
	 * @brief It will set the vertical field of view of the filmback. (unit = degrees).
	 * The input parameter scales the scale of the sensor width to adjust the field of view logarithmically. */
	void SetVerticalFov(const float& fieldOfViewIn);

	/**
	 * @brief It will return the current vertical field of view of the filmback. (unit = degrees).
	 * The input parameter scales the scale of the sensor width to adjust the field of view logarithmically. */
	float GetVerticalFov(const float& scaleIn = 1.0f) const;

	/**
	 * @brief It will return the current horizontal field of view where the scene is output from the filmback.
	 * (unit = degrees).
	 * The input parameter scales the scale of the sensor width to adjust the field of view logarithmically.
	 * For more information, See the "Gate fit" issue (https://morai.atlassian.net/browse/TVD-1627) */
	float GetCameraViewHorizontalFov(const float& scaleIn = 1.0f) const;

	/**
	 * @brief It will convert the current horizontal field of view where the scene is output from the filmback into a
	 * focal length (unit = pixels). */
	float ConvertCameraViewHorizontalFovToFocalLength(const float& fovIn) const;

	/**
	 * @brief It will convert the current vertical field of view where the scene is output from the filmback into a
	 * focal length (unit = pixels). */
	float ConvertCameraViewVerticalFovToFocalLength(const float& fovIn) const;

	/**
	 * @brief It will return the current vertical field of view where the scene is output from the filmback. (unit =
	 * degrees). The input parameter scales the scale of the sensor width to adjust the field of view logarithmically.
	 * For more information, See the "Gate fit" issue (https://morai.atlassian.net/browse/TVD-1627) */
	float GetCameraViewVerticalFov(const float& scaleIn = 1.0f) const;

	/**
	 * @brief It will set the width and height of the filmback (unit = mm) */
	void SetFilmbackSize(const float& sensorWidthIn, const float& sensorHeightIn);

	/**
	 * @brief It will return the width and height of the filmback (unit = mm).
	 * The return struct type consists of two floats (width, height). */
	Eigen::Vector2f GetFilmbackSize() const
	{
		return Eigen::Vector2f { filmbackSettings_.sensorWidth, filmbackSettings_.sensorHeight };
	}

	/**
	 * @brief It will set the type of the color filter array.
	 * The input type is defined as an enum class in VDCameraSensorConfig.h. */
	void SetColorFilterArray(const VD_SENSOR::ColorFilterArray& cfaIn);

	/**
	 * @brief It will return the type of the color filter array.
	 * The return type is an enum class that defined in VDCameraSensorConfig.h. */
	VD_SENSOR::ColorFilterArray GetColorFilterArray() const { return currentCFA; }

	void SetCurrentCameraType(const VD_SENSOR::CameraType& camTypeIn) { currentCameraType = camTypeIn; }

	VD_SENSOR::CameraType GetCurrentCameraType() const { return currentCameraType; }

	void SetDepthRange(const float& minDepthIn, const float& maxDepthIn);

	Eigen::Vector2f GetDepthRange() const { return depthRange; }

	bool IsActivatedAutoSave() const;
	void ActivateAutoSave() const;
	void DeactivatedAutoSave() const;

	/**
	 * @brief It undistorts top left originated viewport UV into the view space (x', y', z'=1.f).
	 * The input parameters take the aspect ratio of the current resolution and the corner points of the view space.
	 * The return struct type consists of two floats (width, height). */
	Eigen::Vector2f LensUndistortViewportUVIntoViewSpace(
		float DistortedAspectRatio, Eigen::Vector2f DistortedViewportUV) const;

	/**
	 * @brief It will return the over-scan horizontal field of view that required for undistort rendering to avoid
	 * unrendered distorted pixels (unit = degrees). */
	float GetOverScanFov() const;

	/**
	 * @brief It will draw a frustum to visualize the "Image Gate" for debugging
	 * (https://morai.atlassian.net/browse/TVD-1627)
	 */
	void DrawFrustumImageView() const;

	/**
	 * @brief It will draw a frustum to visualize the "Sensor Gate" for debugging
	 * (https://morai.atlassian.net/browse/TVD-1627)
	 */
	void DrawFrustumResolutionView() const;

	virtual void InitAndRunThread(const float& threadSleepTimeIn) override;
	virtual void UpdateThreadProcess() override;
	virtual void ReleaseThread() override;

private:
	Eigen::Vector2i resolution_;	 // unit: pixel
	Eigen::Vector2f principalPoint_; // unit: pixel
	float currentFocalLength;		 // unit: mm
	float currentAperture;
	float fieldOfView; // unit: degree
	float accumulatedDeltaTime;
	Eigen::Vector2f depthRange; // unit: meter

	VD_SENSOR::VDBrownConradyLensDistortionParams distortion_;
	VD_SENSOR::CameraSettings::Filmback filmbackSettings_;
	VD_SENSOR::CameraSettings::CameraLens lensSettings_;
	VD_SENSOR::ColorFilterArray currentCFA;
	VD_SENSOR::CameraType currentCameraType;

	TObjectPtr<UVDCaptureComponent> sceneCaptureComponent = nullptr;
	TObjectPtr<UVDImageExporter> imageExporter = nullptr;
};
