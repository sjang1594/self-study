﻿#pragma once

#include "Runtime/Engine/Classes/Engine/TextureRenderTarget2D.h"
#include "Runtime/Engine/Classes/Components/SceneCaptureComponent2D.h"

#include "Eigen/Eigen"

#include "VDSensorConfig/VDCameraSensorConfig.h"

#include "VDCaptureComponent.generated.h"

UCLASS()
class MORAISENSORMODULE_API UVDCaptureComponent : public USceneCaptureComponent2D
{
	GENERATED_BODY()

public:
	UVDCaptureComponent(const FObjectInitializer& objectInitializerIn);

	virtual ~UVDCaptureComponent() override;

	void Initialize(const Eigen::Vector2i& resolutionIn);

	TObjectPtr<UTextureRenderTarget2D> GetCurrentTextureTarget() const { return TextureTarget; }

	TObjectPtr<UMaterialInstanceDynamic> GetMaterialInstanceDynamic(VD_SENSOR::MaterialType materialTypeIn) const
	{
		return materialInstances[static_cast<int>(materialTypeIn)];
	}

	void SetCameraType(VD_SENSOR::CameraType cameraTypeIn);
	void ResizeAllTargetsResolution(const uint32_t& widthIn, const uint32_t& heightIn);

private:
	void InitTextureRenderTargets(const Eigen::Vector2i& resolutionIn);
	void InitMaterialInstanceDynamics();

	UPROPERTY()
	TArray<TObjectPtr<UTextureRenderTarget2D>> textureRenderTargets;

	UPROPERTY()
	TArray<TObjectPtr<UMaterialInstanceDynamic>> materialInstances;
};
