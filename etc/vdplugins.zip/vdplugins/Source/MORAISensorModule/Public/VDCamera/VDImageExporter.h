﻿#pragma once

#include <Engine/TextureRenderTarget2D.h>

#include <chrono>

#include "VDImageExporter.generated.h"

USTRUCT()
struct FRenderRequestStruct
{
	GENERATED_BODY()

	TArray<FColor> image;
	unsigned int width, height;
	EPixelFormat dataFormat;
	bool bIsReadyToExport = false;
};

USTRUCT()
struct FReadSurfaceContext
{
	GENERATED_BODY()

	TRefCountPtr<FRHITexture> SrcRenderTarget;
	TArray<FColor>* OutData;
	FIntRect Rect;
	FReadSurfaceDataFlags Flags;
};

UCLASS()
class MORAISENSORMODULE_API UVDImageExporter : public UObject
{
	GENERATED_BODY()

public:
	UVDImageExporter(const FObjectInitializer& objectInitializerIn);

	virtual ~UVDImageExporter() override
	{
		// UE_LOG(LogTemp, Log, TEXT("On destroying UVDImageExporter"));

		renderRequestQueue.Empty();
	}

	/**
	 * @brief It will set & return Camera Data */
	bool SaveRenderTarget(
		const FString& pathIn, const FString& fileNameIn, const TObjectPtr<UTextureRenderTarget2D> textureTargetIn);

	/**
	 * @breif It will be triggered while MSensorCamera->PostPhysTick() is executing
	 */
	void EnqueueRenderRequest(const TObjectPtr<UTextureRenderTarget2D>& textureTargetIn);

	uint8_t* EncodeByteArray(const TObjectPtr<UTextureRenderTarget2D> textureTargetIn);

	TArray<float> DecodeDepthIntToFloat(const TArray<FColor>& floatDepthIn);

	/**
	 * @breif Triggered while MSensorCamera->ThreadProcessUpdate() is executing
	 */
	void PopRenderRequest();

	void ClearRenderRequest() { renderRequestQueue.Empty(); }

	bool IsActivatedAutoSave() const { return bAutoSave; }

	void ActivateAutoSave() { bAutoSave = true; }

	void DeactivateAutoSave() { bAutoSave = false; }

	void SetSensorPeriod(const float& sensorPeriodIn);

	float GetSensorPeriod() const { return sensorPeriod; }

protected:
	void RunAsyncImageSaveTask(const FString& pathIn, const FString& fileNameIn, const FImageView& outBmpIn);
	FString ToStringWithLeadingZeros(const int& integer, const int& maxDigits);

private:
	std::chrono::steady_clock::time_point time;
	TQueue<FRenderRequestStruct*> renderRequestQueue;

	bool bAutoSave;
	bool bUsePNG;
	float sensorPeriod; // [TEMP] Debug 용도
	int numDigits;
	size_t imgCounter;
	FString saveDirPath;
};

class MORAISENSORMODULE_API AsyncSaveImageToDiskTask : public FNonAbandonableTask
{
public:
	AsyncSaveImageToDiskTask(const FString& pathIn, const FString& fileNameIn, const FImageView& outBmpIn);
	~AsyncSaveImageToDiskTask()
	{
		// UE_LOG(LogTemp, Warning, TEXT("AsyncTaskDone"));
	}

	// Required by UE4!
	FORCEINLINE TStatId GetStatId() const
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT(AsyncSaveImageToDiskTask, STATGROUP_ThreadPoolAsyncTasks);
	}

	void DoWork() const;

private:
	FImageView imageCopy;
	FString FileName;
};
