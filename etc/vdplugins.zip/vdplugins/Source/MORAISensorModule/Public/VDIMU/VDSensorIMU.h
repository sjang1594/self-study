#pragma once

#include <array>

#include "VDSensorBase.h"

#include "VDRADAR/VDRADARInfo.h"

struct MORAISENSORMODULE_API VDImuData
{
	FQuat orientation_;
	FVector angularVelocity_;
	FVector linearAcceleration_;
};

class MORAISENSORMODULE_API VDSensorIMU : public VDSensorBase
{
public:
	using arrayFVector_t = std::array<FVector, 2>;

	VDSensorIMU() :
	bDebugImu(false),
	prevLocation(),
	prevRotator(),
	previousVelocity_(FVector(0)),
	accResult_(),
	noise(),
	prevDeltaTime(0.0f),
	sensorData_(),
	jsbSimOrientation_(nullptr),
	jsbSimAngularVelocity_(nullptr),
	jsbSimLinearVelocity_(nullptr),
	dynamicObjLocation_(),
	dynamicObjAngularVelocity_(),
	dynamicObjQuat_()
	{
	}

	virtual ~VDSensorIMU() override {}

	virtual void Initialize() override;
	virtual void Release() override;
	virtual void Update(const float deltaTimeIn) override;

	/** @brief GetSensorData: This will return the sensor data
	 * @return VDImuData */
	VDImuData GetSensorData() const { return sensorData_; }

	/* JSBSim 등 동역학 모델로부터 계산된 역학 정보의 포인터를 설정하는 함수.
	 * IMU Sensor는 자체적으로 데이터를 계산하지 않고 JSBSim의 데이터를 활용하여 값을 출력함.
	 * 따라서 JSBSim의 Orientation, AngularVelocity, LinearVelocity 값을 들고와야 함.
	 * 이를 위해 JSBSim의 관련 역학 정보 소스를 IMU Class에 설정해야 함.
	 * BeginPlay 시 호출.*/

	/** [SUPERNAL / UAM]
	 * @brief SetDynamicModel: This will set the dynamic model of the objects
	 * Target Object type will be Airplanes Types
	 * @param orientationIn: FRotator* orientationIn
	 * @param angularVelocityIn: FVector*
	 * @param linearVelocityIn: FVector* */
	void SetDynamicsModel(
		const FRotator* orientationIn, const FVector* angularVelocityIn, const FVector* linearVelocityIn);

	/** [NSR]
	 * @brief SetDynamicModel: This will set the dynamic model of the objects
	 * Target Object types are drones
	 * @param locationIn: FVector
	 * @param angularVelocityIn: FVector
	 * @param quatIn: FQuat */
	void SetDynamicsModel(const FVector locationIn, const FVector angularVelocityIn, FQuat quatIn);

	/** [TestBed]
	 * @brief SetDefaultDynamicsModel: This will set the dynamic model of the objects
	 * Target Object types can be any Chaos Vehicle but it runs on Testbed.
	 * @param locationIn: FVector
	 * @param rotatorIn: FRotator
	 * @param quatIn: FQuat  */
	void SetDefaultDynamicsModel(const FVector& locationIn, const FVector& rotatorIn, const FQuat& quatIn);

private:
	/** @brief Check JsbSIMResource Load
	 * @return true if jsbsim resource is loaded */
	bool IsJsbSimResourceLoad();
	bool IsNSRDroneResourceLoad();

	/** [SUPERNAL / UAM] */
	FVector CalculateAcceleration(const float deltaTimeIn);
	FVector CalculateVelocity(const float deltaTimeIn);
	FVector CalculateAngularVelocity(const float deltaTimeIn);
	FVector CalculateAngularAcceleration(const float deltaTimeIn);
	bool bDebugImu;

	/** [NSR] */
	FVector CalculateAcceleration(FVector poseIn, FQuat rotIn, const float deltaTimeIn);
	FVector CalculateAngularVelocity(FVector angleIn, FQuat rotIn, const float deltaTimeIn);

	/** [Common]
	 * @brief CalculateAccelerationNoise: This will calculate the acceleration noise
	 * @param FVector& accelerometerIn */
	const FVector CalculateAccelerationNoise(const FVector& accelerometerIn);

	/* Member Variable	*/
	/* [Common]			*/
	/* [Description]: Used to compute the acceleration */
	arrayFVector_t prevLocation;
	arrayFVector_t prevRotator;
	FVector previousVelocity_;

	/* [Description]: Acceleration Result & noise */
	FVector accResult_;
	VDNoise noise;

	/* [Description]: Used to compute the acceleration */
	float prevDeltaTime;
	/* [Description]: sensor data */
	VDImuData sensorData_;

	/* [SUPERNAL / UAM] */
	const FRotator* jsbSimOrientation_;
	const FVector* jsbSimAngularVelocity_;
	const FVector* jsbSimLinearVelocity_;

	/* [NSR] */
	FVector dynamicObjLocation_;
	FVector dynamicObjAngularVelocity_;
	FQuat dynamicObjQuat_;

	/* [Default Config => TestBed] */
	FVector defaultLocation_;
	FVector defaultAngularVelocity_;
	FQuat defaultQuat_;
};
