#pragma once

#include "CoreMinimal.h"
#include "HAL/Runnable.h"
#include "HAL/ThreadSafeBool.h"

class VDSensorThreadBase : public FRunnable
{
public:
	VDSensorThreadBase(const FTimespan& threadSleepTimeIn, const TCHAR* threadNameIn);

	virtual ~VDSensorThreadBase() override;
	virtual void Process() {}
	virtual bool Init() override;
	virtual uint32 Run() override;
	virtual void Stop() override;
	void SetPaused(bool makePausedIn);

	bool IsThreadPaused();
	bool IsThreadVerifiedSuspended();
	bool ThreadHasStopped();

	bool bStopThread;

	FTimespan threadSleepTime;

protected:
	FThreadSafeBool paused;
	FThreadSafeBool isVerifiedSuspended;
	FThreadSafeBool hasStopped;

	FRunnableThread* thread = nullptr;
};
