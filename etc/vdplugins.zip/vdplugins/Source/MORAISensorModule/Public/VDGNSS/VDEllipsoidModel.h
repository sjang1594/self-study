/*
 * EllipsoidModel DB
 * EllipsoidModel : ID of EllipsoidModel
 * EllipsoidModelDB : Data of each EllipsoidModel
 * EllipsoidModelData : Data format of EllipsoidModel
 */

#pragma once
#pragma warning(disable : 4996)

#include <unordered_map>
#include <string>
#include <cstdlib>

enum class EllipsoidModel : uint8_t
{
	Airy1830 = 0,
	AiryModified,
	AustralianNational,
	Bessel1841Namibia,
	Bessel1841,
	Clarke1866,
	Clarke1880,
	EverestIndia1830,
	EverestSabahSarawak,
	EverestIndia1956,
	EverestMalaysia1969,
	EverestMalay_Sing,
	EverestPakistan,
	Fischer1960Modified,
	Helmert1906,
	Hough1960,
	Indonesian1974,
	International1924,
	Krassovsky1940,
	GRS80,
	SouthAmerican1969,
	WGS72,
	WGS84,
};

struct EllipsoidModelData
{
	EllipsoidModelData() : name(""), equatorialRadius(0.0), inverseFlattening(0.0) {};

	// TODO
	EllipsoidModelData(const char* nameIn, double equatorialRadiusIn, double inverseFlatteningIn) :
	equatorialRadius(equatorialRadiusIn),
	inverseFlattening(inverseFlatteningIn)
	{
		std::strncpy(name, nameIn, sizeof(name) - 1);
		name[sizeof(name) - 1] = '\0';
	};

	char name[20];
	double equatorialRadius;
	double inverseFlattening;
};

static const std::unordered_map<EllipsoidModel, EllipsoidModelData> ellipsoidModelDb = {
	{ EllipsoidModel::Airy1830, EllipsoidModelData { "Airy1830", 6377563.396, 299.3249646 } },
	{ EllipsoidModel::AiryModified, EllipsoidModelData { "AiryModified", 6377340.189, 299.3249646 } },
	{ EllipsoidModel::AustralianNational, EllipsoidModelData { "AustralianNational", 6378160, 298.25 } },
	{ EllipsoidModel::Bessel1841Namibia, EllipsoidModelData { "Bessel1841Namibia", 6377483.865, 299.1528128 } },
	{ EllipsoidModel::Bessel1841, EllipsoidModelData { "Bessel1841", 6377397.155, 299.1528128 } },
	{ EllipsoidModel::Clarke1866, EllipsoidModelData { "Clarke1866", 6378206.4, 294.9786982 } },
	{ EllipsoidModel::Clarke1880, EllipsoidModelData { "Clarke1880", 6378249.145, 293.465 } },
	{ EllipsoidModel::EverestIndia1830, EllipsoidModelData { "EverestIndia1830", 6377276.345, 300.8017 } },
	{ EllipsoidModel::EverestSabahSarawak, EllipsoidModelData { "EverestSabahSarawak", 6377298.556, 300.8017 } },
	{ EllipsoidModel::EverestIndia1956, EllipsoidModelData { "EverestIndia1956", 6377301.243, 300.8017 } },
	{ EllipsoidModel::EverestMalaysia1969, EllipsoidModelData { "EverestMalaysia1969", 6377295.664, 300.8017 } },
	{ EllipsoidModel::EverestMalay_Sing, EllipsoidModelData { "EverestMalay_Sing", 6377304.063, 300.8017 } },
	{ EllipsoidModel::EverestPakistan, EllipsoidModelData { "EverestPakistan", 6377309.613, 300.8017 } },
	{ EllipsoidModel::Fischer1960Modified, EllipsoidModelData { "Fischer1960Modified", 6378155, 298.3 } },
	{ EllipsoidModel::Helmert1906, EllipsoidModelData { "Helmert1906", 6378200, 298.3 } },
	{ EllipsoidModel::Hough1960, EllipsoidModelData { "Hough1960", 6378270, 297 } },
	{ EllipsoidModel::Indonesian1974, EllipsoidModelData { "Indonesian1974", 6378160, 298.247 } },
	{ EllipsoidModel::International1924, EllipsoidModelData { "International1924", 6378388, 297 } },
	{ EllipsoidModel::Krassovsky1940, EllipsoidModelData { "Krassovsky1940", 6378245, 298.3 } },
	{ EllipsoidModel::GRS80, EllipsoidModelData { "GRS80", 6378137, 298.257222101 } },
	{ EllipsoidModel::SouthAmerican1969, EllipsoidModelData { "SouthAmerican1969", 6378160, 298.25 } },
	{ EllipsoidModel::WGS72, EllipsoidModelData { "WGS72", 6378135, 298.26 } },
	{ EllipsoidModel::WGS84, EllipsoidModelData { "WGS84", 6378137, 298.257223563 } }
};
