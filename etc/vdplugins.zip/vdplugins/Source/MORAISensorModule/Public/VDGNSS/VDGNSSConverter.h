#pragma once

#include "CoreMinimal.h"

#include "VDEllipsoidModel.h"

#pragma pack(push, 1) // 1 byte alignment

struct WGSData
{
	WGSData() : longitude(0.0f), latitude(0.0f), altitude(0.0f) {}

	void SetData(double longitudeIn, double latitudeIn, double altitudeIn)
	{
		longitude = longitudeIn;
		latitude = latitudeIn;
		altitude = altitudeIn;
	}

	double longitude;
	double latitude;
	double altitude;
};

struct UTMData
{
	UTMData() : northing(0.0f), easting(0.0f), zone(0) {}

	void SetData(double northingIn, double eastingIn, int zoneIn)
	{
		northing = northingIn;
		easting = eastingIn;
		zone = zoneIn;
	}

	double northing;
	double easting;
	int zone;
};

#pragma pack(pop)

class MORAISENSORMODULE_API VDGNSSConverter
{
public:
	VDGNSSConverter() {}

	~VDGNSSConverter() {}

	static bool UtmToWgsPosition(WGSData& coreDataOut, EllipsoidModel eidIn, UTMData utmIn, double altitudeIn = 0.0);
	static bool WgsToUtmPosition(UTMData& coreDataOut, EllipsoidModel eidIn, WGSData wgsIn, double altitudeIn = 0.0);
	static bool GetEllipsoidInfo(EllipsoidModel eidIn, EllipsoidModelData& dataOut);
	static void UeToUtmPosition(
		const FVector uePositionIn, UTMData& utmPositionOut, const FVector mapUtmOriginIn = FVector(0.));
	static UTMData UeToUtmPosition(const FVector uePositionIn, const FVector mapUtmOriginIn = FVector(0.));

private:
	static inline double piGps = 4.0 * atan(1);
	static inline double deg2Rad = piGps / 180.0;
	static inline double rad2Deg = 180.0 / piGps;
	static inline const double kK0 = 0.9996;

	static void UtmToWgs(WGSData& coreDataOut, EllipsoidModelData ellipIn, UTMData utmIn, double altitudeIn = 0.0);
	static void WgsToUtm(UTMData& coreDataOut, EllipsoidModelData ellipIn, WGSData wgsIn, double altitudeIn = 0.0);
};
