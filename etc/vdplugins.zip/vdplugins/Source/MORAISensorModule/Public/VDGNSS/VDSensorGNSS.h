#pragma once

#include "VDSensorBase.h"

#include "VDGNSS/VDGNSSConverter.h"

struct MORAISENSORMODULE_API VDGnssData
{
	double longitude;
	double latitude;
	double altitude;
	double eastOffset;
	double northOffset;
};

/* TODO & Comments: SetDefaultConfig() 를 만들어서, Abstraction 을 늘리고 명세를 정확하게 했으면 좋겠습니다.
 * 여기서 DefaultConfig 는 Supernal 로 잡으시고, 호출할때 DefaultConfig 또는 NSR 이라고 하면, Config() 를
 * 불러오는 식으로 해야되는게 좋을것 같습니다.
 */
class MORAISENSORMODULE_API VDSensorGNSS : public VDSensorBase
{
public:
	VDSensorGNSS() :
	eastOffset(0.0f),
	northOffset(0.0f),
	altitude(0.0f),
	sensorData_(nullptr),
	mapUtmOrigin(nullptr),
	bIsMapUtmOriginInit(false),
	ellipsoidModelId()
	{
		/*TODO @gyshin: This is default constructor where we can set default values.
		 * but, sensorData allocating VDGnssData() is not good. */
		sensorData_ = new VDGnssData();
		SetEllipsoidModel(EllipsoidModel::WGS84);
	}

	virtual ~VDSensorGNSS() override;

	virtual void Initialize() override;
	virtual void Release() override;
	virtual void Update(const float deltaTimeIn) override;

	/** SensorData
	 * @brief It will return GNSS Data
	 * @return VDGnssData */
	VDGnssData GetSensorData() const { return *sensorData_; }

	/** SetUtmOrigin
	 * @brief It will get the UTM Origin of the Map.
	 * @remark In order to calculate the GNSS data, we need to know the UTM value of the actual location.
	 * @param originIn: const FVector* originIn */
	void SetUtmOrigin(const FVector* originIn);

	/** SetEllipsoidModel
	 * @brief Set the Ellipsoid Model for earth
	 * @param ellipsoidIdIn: EllipsoidModel ellipsoidIdIn
	 * @remark currently only WGS84 is supported. */
	void SetEllipsoidModel(EllipsoidModel ellipsoidIdIn) { ellipsoidModelId = ellipsoidIdIn; }

	EllipsoidModel GetEllipsoidModelId() const { return ellipsoidModelId; }

	FVector GetUtmOrigin();

	void SetMapOffset(double eastOffsetIn, double northOffsetIn, double altIn);

	void SetJsbSimResourceLoad(bool bisLoad) { bIsJsbSimLoad = bisLoad; }

	void SetNsrResourceLoad(bool bisLoad) { bIsJsbSimLoad = !bisLoad; }

	double eastOffset;
	double northOffset;
	double altitude;

private:
	/** HasMapUtmOrigin
	 * @brief Whether mapUtmOrigin is null or not
	 * @return bool */
	bool HasMapUtmOrigin() const { return mapUtmOrigin != nullptr; }

	/** SetDefaultMapUtmOrigin
	 * @brief Set San Fransisco Map / Duluth Utm Origin as default for Map
	 * @remark [UAM / SUPERNAL]*/
	void SetDefaultMapUtmOrigin();

	// TODO: @gyshin: 사용하고 있지 않는 함수 인데, 이걸 더 간단하게 할수 있는 방법이 뭘까요? //
	void SetMapUtmOrigin();

	/** UeToUtmPosition
	 * @brief Convert Unreal Engine Position to UTM Position
	 * @param uePositionIn: const FVector& uePositionIn
	 * @param utmPositionOut: UTMData& utmPositionOut
	 * @param mapUtmOriginIn: const FVector& mapUtmOriginIn */
	void UeToUtmPosition(
		const FVector& uePositionIn, UTMData& utmPositionOut, const FVector& mapUtmOriginIn = FVector(0.));

	/** UeToUtmPosition
	 * @brief Convert Unreal Engine Position to UTM Position
	 * @param uePositionIn: const FVector& uePositionIn
	 * @param mapUtmOriginIn: const FVector& mapUtmOriginIn */
	UTMData UeToUtmPosition(const FVector& uePositionIn, const FVector& mapUtmOriginIn = FVector(0.0));

	bool bIsJsbSimLoad = true;
	VDGnssData* sensorData_;
	const FVector* mapUtmOrigin;
	bool bIsMapUtmOriginInit;
	EllipsoidModel ellipsoidModelId;
	VDNoise gnssNoise;
};
