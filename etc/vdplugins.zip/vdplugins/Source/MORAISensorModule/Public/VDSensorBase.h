#pragma once

#include "CoreMinimal.h"

#include <string>

#include "Utils/VDALG.h"
#include "Utils/VDCommon.h"
#include "VDNoise/VDNoise.h"

#include "VDSensorThreadProcess.h"

class MORAISENSORMODULE_API VDSensorBase
{
public:
	/* 생성자에서는 포인터로 선언된 변수들을 모두 nullptr로 초기화한다. */
	VDSensorBase();

	virtual ~VDSensorBase() {}

	/* Class 내 모든 변수 값이 할당 되었고 이것이 확인될 경우 초기화한다.
	   SetWorld, SetRootComponent 등 내부 변수를 설정하는 부분이 모두 완료 된 뒤,
	   Actor BeginPlay 시 호출하는 것이 적절하다.*/
	virtual void Initialize() {}

	/* Class 소멸 직전에 호출하여 내부 변수를 소멸시켜준다.
	   Actor Release 시 호출하는 것이 적절하다. */
	virtual void Release() {};

	/* Sensor Data를 생성하는 함수.
	 * 현재는 모든 Frame에 실행할 것이므로 Actor Tick 시 호출한다. */
	virtual void Update(const float deltaTimeIn) {}; // Using in Tick

	/* 이 Sensor가 존재하는 Simulator World 변수를 가져오는 함수.
	   const로 들고 와서 이 Class 내에서 변경 불가.
	   BeginPlay에서 호출.*/
	void SetWorld(const UWorld* worldIn);

	/* 이 Sensor가 Actor에 붙었을 때 그 Actor의 RootComponent 변수를 가져오는 함수.
	  const로 들고 와서 이 Class 내에서 변경 불가. BeginPlay에서 호출.*/
	void SetRootComponent(const USceneComponent* rootIn);

	/* Async 스레드 설정 관련 */
	virtual void InitAndRunThread(const float& timespanIn) {}
	virtual void UpdateThreadProcess() {}
	virtual void ReleaseThread() {}

protected:
	bool HasRootComponent();
	bool HasWorld();

	// For DebugLog
	void InfoLog(const FString logIn);
	void WarningLog(const FString logIn);
	void ErrorLog(const FString logIn);

	const USceneComponent* rootComponent;
	const UWorld* world;
	VDSensorThreadProcess* sensorThread = nullptr;
};
