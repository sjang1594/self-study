#pragma once

#include "VDSensorBase.h"

struct MORAISENSORMODULE_API VDAltimeterData
{
	VDAltimeterData() : distance(0.0f) {}

	float distance;
};

class MORAISENSORMODULE_API VDSensorAltimeter : public VDSensorBase
{
public:
	VDSensorAltimeter() : sensorData_() {}

	virtual ~VDSensorAltimeter() override {};

	virtual void Initialize() override {}

	virtual void Release() override {}

	virtual void Update(const float deltaTimeIn) override;

	/** SensorData
	 * @brief It will return Radar Data
	 * @return VDAltimeterData */
	VDAltimeterData GetSensorData() const { return sensorData_; }

private:
	VDAltimeterData sensorData_;
};
