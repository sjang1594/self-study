﻿#pragma once

#include "CoreMinimal.h"

PRAGMA_PUSH_PLATFORM_DEFAULT_PACKING
#include "GeographicLib/Geoid.hpp"
PRAGMA_POP_PLATFORM_DEFAULT_PACKING

class MORAISENSORMODULE_API VDGeoGraphic
{
public:
	VDGeoGraphic(const VDGeoGraphic&) = delete;
	VDGeoGraphic& operator=(const VDGeoGraphic&) = delete;

	static GeographicLib::Geoid& GetInstance()
	{
		static FString libraryDirectoryPath = FPaths::ConvertRelativePathToFull(*FPaths::ProjectPluginsDir())
			+ "vdplugins/Source/ThirdParty/geographiclib/geoids/";
		static GeographicLib::Geoid geoidModel = GeographicLib::Geoid(
			TCHAR_TO_ANSI(*FString(TEXT("egm96-5"))), TCHAR_TO_ANSI(*libraryDirectoryPath), true, true);

		return geoidModel;
	}

private:
	VDGeoGraphic() {}

	~VDGeoGraphic() {}
};
