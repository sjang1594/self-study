﻿#pragma once
#include <chrono>

#include "CoreMinimal.h"
#include "HAL/Runnable.h"
#include "HAL/ThreadSafeBool.h"

class VDThread : public FRunnable
{
public:
	VDThread(const FTimespan& ThreadSleepTimeIn, const TCHAR* InThreadName);
	virtual ~VDThread() override;
	virtual bool Init() override;

	virtual void Process() {}

	virtual uint32 Run() override;
	virtual void Stop() override;

	void SetPaused(bool MakePaused);

	bool IsThreadPaused();
	bool IsThreadVerifiedSuspended();
	bool ThreadHasStopped();

	bool bStopThread;

	FTimespan threadSleepTime;

protected:
	FThreadSafeBool Paused;
	FThreadSafeBool IsVerifiedSuspended;
	FThreadSafeBool HasStopped;

	FRunnableThread* Thread = nullptr;
};
