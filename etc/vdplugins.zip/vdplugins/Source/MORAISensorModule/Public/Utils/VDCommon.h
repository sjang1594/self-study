﻿#pragma once

#include "CoreMinimal.h"

#include <cmath>

#include "Eigen/Dense"

inline const float kPIf = 2.0f * asinf(1.0f);
inline const double kPI = 2.0f * asinl(1.0f);
inline const long double kPIl = 2.0f * asinl(1.0f);
constexpr float kEpsilon = 1e-6f;

template <typename T>
T Rad2Deg(const T& angleIn)
{
	static_assert(std::is_floating_point_v<T>, "T must be floating point");
	return angleIn * 180.0f / kPIf;
}

template <typename T>
T Deg2Rad(const T& angleIn)
{
	static_assert(std::is_floating_point_v<T>, "T must be floating point");
	return angleIn * kPIf / 180.0f;
}

/** Linear RGB -> XYZ_D65 (ref. https://en.wikipedia.org/wiki/SRGB) */
inline uint8_t LinearRgb2Luminance(const uint8_t& rIn, const uint8_t& gIn, const uint8_t& bIn)
{
	return static_cast<uint8_t>(
		0.2126f * static_cast<float>(rIn) + 0.7152f * static_cast<float>(gIn) + 0.0722f * static_cast<float>(bIn));
}
