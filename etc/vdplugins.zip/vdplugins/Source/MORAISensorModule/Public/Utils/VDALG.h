#pragma once

#include "CoreMinimal.h"

#include <array>

#pragma pack(push, 1)

using arrayFVector_t = std::array<FVector, 2>; // Unreal Engine FVector
using arrayFloat_t = std::array<float, 2>;	   // C++ STL

struct AlgInfo
{
	float prevDeltaTime;
	arrayFVector_t prevLocation;
	FVector currentVelocity_;
};

struct AlgObject
{
	AlgInfo algInfo_[64];
};

#pragma pack(pop)

class MORAISENSORMODULE_API VDALG
{
public:
	VDALG() {};
	~VDALG() {};

	static void CalculateVelocity(FVector poseIn, FQuat rotIn, int currentNum, AlgObject& alg, const float deltaTimeIn);
	FVector CalculateAcceleration(FVector poseIn, FQuat rotIn, const float deltaTimeIn);
	FVector CalculateAngularVelocity(FVector anlgeIn, FQuat rotIn, const float deltaTimeIn);
	FVector CalculateAngularAcceleration(FVector anlgeIn, FQuat rotIn, const float deltaTimeIn);

private:
	float prevDeltaTime;
	arrayFVector_t prevLocation;
	arrayFVector_t prevRotator;
	arrayFloat_t prevRotatorFloat;
	arrayFloat_t prevLocationFloat;
};
