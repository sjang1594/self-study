#pragma once

#include "Kismet/KismetMathLibrary.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "Components/SceneComponent.h"

#include <vector>

#include "VDSensorBase.h"
#include "VDSensorConfig/VDLiDARSensorConfig.h"

#include "Eigen/Dense"

struct SensorPose;

class MORAISENSORMODULE_API VDSensorLiDAR : public VDSensorBase
{
public:
	VDSensorLiDAR() {};
	virtual ~VDSensorLiDAR() override;
	virtual void Initialize() override;
	virtual void Release() override;
	virtual void Update(const float deltaTimeIn) override;

	Lidar3dTemplate* GetParams() { return &lidar3dTemplate_; }

	/**
	 * @brief It will return Lidar Data
	 * @return VDRadarData */
	std::vector<float> GetSensorData() { return sensorData; }

	TEnumAsByte<Lidar3DType> SensorModel;
	TEnumAsByte<SensorFrequency> SamplingRate;
	TEnumAsByte<LaserReturnMode> ReturnMode;

	Lidar3dConfig* lidar3dConfig;
	VDNoise lidarNoise;

private:
	static inline Eigen::Vector3f ToVector3r(const FVector& vecIn, float scaleIn, bool convertToNedIn)
	{
		return Eigen::Vector3f(vecIn.X * scaleIn, vecIn.Y * scaleIn, (convertToNedIn ? -vecIn.Z : vecIn.Z) * scaleIn);
	}

	static inline Eigen::Vector3f ToLeftHandToRightHandPosition(const Eigen::Vector3f& vecIn)
	{
		return Eigen::Vector3f(vecIn.x(), -1.0 * vecIn.y(), vecIn.z());
	}

	static inline FVector ToFVector(const Eigen::Vector3f& vec, float scaleIn, bool convertFromNedIn)
	{
		return FVector(vec.x() * scaleIn, vec.y() * scaleIn, (convertFromNedIn ? -vec.z() : vec.z()) * scaleIn);
	}

	static inline Eigen::Vector3f RotateVectorReverse(
		const Eigen::Vector3f& vIn, const Eigen::Quaternionf& qIn, bool assumeUnitQuatIn)
	{
		if (!assumeUnitQuatIn)
			return qIn.inverse()._transformVector(vIn);
		else
			return qIn.conjugate()._transformVector(vIn);
	}

	// FVector to Eigen Vector3 float
	static inline Eigen::Vector3f ToLocalNed(const FVector& positionIn)
	{
		return Eigen::Vector3f(positionIn.X, positionIn.Y, positionIn.Z);
	}

	// FQuat to Eigen Quaternion float
	static inline Eigen::Quaternionf ToNed(const FQuat& qIn)
	{
		return Eigen::Quaternionf(qIn.W, -qIn.X, -qIn.Y, qIn.Z);
	}

	static inline Eigen::Vector3f TransformToBodyFrame(
		const Eigen::Vector3f& vWorldIn, const Eigen::Quaternionf& qWorldIn, bool assumeUnitQuatIn = true)
	{
		return RotateVectorReverse(vWorldIn, qWorldIn, assumeUnitQuatIn);
	}

	static inline Eigen::Vector3f TransformToBodyFrame(const Eigen::Vector3f& vWorldIn,
		const Eigen::Vector3f& bodyWorldPoseIn, const Eigen::Quaternionf& bodyWorldOrientationIn,
		bool assumeUnitQuatIn = true)
	{
		Eigen::Vector3f translated = vWorldIn - bodyWorldPoseIn;						   // translate
		return TransformToBodyFrame(translated, bodyWorldOrientationIn, assumeUnitQuatIn); // rotate
	}

	void CreateLaser();
	void SetLidarTemplate(Lidar3dConfig* SensorConfig);
	void SetLidarFrequency(Lidar3dConfig* _SensorConfig);
	void SetLidarReturnMode(Lidar3dConfig* _SensorConfig);
	void GetPointCloud(SensorPose& pose, double deltaTimeIn, std::vector<float>& pointCloudOut);
	bool ShootLaser(SensorPose& pose, float horizontalAngleIn, float verticalAngleIn, Lidar3dTemplate paramIn,
		Eigen::Vector3f& pointOut, float& intensityOut);

	std::vector<float> sensorData;
	float currentHorizontalAngle = 0.0f;
	TArray<float> laserAngles;
	Lidar3dTemplate lidar3dTemplate_;

	/**
	 * [TEMP] @ghshin Async Thread 관련 함수, 리팩토링 후 client -> vdplugin 에서 옮기게 되어
	 *  관련 함수도 따라 이동됨.
	 */
	virtual void InitAndRunThread(const float& threadSleepTimeIn) override;
	virtual void UpdateThreadProcess() override;
	virtual void ReleaseThread() override;
};
