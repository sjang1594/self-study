﻿#pragma once

/** SensorPose
 *	@brief SensorPose struct
 *	@remark It will store the sensor location and rotation */
struct SensorPose
{
	SensorPose() :
	location_ { 0.0f, 0.0f, 0.0f },
	rotation_ { 0.0f, 0.0f, 0.0f },
	quat_ { FQuat::Identity },
	transform_ { FTransform::Identity }
	{
	}

	SensorPose(const FVector& location, const FRotator& rotation, const FQuat& quat) :
	location_(location),
	rotation_(rotation),
	quat_(quat)
	{
	}

	SensorPose(const FTransform& transform) { transform_ = transform; }

	virtual ~SensorPose() = default;

	SensorPose(const SensorPose& other)
	{
		location_ = other.location_;
		rotation_ = other.rotation_;
		quat_ = other.quat_;
	}

	SensorPose& operator=(const SensorPose& other)
	{
		if (this != &other)
		{
			location_ = other.location_;
			rotation_ = other.rotation_;
			quat_ = other.quat_;
		}
		return *this;
	}

	SensorPose operator+(SensorPose& other) const
	{
		return SensorPose(location_ + other.location_, rotation_ + other.rotation_, quat_ + other.quat_);
	}

	SensorPose operator-(SensorPose& other) const
	{
		return SensorPose(location_ - other.location_, rotation_ - other.rotation_, quat_ - other.quat_);
	}

	SensorPose(SensorPose&& other) = delete;

	FVector location_;
	FRotator rotation_;
	FQuat quat_;
	FTransform transform_;
};
