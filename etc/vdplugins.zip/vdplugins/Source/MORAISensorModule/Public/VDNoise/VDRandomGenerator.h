#pragma once

#include <chrono>
#include <random>

template <typename TReturn, typename TDistribution, unsigned int Seed = 42>
class VDRandomGenerator
{
public:
	template <typename... distArgs>
	VDRandomGenerator(distArgs... distArgsIn) : distribution(distArgsIn...), engine(Seed)
	{
	}

	void seed(int valIn) { engine.seed(valIn); }

	TReturn next() { return static_cast<TReturn>(distribution(engine)); }

	void reset()
	{
		engine.seed(Seed);
		distribution.reset();
	}

private:
	TDistribution distribution;
	std::mt19937 engine;
};

typedef VDRandomGenerator<float, std::normal_distribution<double>> vdRandomGeneratorGaussianF;
typedef VDRandomGenerator<double, std::normal_distribution<double>> vdRandomGeneratorGaussianD;
