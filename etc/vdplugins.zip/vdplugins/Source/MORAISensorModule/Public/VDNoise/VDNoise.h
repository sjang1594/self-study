#pragma once

#include "CoreMinimal.h"

#include "VDRandomGenerator.h"

class MORAISENSORMODULE_API VDNoise
{
public:
	VDNoise() : rd()
	{
		rd = vdRandomGeneratorGaussianD(0, 1);
		unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
		rd.seed(seed);
	}

	virtual ~VDNoise() {};

	double GaussianNoise(double value);
	double GaussianNoise(double meanIn, double stdDevIn);
	double BiasInstabilityGMNoise(
		double lastGmNoiseIn, double correlationTimeIn, double gmNoiseMeanIn, double gmStdevIn, double dtIn);
	double RandomWalkNoise(double lastRwNoiseIn, double rwNoiseMeanIn, double rwStdDevIn, double dtIn);
	double WhiteNoise(double whiteNoiseMeanIn, double wnStdDevIn, double dtIn);
	VDRandomGenerator<double, std::normal_distribution<double>> rd;
};
