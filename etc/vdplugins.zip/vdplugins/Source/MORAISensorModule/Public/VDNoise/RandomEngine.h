﻿#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"

#include <random>
#include "RandomEngine.generated.h"

UCLASS()

class MORAISENSORMODULE_API URandomEngine : public UObject
{
	GENERATED_BODY()

public:
	static uint64 GeneratedRandomId();

	static uint32 GenerateRandomSeed();

	int32 GeneratedSeed();
	void Seed(int32 seedIn);

	float GetUniformFloat();
	float GetUniformFloatRange(float minIn, float maxIn);
	int32 GetUniformIntRange(int32 minIn, int32 maxIn);
	bool GetUniformBool();
	bool GetBernoulliDistribution(float pIn);
	int32 GetBinomialDistribution(int32 tIn, float pIn);
	int32 GetPoissonDistribution(float meanIn);
	float GetExponentialDistribution(float lambdaIn);
	float GetNormalDistribution(float meanIn, float stdDevIn);
	bool GetBoolWidthWeight(float weightIn);
	int32 GetIntWidthWeight(const TArray<float>& weightsOut);

	template <typename T>
	auto& PickOne(const TArray<T>& array);

	template <typename T>
	auto Shuffle(TArray<T>& array);

private:
	std::minstd_rand engine;
};

template <typename T>
auto& URandomEngine::PickOne(const TArray<T>& arrayOut)
{
	return arrayOut[GetUniformIntRange(0, arrayOut.Num() - 1)];
}

template <typename T>
auto URandomEngine::Shuffle(TArray<T>& arrayOut)
{
	std::shuffle(arrayOut.GetData(), arrayOut.GetData() + arrayOut.Num(), engine);
}
