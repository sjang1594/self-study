﻿#pragma once

/* This will store default config file of sensors */
#include "CoreMinimal.h"

struct VDRadarParam
{
	// [TEMP]: UAM
	void SetConfig(const float& hFovIn, const float& vFovIn, const float& minDistanceIn, const float& maxDistanceIn)
	{
		hFov = hFovIn;
		vFov = vFovIn;
		minDistance = minDistanceIn;
		maxDistance = maxDistanceIn;
	}

	void SetNoise(const float& meanIn = 0.0f, const float& stdDevIn = 0.0f)
	{
		mean = meanIn;
		stdDev = stdDevIn;
	}

	float minDistance = 1.0f;	// Default
	float maxDistance = 150.0f; // Default
	float hFov = 90.0f;
	float vFov = 5.0f;
	float horizontalAngleStart = -45.0f;
	float verticalAngleStart = -2.5f;
	float dtAzimuthAngle = 1.0f;
	float dtElevationAngle = 1.0f;

	// Noise Setting
	float mean = 0.0f;
	float stdDev = 0.0f;

	// TODO: Add Sensor Period
};
