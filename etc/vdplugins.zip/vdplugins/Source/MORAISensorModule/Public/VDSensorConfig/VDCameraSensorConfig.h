﻿#pragma once

/* This will store default config file of sensors */
#include "CoreMinimal.h"
#include "Engine/TextureRenderTarget2D.h"

namespace VD_SENSOR
{
	enum class CameraType : int
	{
		// "TOTAL" MUST be located at the end.
		RGB,
		DEPTH,
		TOTAL
	};

	enum class MaterialType : int
	{
		// "TOTAL" MUST be located at the end.
		DISTORTION,
		DEPTH,
		CFA,
		NO_TONEMAP,
		TOTAL
	};

	const TMap<MaterialType, const TCHAR*> materialFilePathMap = {
		{ MaterialType::DISTORTION,
			TEXT(
				"/Script/Engine.MaterialInstanceConstant'/vdplugins/Camera/PP_Material/PP_DistortionMat_Inst.PP_DistortionMat_Inst'") },
		{ MaterialType::DEPTH,
			TEXT(
				"/Script/Engine.MaterialInstanceConstant'/vdplugins/Camera/PP_Material/PP_DepthMat_Inst.PP_DepthMat_Inst'") },
		{ MaterialType::CFA,
			TEXT(
				"/Script/Engine.MaterialInstanceConstant'/vdplugins/Camera/PP_Material/PP_ColorFilterArrayMat_Inst.PP_ColorFilterArrayMat_Inst'") },
		{ MaterialType::NO_TONEMAP,
			TEXT(
				"/Script/Engine.MaterialInstanceConstant'/vdplugins/Camera/PP_Material/PP_DisablingToneMapperMat_Inst.PP_DisablingToneMapperMat_Inst'") }
	};

	// ColorFilterArray is a 2x2 pixel filter that ordered like Z
	enum class ColorFilterArray : int
	{
		NONE = 0,
		RGGB = 1,
		BGGR = 2,
		GBRG = 3,
		GRBG = 4,
		RCCC = 5,
		RCCB = 6,
		RYYCy = 7
	};

	struct VDBrownConradyLensDistortionParams
	{
		explicit VDBrownConradyLensDistortionParams(const float& k1In = 0.0f, const float& k2In = 0.0f,
			const float& k3In = 0.0f, const float& p1In = 0.0f, const float& p2In = 0.0f) :
		radial { k1In, k2In, k3In },
		tangential { p1In, p2In }
		{
		}

		FVector3f radial;
		FVector2f tangential;
	};

	namespace CameraSettings
	{
		struct RgbCamera
		{
		public:
			static void InitTextureRenderTarget(
				const Eigen::Vector2i& resolutionIn, TObjectPtr<UTextureRenderTarget2D> textureTargetOut)
			{
				textureTargetOut->bGPUSharedFlag = true;
				textureTargetOut->bAutoGenerateMips = false;
				textureTargetOut->CompressionSettings = TextureCompressionSettings::TC_Default;
				textureTargetOut->TargetGamma = GEngine->GetDisplayGamma();
				textureTargetOut->AddressX = TA_Clamp;
				textureTargetOut->AddressY = TA_Clamp;
				textureTargetOut->SRGB = false;
				textureTargetOut->RenderTargetFormat = ETextureRenderTargetFormat::RTF_RGBA8;
				textureTargetOut->InitCustomFormat(resolutionIn[0], resolutionIn[1], EPixelFormat::PF_B8G8R8A8, false);
				textureTargetOut->UpdateResourceImmediate(true);
			}

			static void ApplyMaterialInstanceDynamic(const TArray<TObjectPtr<UMaterialInstanceDynamic>>& matInstanceIn,
				FPostProcessSettings& postProcessingOut)
			{
				postProcessingOut.AddBlendable(
					matInstanceIn[static_cast<int>(VD_SENSOR::MaterialType::DISTORTION)], 1.0f);
				postProcessingOut.AddBlendable(matInstanceIn[static_cast<int>(VD_SENSOR::MaterialType::DEPTH)], 0.0f);
				postProcessingOut.AddBlendable(matInstanceIn[static_cast<int>(VD_SENSOR::MaterialType::CFA)], 1.0f);
				postProcessingOut.AddBlendable(
					matInstanceIn[static_cast<int>(VD_SENSOR::MaterialType::NO_TONEMAP)], 0.0f);
			}
		};

		// Get the depth image encoded rgba uint8 from float16
		struct DepthCamera
		{
		public:
			static void InitTextureRenderTarget(
				const Eigen::Vector2i& resolutionIn, TObjectPtr<UTextureRenderTarget2D> textureTargetOut)
			{
				textureTargetOut->bGPUSharedFlag = true;
				textureTargetOut->bAutoGenerateMips = false;
				textureTargetOut->CompressionSettings = TextureCompressionSettings::TC_Default;
				textureTargetOut->TargetGamma = GEngine->GetDisplayGamma();
				textureTargetOut->AddressX = TA_Clamp;
				textureTargetOut->AddressY = TA_Clamp;
				textureTargetOut->SRGB = false;
				// textureTargetOut->RenderTargetFormat = ETextureRenderTargetFormat::RTF_RGBA16f;
				textureTargetOut->RenderTargetFormat = ETextureRenderTargetFormat::RTF_RGBA8;
				// textureTargetOut->InitCustomFormat(resolutionIn[0], resolutionIn[1], EPixelFormat::PF_FloatRGBA,
				// true);
				textureTargetOut->InitCustomFormat(resolutionIn[0], resolutionIn[1], EPixelFormat::PF_B8G8R8A8, true);
				textureTargetOut->UpdateResourceImmediate(true);
			}

			static void ApplyMaterialInstanceDynamic(const TArray<TObjectPtr<UMaterialInstanceDynamic>>& matInstanceIn,
				FPostProcessSettings& postProcessingOut)
			{
				postProcessingOut.AddBlendable(
					matInstanceIn[static_cast<int>(VD_SENSOR::MaterialType::DISTORTION)], 1.0f);
				postProcessingOut.AddBlendable(matInstanceIn[static_cast<int>(VD_SENSOR::MaterialType::DEPTH)], 1.0f);
				postProcessingOut.AddBlendable(matInstanceIn[static_cast<int>(VD_SENSOR::MaterialType::CFA)], 0.0f);
				postProcessingOut.AddBlendable(
					matInstanceIn[static_cast<int>(VD_SENSOR::MaterialType::NO_TONEMAP)], 1.0f);
			}
		};

		struct Filmback
		{
			Filmback(const float& sensorWidthIn = 36.0f, const float& sensorHeightIn = 24.0f) :
			sensorWidth(sensorWidthIn),
			sensorHeight(sensorHeightIn)
			{
				RecalcSensorAspectRatio();
			}

			bool operator==(const Filmback& Other) const
			{
				return (sensorWidth == Other.sensorWidth) && (sensorHeight == Other.sensorHeight);
			}

			bool operator!=(const Filmback& Other) const { return !operator==(Other); }

			void RecalcSensorAspectRatio()
			{
				sensorAspectRatio = (sensorHeight > 0.0f) ? (sensorWidth / sensorHeight) : 0.0f;
			}

			float sensorWidth, sensorHeight; // unit: mm
			float sensorAspectRatio;
		};

		struct CameraLens
		{
			CameraLens(const float& minFocalLengthIn = 4.0f, const float& maxFocalLength = 1000.0f,
				const float& minFStopIn = 1.2f, const float& maxFStopIn = 22.0f,
				const float& minimumFocusDistanceIn = 15.0f) :
			minFocalLength(minFocalLengthIn),
			maxFocalLength(maxFocalLength),
			minFStop(minFStopIn),
			maxFStop(maxFStopIn),
			minimumFocusDistance(minimumFocusDistanceIn)
			{
			}

			bool operator==(const CameraLens& Other) const
			{
				return (minFocalLength == Other.minFocalLength) && (maxFocalLength == Other.maxFocalLength)
					&& (minFStop == Other.minFStop) && (maxFStop == Other.maxFStop)
					&& (minimumFocusDistance == Other.minimumFocusDistance);
			}

			float minFocalLength, maxFocalLength; // unit: mm
			float minFStop, maxFStop;
			float minimumFocusDistance; // unit: mm
		};
	} // namespace CameraSettings
} // namespace VD_SENSOR
