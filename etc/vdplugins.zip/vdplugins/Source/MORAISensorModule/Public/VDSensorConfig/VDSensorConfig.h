﻿#pragma once

#include "CoreMinimal.h"

namespace VD_SENSOR
{
	enum class SensorType
	{
		None,
		Camera,
		Lidar3D,
		Lidar2D,
		GPS,
		IMU,
		Radar,
		// FishEyeCamera,
		Ultrasonic,
		GroundTruth,
		// Velarray,
		LightSensor,
		DelphiRadar,
		END
	};

	class SensorConfig
	{
		std::string sensorName;
		SensorType sensorType;
	};
} // namespace VD_SENSOR
