﻿#pragma once

/* This will store default config file of sensors */
#include "CoreMinimal.h"
#include "VDSensorConfig.h"

#include <vector>
#include "Eigen/Dense"

using namespace VD_SENSOR;

#define FIRING_CYCLE 55296 // nanosecond

enum Lidar3DType
{
	CH16,
	CH16HiRes,
	CH32,
	CH64,
	CH128,
	Ouster64,
	SOS_ML_1,
	SOS_ML_2,
	Ouster32OS1,
	Ouster64OS1,
	H800_Left,
	// Velarray 8ch Left
	H800_Right,
	// Velarray 8ch Right
	M1600,
	// Velarray 16ch
	VLP32c,
	Custom
};

enum SensorFrequency
{
	HZ05,
	HZ10,
	HZ15,
	HZ20,
	HZ25
};

enum LaserReturnMode
{
	Strongest,
	LastReturn,
	DualReturn
};

class Lidar3dConfig : VD_SENSOR::SensorConfig
{
public:
	Lidar3DType lidar3dType;

	SensorFrequency lidar3dFrequency;

	LaserReturnMode lidar3dReturnMode;

	float SensorPeriod;

	float isVizPointCloud;

	int measurementPerRotation;

	Lidar3dConfig()
	{
		lidar3dType = Lidar3DType::CH64;
		lidar3dFrequency = SensorFrequency::HZ10;
		lidar3dReturnMode = LaserReturnMode::Strongest;
		SensorPeriod = 10.0f; // hz
		isVizPointCloud = true;
		measurementPerRotation = 20880;
	}
};

// MORAI LiDAR Template
struct Lidar3dTemplate
{
	std::string name;
	unsigned int numLaserEmitter;
	unsigned int numDataBlocks;
	unsigned int numDataChannel; // 1Block have 32 DataChannels
	float minDistance;
	float maxDistance;
	float rotationFrequency;
	float angleResolution;
	int measurementsPerRotation;
	float fieldOfView;
	std::vector<float> verticalRayAngles; // std::array로 변경
	std::vector<float> azimuthOffset;
	std::vector<float> azimuthAngle;
	std::vector<float> rotCorrections;
	float centerAngle;
	int textureHeightFactor;
	int textureWidthFactor;
	Eigen::Vector3f sensorOffset; // Eigen Vector로 변경
	float nearClipPlane;
	float VelodyneUnit;

	float FiringSequenceTime;
};
