#pragma once

#include "CoreMinimal.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"

#include "Utils/VDALG.h"
#include "VDNoise/VDNoise.h"
#include "VDRADAR/VDRADARInfo.h"

class MORAISENSORMODULE_API VDIntruderDetector
{
public:
	VDIntruderDetector() :
	mean(0.0f),
	stdev(0.0f),
	mapUtmOrigin(nullptr),
	ellipsoidModelId(),
	algObject_(),
	intruderDetectionPacket_(),
	intruderDetectNoise(nullptr),
	rootComponent(nullptr),
	world(nullptr),
	numObj(0),
	radius(3.7f * NMITOMETER),
	dot(0.0f),
	angle(0.0f),
	distance(0.0f),
	turnAngle(0.0f),
	directionAngle(0.0f),
	pitchAngle(0.0f)
	{
	}

	~VDIntruderDetector();

	void Initialize();
	void Release();
	void Update(const float deltaTimeIn);
	void SetWorld(const UWorld* worldIn);
	void SetRootComponent(const USceneComponent* rootIn);

	IntruderDetectionPacket GetGtData() const { return intruderDetectionPacket_; }

	WGSData CalculateLongLat(const FVector* mapOriginIn, FVector targetPoseIn, WGSData* wgsPositionIn);

	void SetTargetObjectRotation(FRotator targetObjRotIn) {} // TODO: @gyshin: necessary?

	float mean;
	float stdev;

private:
	void SetEllipsoidModel(EllipsoidModel ellipsoidIdIn) { ellipsoidModelId = ellipsoidIdIn; }

	void CalculateVelocity(FVector poseIn, FQuat rotIn, int currentNumIn, AlgObject& algOut, const float deltaTimeIn) {}

	bool HasRootComponent();
	bool HasWorld();

	// For DebugLog
	void InfoLog(const FString logIn);
	void WarningLog(const FString logIn);
	void ErrorLog(const FString logIn);

	const FVector* mapUtmOrigin;
	EllipsoidModel ellipsoidModelId;
	AlgObject algObject_;
	IntruderDetectionPacket intruderDetectionPacket_;
	VDNoise* intruderDetectNoise;

	const USceneComponent* rootComponent;
	const UWorld* world;

	FVector location_;
	FVector rot_;
	FQuat quat_;
	FVector velocity_;
	FVector acceleration_;
	FVector angularVelocity_;
	FVector angularAcceleration_;
	FRotator targetObjRot_;

	TArray<AActor*> ignoreActors;
	TArray<AActor*> outActors;
	TArray<AActor*> attachedActors;

	FVector sensorOrigin;
	FVector sensorForwardVector;
	FVector closestPoint;

	int numObj;
	float radius;
	float dot;
	float angle;
	float distance;
	float turnAngle;
	float directionAngle;
	float pitchAngle;
};
