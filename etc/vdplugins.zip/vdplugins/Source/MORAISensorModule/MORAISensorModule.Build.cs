using System.IO;
using UnrealBuildTool;

public class MORAISensorModule : ModuleRules
{
	public MORAISensorModule(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		bEnableExceptions = true; // win64
		// if (Target.Platform == UnrealTargetPlatform.Linux)
		// 	bEnableExceptions = false;

		PublicIncludePaths.AddRange(
			new string[]
			{
				Path.Combine(ModuleDirectory, "../ThirdParty/eigen3"),
				Path.Combine(ModuleDirectory, "../ThirdParty/geographiclib/include"),
			}
		);

		PrivateIncludePaths.AddRange(
			new string[]
			{
				// ... add other private include paths required here ...
			}
		);


		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core", "CoreUObject", "Engine", // Shader dependent
				"Projects",
				"ImageWrapper",
				"RenderCore", // Shader dependent
				"RHI", // Shader dependent
				"JSBSimFlightDynamicsModel",
				"GeoReferencing", "ThirdParty",
				// ... add other public dependencies that you statically link with here ...
			}
		);

		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"ThirdParty"
				// ... add private dependencies that you statically link with here ...	
			}
		);


		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
				// ... add any modules that your module loads dynamically here ...
			}
		);
	}
}