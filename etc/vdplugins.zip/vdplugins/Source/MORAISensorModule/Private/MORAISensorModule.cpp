#include "MORAISensorModule.h"
#include "Interfaces/IPluginManager.h"
#include "Misc/Paths.h"
#include "ShaderCore.h"

#define LOCTEXT_NAMESPACE "FMORAISensorModuleModule"

void FMORAISensorModuleModule::StartupModule() {}

void FMORAISensorModuleModule::ShutdownModule() {}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FMORAISensorModuleModule, MORAISensorModule)
