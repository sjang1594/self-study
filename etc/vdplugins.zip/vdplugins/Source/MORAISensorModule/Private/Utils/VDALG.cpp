#include "Utils/VDALG.h"

void VDALG::CalculateVelocity(FVector poseIn, FQuat rotIn, int currentNumIn, AlgObject& algOut, const float deltaTimeIn)
{
	constexpr float kToMeters = 1e-2;
	FVector currentLocation_ = poseIn;
	FVector vY2_ = algOut.algInfo_[currentNumIn].prevLocation[0];
	FVector vY1_ = algOut.algInfo_[currentNumIn].prevLocation[1];
	FVector vY0_ = currentLocation_;

	float h1 = deltaTimeIn;									// x3 -x2
	float h2 = algOut.algInfo_[currentNumIn].prevDeltaTime; // x2 - x1
	float h1AndH2 = h2 + h1;								// x3 - x1

	FVector A_ = (vY2_ * h1) / (h2 * h1AndH2);
	FVector B_ = (vY1_ * (h1 + h2)) / (h2 * h1);
	FVector C_ = (vY0_ * (2 * h1 + h2)) / (h1 * h1AndH2);

	FVector vectorVelocity_ = (A_ - B_ + C_);

	// [Temp]
	// FQuat ImuRotation = _rot;
	// FVectorVelocity = ImuRotation.UnrotateVector(FVectorVelocity);

	algOut.algInfo_[currentNumIn].prevLocation[0] = algOut.algInfo_[currentNumIn].prevLocation[1];
	algOut.algInfo_[currentNumIn].prevLocation[1] = currentLocation_;
	algOut.algInfo_[currentNumIn].prevDeltaTime = deltaTimeIn;
	algOut.algInfo_[currentNumIn].currentVelocity_ = vectorVelocity_ * kToMeters;
}

FVector VDALG::CalculateAcceleration(FVector poseIn, FQuat rotIn, const float deltaTimeIn)
{
	constexpr float kToMeters = 1e-2;

	constexpr float kGravity = 9.81f;

	const FVector kCurrentLocation_ = poseIn;

	const FVector kY2_ = prevLocation[0];
	const FVector kY1_ = prevLocation[1];
	const FVector kY0_ = kCurrentLocation_;
	const float kH1 = deltaTimeIn;	 // x3 -x2
	const float kH2 = prevDeltaTime; // x2 - x1

	const float kH1AndH2 = kH2 + kH1; // x3 - x1
	const FVector kA_ = kY1_ / (kH1 * kH2);
	const FVector kB_ = kY2_ / (kH2 * (kH1AndH2));
	const FVector kC_ = kY0_ / (kH1 * (kH1AndH2));

	FVector vectorAccelerometer_ = kToMeters * -2.0f * (kA_ - kB_ - kC_);
	vectorAccelerometer_.Z += kGravity;

	FQuat imuRotation_ = rotIn;
	vectorAccelerometer_ = imuRotation_.UnrotateVector(vectorAccelerometer_);

	prevLocation[0] = prevLocation[1];
	prevLocation[1] = kCurrentLocation_;
	prevDeltaTime = deltaTimeIn;

	return vectorAccelerometer_;
}

FVector VDALG::CalculateAngularVelocity(FVector angleIn, FQuat rotIn, const float deltaTimeIn)
{
	constexpr float kToMeters = 1e-2;

	const FVector kCurrentAngle_ = angleIn;

	const FVector kVY2_ = prevRotator[0];
	const FVector kVY1_ = prevRotator[1];
	const FVector kVY0_ = kCurrentAngle_;

	const float kH1 = deltaTimeIn;	  // x3 -x2
	const float kH2 = prevDeltaTime;  // x2 - x1
	const float kH1AndH2 = kH2 + kH1; // x3 - x1

	const FVector kA_ = (kVY2_ * kH1) / (kH2 * kH1AndH2);
	const FVector kB_ = (kVY1_ * (kH1 + kH2)) / (kH2 * kH1);
	const FVector kC_ = (kVY0_ * (2 * kH1 + kH2)) / (kH1 * kH1AndH2);

	FVector vectorAngularVelocity_ = kToMeters * (kA_ - kB_ + kC_);
	FQuat imuRotation_ = rotIn;

	vectorAngularVelocity_ = imuRotation_.UnrotateVector(vectorAngularVelocity_);

	prevRotator[0] = prevRotator[1];
	prevRotator[1] = kCurrentAngle_;

	prevDeltaTime = deltaTimeIn;

	return vectorAngularVelocity_;
}

FVector VDALG::CalculateAngularAcceleration(FVector angleIn, FQuat rotIn, const float deltaTimeIn)
{
	constexpr float kToMeters = 1e-2;
	const FVector kCurrentAngle_ = angleIn;
	const FVector kY2_ = prevRotator[0];
	const FVector kY1_ = prevRotator[1];
	const FVector kY0_ = kCurrentAngle_;
	const float kH1 = deltaTimeIn;	 // x3 -x2
	const float kH2 = prevDeltaTime; // x2 - x1

	const float kH1AndH2 = kH2 + kH1; // x3 - x1
	const FVector kA_ = kY1_ / (kH1 * kH2);
	const FVector kB_ = kY2_ / (kH2 * (kH1AndH2));
	const FVector kC_ = kY0_ / (kH1 * (kH1AndH2));
	FVector vectorAngularAccelerometer_ = kToMeters * -2.0f * (kA_ - kB_ - kC_);

	FQuat imuRotation_ = rotIn;
	//_rootComp->GetComponentTransform().GetRotation();
	vectorAngularAccelerometer_ = imuRotation_.UnrotateVector(vectorAngularAccelerometer_);

	prevRotator[0] = prevRotator[1];
	prevRotator[1] = kCurrentAngle_;
	prevDeltaTime = deltaTimeIn;

	return vectorAngularAccelerometer_;
}
