﻿#include "Utils/VDThread.h"

VDThread::VDThread(const FTimespan& ThreadSleepTimeIn, const TCHAR* InThreadName) :
bStopThread(false),
threadSleepTime(ThreadSleepTimeIn)
{
	Paused.AtomicSet(false);
	HasStopped.AtomicSet(true);

	Thread = FRunnableThread::Create(
		this, InThreadName, 0U, EThreadPriority::TPri_TimeCritical, FPlatformAffinity::GetPoolThreadMask());
	if (Thread == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Thread has not been created in Constructor"))
	}
}

VDThread::~VDThread()
{
	if (Thread != nullptr)
	{
		Thread->Kill(true);
		delete Thread;
		Thread = nullptr;

		UE_LOG(LogTemp, Warning, TEXT("Thread has been deleted in Destructor"));
	}
}

bool VDThread::Init()
{
	return true;
}

uint32 VDThread::Run()
{
	HasStopped.AtomicSet(false);

	while (!bStopThread)
	{
		if (Paused)
		{
			if (!IsVerifiedSuspended)
			{
				IsVerifiedSuspended.AtomicSet(true);
			}

			//! Ready to resume on a moments notice though!
			FPlatformProcess::Sleep(threadSleepTime.GetTotalSeconds());

			continue;
		}

		Process();
	}

	HasStopped.AtomicSet(true);
	return 0;
}

void VDThread::Stop()
{
	SetPaused(true);
	bStopThread = true;
	FRunnable::Stop();
}

void VDThread::SetPaused(bool MakePaused)
{
	Paused.AtomicSet(MakePaused);
	if (!MakePaused)
	{
		IsVerifiedSuspended.AtomicSet(false);
	}
}

bool VDThread::IsThreadPaused()
{
	return Paused;
}

bool VDThread::IsThreadVerifiedSuspended()
{
	return IsVerifiedSuspended;
}

bool VDThread::ThreadHasStopped()
{
	return HasStopped;
}
