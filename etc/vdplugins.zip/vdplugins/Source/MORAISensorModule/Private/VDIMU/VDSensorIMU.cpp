#include "VDIMU/VDSensorIMU.h"

typedef VDSensorBase Super;

void VDSensorIMU::Initialize()
{
	Super::Initialize();
}

void VDSensorIMU::Release()
{
	Super::Release();
}

void VDSensorIMU::Update(const float deltaTimeIn)
{
	Super::Update(deltaTimeIn);

	if (!HasRootComponent())
	{
		UE_LOG(LogTemp, Log, TEXT("RootComponent of IMU Sensor is not defined"));
	}

	/* [SUPERNAL / UAM] */
	if (IsJsbSimResourceLoad())
	{
		// Set Pose, Orientation //
		// FVector pose_ = rootComponent->GetRelativeLocation();
		// FVector angle_ = {
		//	rootComponent->GetRelativeRotation().Roll,
		//	rootComponent->GetRelativeRotation().Pitch,
		//	rootComponent->GetRelativeRotation().Yaw};

		// FQuat quat_ = rootComponent->GetRelativeRotation().Quaternion();

		// const FVector acceleration = CalculateAcceleration(deltaTimeIn);
		// const FVector velocity = CalculateVelocity(deltaTimeIn);
		// const FVector angularVelocity = CalculateAngularVelocity(deltaTimeIn);
		// const FVector angularAcceleration = CalculateAngularAcceleration(deltaTimeIn);
		// if(bDebugImu)
		//{
		//	FString debugMessage;
		//	debugMessage += FString::Printf(TEXT("Velocity : %f, %f, %f"), velocity.X, velocity.Y, velocity.Z) +
		// LINE_TERMINATOR;
		//
		// debugMessage += FString::Printf(TEXT("ToTal Velocity : %f"), velocity.Size() *
		// METERTOFEET) + LINE_TERMINATOR;
		//
		// debugMessage += FString::Printf(TEXT("Acceleration : %f, %f, %f"), acceleration.X, acceleration.Y,
		// acceleration.Z) + LINE_TERMINATOR;
		//
		// debugMessage += FString::Printf(TEXT("AngularVelocity : %f, %f, %f"), angularVelocity.X, angularVelocity.Y,
		// angularVelocity.Z) + LINE_TERMINATOR;
		// debugMessage += FString::Printf(TEXT("AngularAcceleration : %f, %f, %f"), angularAcceleration.X,
		// angularAcceleration.Y, angularAcceleration.Z) + LINE_TERMINATOR;
		// const FVector2D textScale = FVector2D::UnitVector * 2;
		// GEngine->AddOnScreenDebugMessage(1, 0, FColor::Red, debugMessage, false, textScale);
		// }

		// Fill the orientation data into sensor data //
		// sensorData_.orientation_ = rootComponent->GetRelativeRotation().Quaternion();
		// Fill the angular velocity data into sensor data //
		// sensorData_.angularVelocity_ = CalculateAngularVelocity(angle_, quat_, deltaTimeIn);

		// JSBSim
		sensorData_.orientation_ = jsbSimOrientation_->Quaternion();
		sensorData_.angularVelocity_ = *jsbSimAngularVelocity_;
		sensorData_.linearAcceleration_ = (*jsbSimLinearVelocity_ - previousVelocity_) / deltaTimeIn;
		previousVelocity_ = *jsbSimLinearVelocity_;
		// Calculate Acceleration //
		// accResult_ = CalculateAcceleration(pose_, quat_, deltaTimeIn);
	}
	else
	{
		// [NSR]
		// Set Pose, Orientation //
		FVector pose_ = dynamicObjLocation_;
		FVector angleVelocity_ = dynamicObjAngularVelocity_;
		FQuat quat_ = dynamicObjQuat_;
		// Fill the orientation data into sensor data //
		sensorData_.orientation_ = quat_;
		// Fill the angular velocity data into sensor data //
		sensorData_.angularVelocity_ = angleVelocity_;
		// Calculate Acceleration //
		accResult_ = CalculateAcceleration(pose_, quat_, deltaTimeIn);

		// Push the acceleration data into sensor data //
		sensorData_.linearAcceleration_ = accResult_;
		UE_LOG(LogTemp, Log, TEXT("IMU AccResult : %f, %f, %f"), accResult_.X, accResult_.Y, accResult_.Z);
	}

	UE_LOG(LogTemp, Log, TEXT("IMU angularVelocity : %f, %f, %f"), sensorData_.angularVelocity_.X,
		sensorData_.angularVelocity_.Y, sensorData_.angularVelocity_.Z);
}

// [SUPERNAL / UAM]
void VDSensorIMU::SetDynamicsModel(
	const FRotator* orientationIn, const FVector* angularVelocityIn, const FVector* linearVelocityIn)
{
	jsbSimOrientation_ = orientationIn;
	jsbSimAngularVelocity_ = angularVelocityIn;
	jsbSimLinearVelocity_ = linearVelocityIn;
}

// [NSR]
void VDSensorIMU::SetDynamicsModel(const FVector locationIn, const FVector angularVelocityIn, FQuat quatIn)
{
	dynamicObjLocation_ = locationIn;
	dynamicObjAngularVelocity_ = angularVelocityIn;
	dynamicObjQuat_ = quatIn;
}

void VDSensorIMU::SetDefaultDynamicsModel(const FVector& locationIn, const FVector& rotatorIn, const FQuat& quatIn)
{
	defaultLocation_ = locationIn;
	defaultAngularVelocity_ = rotatorIn;
	defaultQuat_ = quatIn;
}

// [SUPERNAL / UAM]
FVector VDSensorIMU::CalculateAcceleration(const float deltaTimeIn)
{
	constexpr float kToMeters = 1e-2;
	constexpr float kGravity = 9.81f;

	const FVector kCurrentLocation_ = rootComponent->GetComponentLocation();

	const FVector kY2_ = prevLocation[0];
	const FVector kY1_ = prevLocation[1];
	const FVector kY0_ = kCurrentLocation_;
	const float kH1 = deltaTimeIn;	 // x3 -x2
	const float kH2 = prevDeltaTime; // x2 - x1

	const float kH1AndH2 = kH2 + kH1; // x3 - x1
	const FVector kA_ = kY1_ / (kH1 * kH2);
	const FVector kB_ = kY2_ / (kH2 * (kH1AndH2));
	const FVector kC_ = kY0_ / (kH1 * (kH1AndH2));
	FVector fVectorAccelerometer_ = kToMeters * -2.0f * (kA_ - kB_ - kC_);

	fVectorAccelerometer_.Z += kGravity;

	FQuat imuRotation_ = rootComponent->GetComponentTransform().GetRotation();
	fVectorAccelerometer_ = imuRotation_.UnrotateVector(fVectorAccelerometer_);

	prevLocation[0] = prevLocation[1];
	prevLocation[1] = kCurrentLocation_;
	prevDeltaTime = deltaTimeIn;

	return fVectorAccelerometer_;
}

// [SUPERNAL / UAM]
FVector VDSensorIMU::CalculateVelocity(const float deltaTimeIn)
{
	constexpr float kToMeters = 1e-2;

	const FVector kCurrentLocation_ = rootComponent->GetComponentLocation();

	const FVector kVY2_ = prevLocation[0];
	const FVector kVY1_ = prevLocation[1];
	const FVector kVY0_ = kCurrentLocation_;

	const float kH1 = deltaTimeIn;	  // x3 -x2
	const float kH2 = prevDeltaTime;  // x2 - x1
	const float kH1AndH2 = kH2 + kH1; // x3 - x1

	const FVector kA_ = (kVY2_ * kH1) / (kH2 * kH1AndH2);
	const FVector kB_ = (kVY1_ * (kH1 + kH2)) / (kH2 * kH1);
	const FVector kC_ = (kVY0_ * (2 * kH1 + kH2)) / (kH1 * kH1AndH2);

	FVector vectorVelocity_ = kToMeters * (kA_ - kB_ + kC_);

	FQuat imuRotation_ = rootComponent->GetComponentTransform().GetRotation();

	vectorVelocity_ = imuRotation_.UnrotateVector(vectorVelocity_);

	prevLocation[0] = prevLocation[1];
	prevLocation[1] = kCurrentLocation_;

	prevDeltaTime = deltaTimeIn;

	return vectorVelocity_;
}

// [SUPERNAL / UAM]
FVector VDSensorIMU::CalculateAngularVelocity(const float deltaTimeIn)
{
	constexpr float kToMeters = 1e-2;
	const FVector kCurrentLocation_ = { rootComponent->GetComponentRotation().Roll,
		rootComponent->GetComponentRotation().Pitch, rootComponent->GetComponentRotation().Yaw };

	const FVector kVY2_ = prevRotator[0];
	const FVector kVY1_ = prevRotator[1];
	const FVector kVY0_ = kCurrentLocation_;

	const float kH1 = deltaTimeIn;	  // x3 -x2
	const float kH2 = prevDeltaTime;  // x2 - x1
	const float kH1AndH2 = kH2 + kH1; // x3 - x1

	const FVector kA_ = (kVY2_ * kH1) / (kH2 * kH1AndH2);
	const FVector kB_ = (kVY1_ * (kH1 + kH2)) / (kH2 * kH1);
	const FVector kC_ = (kVY0_ * (2 * kH1 + kH2)) / (kH1 * kH1AndH2);

	FVector vectorAngularVelocity_ = kToMeters * (kA_ - kB_ + kC_);

	FQuat imuRotation_ = rootComponent->GetComponentTransform().GetRotation();

	vectorAngularVelocity_ = imuRotation_.UnrotateVector(vectorAngularVelocity_);

	prevRotator[0] = prevRotator[1];
	prevRotator[1] = kCurrentLocation_;

	prevDeltaTime = deltaTimeIn;
	return vectorAngularVelocity_;
}

// [SUPERNAL / UAM]
FVector VDSensorIMU::CalculateAngularAcceleration(const float deltaTimeIn)
{
	constexpr float kToMeters = 1e-2;

	const FVector kCurrentLocation_ = { rootComponent->GetComponentRotation().Roll,
		rootComponent->GetComponentRotation().Pitch, rootComponent->GetComponentRotation().Yaw };

	const FVector kY2_ = prevLocation[0];
	const FVector kY1_ = prevLocation[1];
	const FVector kY0_ = kCurrentLocation_;
	const float kH1 = deltaTimeIn;	 // x3 -x2
	const float kH2 = prevDeltaTime; // x2 - x1

	const float kH1AndH2 = kH2 + kH1; // x3 - x1
	const FVector kA_ = kY1_ / (kH1 * kH2);
	const FVector kB_ = kY2_ / (kH2 * (kH1AndH2));
	const FVector kC_ = kY0_ / (kH1 * (kH1AndH2));
	FVector fVectorAngularAccelerometer_ = kToMeters * -2.0f * (kA_ - kB_ - kC_);

	FQuat imuRotation_ = rootComponent->GetComponentTransform().GetRotation();

	fVectorAngularAccelerometer_ = imuRotation_.UnrotateVector(fVectorAngularAccelerometer_);
	prevRotator[0] = prevRotator[1];
	prevRotator[1] = kCurrentLocation_;
	prevDeltaTime = deltaTimeIn;

	return fVectorAngularAccelerometer_;
}

// [SUPERNAL / UAM]
FVector VDSensorIMU::CalculateAngularVelocity(FVector angleIn, FQuat rotIn, const float deltaTimeIn)
{
	constexpr float kToMeters = 1e-2;

	const FVector currentAngle_ = angleIn;

	const FVector kVY2_ = prevRotator[0];
	const FVector kVY1_ = prevRotator[1];
	const FVector kVY0_ = currentAngle_;

	const float kH1 = deltaTimeIn;	  // x3 -x2
	const float kH2 = prevDeltaTime;  // x2 - x1
	const float kH1AndH2 = kH2 + kH1; // x3 - x1

	const FVector kA_ = (kVY2_ * kH1) / (kH2 * kH1AndH2);
	const FVector kB_ = (kVY1_ * (kH1 + kH2)) / (kH2 * kH1);
	const FVector kC_ = (kVY0_ * (2 * kH1 + kH2)) / (kH1 * kH1AndH2);

	FVector fVectorAngularVelocity_ = kToMeters * (kA_ - kB_ + kC_);

	FQuat imuRotation_ = rotIn;

	fVectorAngularVelocity_ = imuRotation_.UnrotateVector(fVectorAngularVelocity_);

	prevRotator[0] = prevRotator[1];
	prevRotator[1] = currentAngle_;

	prevDeltaTime = deltaTimeIn;

	return fVectorAngularVelocity_;
}

// [SUPERNAL / UAM]
const FVector VDSensorIMU::CalculateAccelerationNoise(const FVector& accelerometerIn)
{
	const FVector kMean_ = { 0.0, 0.0, 0.0 };
	const FVector kStdDev_ = { 0.1, 0.1, 0.1 };

	// return FVector(
	// Accelerometer.X + Noise.GaussianNoise(Mean.X, Stdev.X),
	// Accelerometer.Y + Noise.GaussianNoise(Mean.Y, Stdev.Y),
	// Accelerometer.Z + Noise.GaussianNoise(Mean.Z, Stdev.Z));

	//**** Just ACC ****//
	return FVector(accelerometerIn.X, accelerometerIn.Y, accelerometerIn.Z);

	//**** Just Noise ****//
	// return FVector(
	//	Noise.GaussianNoise(Mean.X, Stdev.X),
	//	Noise.GaussianNoise(Mean.Y, Stdev.Y),
	//	Noise.GaussianNoise(Mean.Z, Stdev.Z));
}

//[NSR]
FVector VDSensorIMU::CalculateAcceleration(FVector poseIn, FQuat rotIn, const float deltaTimeIn)
{
	constexpr float kToMeters = 1e-2;
	constexpr float kGravity = 9.81f;

	// 2nd derivative of the polynomic (quadratic) interpolation
	// using the point in current time and two previous steps:
	// d2[i] = -2.0*(y1/(h1*h2)-y2/((h2+h1)*h2)-y0/(h1*(h2+h1)))

	const FVector currentLocation_ = poseIn;

	const FVector kY2_ = prevLocation[0];
	const FVector kY1_ = prevLocation[1];
	const FVector kY0_ = currentLocation_;

	const float kH1 = deltaTimeIn;
	const float kH2 = prevDeltaTime;

	const float H1AndH2 = kH2 + kH1;
	const FVector kA_ = kY1_ / (kH1 * kH2);
	const FVector kB_ = kY2_ / (kH2 * (H1AndH2));
	const FVector kC_ = kY0_ / (kH1 * (H1AndH2));
	FVector fVectorAccelerometer_ = kToMeters * -2.0f * (kA_ - kB_ - kC_);

	fVectorAccelerometer_.Z += kGravity;

	FQuat imuRotation_ = rotIn;

	fVectorAccelerometer_ = imuRotation_.UnrotateVector(fVectorAccelerometer_);

	prevLocation[0] = prevLocation[1];
	prevLocation[1] = currentLocation_;

	prevDeltaTime = deltaTimeIn;

	// const FVector Accelerometer = CalculateAccelerationNoise(FVectorAccelerometer);
	return fVectorAccelerometer_;
}

bool VDSensorIMU::IsJsbSimResourceLoad()
{
	if (jsbSimOrientation_ == nullptr || jsbSimAngularVelocity_ == nullptr || jsbSimLinearVelocity_ == nullptr)
	{
		// ErrorLog(TEXT("JSBSim Dynamics Model is not loaded. Please check the JSBSim Dynamics Model."));
		return false;
	}

	if (!HasRootComponent())
	{
		ErrorLog(TEXT("RootComponent of IMU Sensor is not defined"));
		return false;
	}
	return true;
}

bool VDSensorIMU::IsNSRDroneResourceLoad()
{
	// Clear All JSBSim Dynamics Model //
	if (IsJsbSimResourceLoad())
	{
		jsbSimOrientation_ = nullptr;
		jsbSimAngularVelocity_ = nullptr;
		jsbSimLinearVelocity_ = nullptr;
	}

	if (!HasRootComponent())
	{
		ErrorLog(TEXT("RootComponent of IMU Sensor is not defined"));
		return false;
	}
	return true;
}
