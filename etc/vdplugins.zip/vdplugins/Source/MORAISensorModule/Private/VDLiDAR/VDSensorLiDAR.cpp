#include "VDLiDAR/VDSensorLiDAR.h"

#include "Components/LineBatchComponent.h"
#include "Physics/Experimental/PhysScene_Chaos.h"
#include "PhysicsEngine/PhysicsObjectExternalInterface.h"
#include "VDSensorPose/SensorPose.h"

typedef VDSensorBase Super;

VDSensorLiDAR::~VDSensorLiDAR()
{
	if (lidar3dConfig != nullptr)
	{
		delete lidar3dConfig;
		lidar3dConfig = nullptr;
	}

	if (sensorData.size() > 0)
	{
		sensorData.clear();
	}
}

void VDSensorLiDAR::Initialize()
{
	Super::Initialize();

	lidar3dConfig = new Lidar3dConfig();
	CreateLaser();
}

void VDSensorLiDAR::Release()
{
	Super::Release();
	if (lidar3dConfig != nullptr)
	{
		delete lidar3dConfig;
		lidar3dConfig = nullptr;
	}

	if (sensorData.size() > 0)
	{
		sensorData.clear();
	}
}

void VDSensorLiDAR::Update(const float deltaTimeIn)
{
	Super::Update(deltaTimeIn);
	if (HasRootComponent() && HasWorld())
	{
		// Sensor Pose
		SensorPose sensorPose_;
		sensorPose_.location_ = rootComponent->GetComponentTransform().GetLocation();
		sensorPose_.rotation_ = rootComponent->GetComponentTransform().Rotator();
		sensorPose_.quat_ = rootComponent->GetComponentTransform().GetRotation();

		std::vector<float> lidarOutput;
		GetPointCloud(sensorPose_, deltaTimeIn, lidarOutput);
		sensorData.clear();
		sensorData = lidarOutput;
	}
}

void VDSensorLiDAR::CreateLaser()
{
	SetLidarTemplate(lidar3dConfig);
	SetLidarFrequency(lidar3dConfig);
	SetLidarReturnMode(lidar3dConfig);
}

void VDSensorLiDAR::SetLidarTemplate(Lidar3dConfig* SensorConfig)
{
	switch (SensorConfig->lidar3dType)
	{
	case CH16:
	{
		lidar3dTemplate_.name = "Lidar16VLP";
		lidar3dTemplate_.numLaserEmitter = 16;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 50.0f;	 // cm
		lidar3dTemplate_.maxDistance = 10000.0f; // cm
		lidar3dTemplate_.fieldOfView = 30.0f;
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.02;
		lidar3dTemplate_.measurementsPerRotation = 1800;

		const std::vector kVerticalRayAngles = { -15.0f, 1.0f, -13.0f, 3.0f, -11.0f, 5.0f, -9.0f, 7.0f, -7.0f, 9.0f,
			-5.0f, 11.0f, -3.0f, 13.0f, -1.0f, 15.0f };
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector kRotCorrections = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f };
		lidar3dTemplate_.rotCorrections.assign(kRotCorrections.begin(), kRotCorrections.end());
		lidar3dTemplate_.centerAngle = 0.0f;
		lidar3dTemplate_.textureHeightFactor = 2;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(0, 0.0378f, 0.04191f);
		lidar3dTemplate_.nearClipPlane = 1.0f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.5f;  // Velodyne unit이라는 명칭이 맞는지 확인 필요.
		break;
	}
	case CH32:
	{
		lidar3dTemplate_.name = "Lidar32";
		lidar3dTemplate_.numLaserEmitter = 32;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 50.0f;	 // cm
		lidar3dTemplate_.maxDistance = 10000.0f; // cm
		lidar3dTemplate_.fieldOfView = 41.33f;
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.02;
		lidar3dTemplate_.measurementsPerRotation = 1800;

		const std::vector kVerticalRayAngles = { -30.67f, -9.3299f, -29.33f, -8.0f, -28.0f, -6.6700f, -26.67f, -5.3299f,
			-25.33f, -4.0f, -24.0f, -2.6700f, -22.67f, -1.33f, -21.33f, 0.0f, -20.0f, 1.33f, -18.67f, 2.67f, -17.33f,
			4.0f, -16.0f, 5.3299f, -14.67f, 6.67f, -13.33f, 8.0f, -12.0f, 9.329f, -10.67f, 10.67f };
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector kRotCorrections = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f };
		lidar3dTemplate_.rotCorrections.assign(kRotCorrections.begin(), kRotCorrections.end());
		lidar3dTemplate_.centerAngle = 5.0f;
		lidar3dTemplate_.textureHeightFactor = 2;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(0, 0.0378f, 0.04191f);
		lidar3dTemplate_.nearClipPlane = 1.0f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.5f;
		break;
	}
	case CH64:
	{
		lidar3dTemplate_.name = "Lidar64";
		lidar3dTemplate_.numLaserEmitter = 64;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 50.0f;	 // cm
		lidar3dTemplate_.maxDistance = 10000.0f; // cm
		lidar3dTemplate_.fieldOfView = 41.33f;
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.2;
		lidar3dTemplate_.measurementsPerRotation = 2088;

		const std::vector kVerticalRayAngles = { -7.0f, -6.667f, 0.333f, 0.667f, -6.333f, -6.0f, -8.333f, -8.0f,
			-5.667f, -5.333f, -7.667f, -7.333f, -3.0f, -2.667f, -5.0f, -4.667f, -2.333f, -2.0f, -4.333f, -4.0f, -1.667f,
			-1.333f, -3.667f, -3.333f, 1.0f, 1.333f, -1.0f, -0.667f, 1.667f, 2.0f, -0.333f, 0.0f, -22.8f, -22.3f,
			-11.8f, -11.3f, -21.8f, -21.3f, -24.8f, -24.3f, -20.8f, -20.3f, -23.8f, -23.3f, -16.8f, -16.3f, -19.8f,
			-19.3f, -15.8f, -15.3f, -18.8f, -18.3f, -14.8f, -14.3f, -17.8f, -17.3f, -10.8f, -10.3f, -13.8f, -13.3f,
			-9.8f, -9.3f, -12.8f, -12.3f };
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector kRotCorrections = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
		lidar3dTemplate_.rotCorrections.assign(kRotCorrections.begin(), kRotCorrections.end());
		lidar3dTemplate_.centerAngle = 11.45f;
		lidar3dTemplate_.textureHeightFactor = 2;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(0, 0.0378f, 0.04191f);
		lidar3dTemplate_.nearClipPlane = 1.0f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.5f;
		break;
	}
	case CH128:
	{
		lidar3dTemplate_.name = "Lidar128";
		lidar3dTemplate_.numLaserEmitter = 128;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 50.0f;	 // cm
		lidar3dTemplate_.maxDistance = 10000.0f; // cm
		lidar3dTemplate_.fieldOfView = 41.33f;
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.02;
		lidar3dTemplate_.measurementsPerRotation = 1800;

		const std::vector kVerticalRayAngles = { -11.742f, -1.99f, 3.4f, -5.29f, -0.78f, 4.61f, -4.08f, 1.31f, -6.5f,
			-1.11f, 4.28f, -4.41f, 0.1f, 6.48f, -3.2f, 2.19f, -3.86f, 1.53f, -9.244f, -1.77f, 2.74f, -5.95f, -0.56f,
			4.83f, -2.98f, 2.41f, -6.28f, -0.89f, 3.62f, -5.07f, 0.32f, 7.58f, -0.34f, 5.18f, -3.64f, 1.75f, -25.0f,
			-2.43f, 2.96f, -5.73f, 0.54f, 9.7f, -2.76f, 2.63f, -7.65f, -1.55f, 3.84f, -4.85f, 3.18f, -5.51f, -0.12f,
			5.73f, -4.3f, 1.09f, -16.042f, -2.21f, 4.06f, -4.63f, 0.76f, 15.0f, -3.42f, 1.97f, -6.85f, -1.33f, -5.62f,
			-0.23f, 5.43f, -3.53f, 0.98f, -19.582f, -2.32f, 3.07f, -4.74f, 0.65f, 11.75f, -2.65f, 1.86f, -7.15f, -1.44f,
			3.95f, -2.1f, 3.29f, -5.4f, -0.01f, 4.5f, -4.19f, 1.2f, -13.565f, -1.22f, 4.17f, -4.52f, 0.87f, 6.08f,
			-3.31f, 2.08f, -6.65f, 1.42f, -10.346f, -1.88f, 3.51f, -6.06f, -0.67f, 4.72f, -3.97f, 2.3f, -6.39f, -1.0f,
			4.39f, -5.18f, 0.21f, 6.98f, -3.09f, 4.98f, -3.75f, 1.64f, -8.352f, -2.54f, 2.85f, -5.84f, -0.45f, 8.43f,
			-2.87f, 2.52f, -6.17f, -1.66f, 3.73f, -4.96f, 0.43f };
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector kRotCorrections = { 6.354f, 4.548f, 2.732f, 0.911f, -0.911f, -2.732f, -4.548f, -6.354f,
			6.354f, 4.548f, 2.732f, 0.911f, -0.911f, -2.732f, -4.548f, -6.354f, 6.354f, 4.548f, 2.732f, 0.911f, -0.911f,
			-2.732f, -4.548f, -6.354f, 6.354f, 4.548f, 2.732f, 0.911f, -0.911f, -2.732f, -4.548f, -6.354f, 6.354f,
			4.548f, 2.732f, 0.911f, -0.911f, -2.732f, -4.548f, -6.354f, 6.354f, 4.548f, 2.732f, 0.911f, -0.911f,
			-2.732f, -4.548f, -6.354f, 6.354f, 4.548f, 2.732f, 0.911f, -0.911f, -2.732f, -4.548f, -6.354f, 6.354f,
			4.548f, 2.732f, 0.911f, -0.911f, -2.732f, -4.548f, -6.354f, 6.354f, 4.548f, 2.732f, 0.911f, -0.911f,
			-2.732f, -4.548f, -6.354f, 6.354f, 4.548f, 2.732f, 0.911f, -0.911f, -2.732f, -4.548f, -6.354f, 6.354f,
			4.548f, 2.732f, 0.911f, -0.911f, -2.732f, -4.548f, -6.354f, 6.354f, 4.548f, 2.732f, 0.911f, -0.911f,
			-2.732f, -4.548f, -6.354f, 6.354f, 4.548f, 2.732f, 0.911f, -0.911f, -2.732f, -4.548f, -6.354f, 6.354f,
			4.548f, 2.732f, 0.911f, -0.911f, -2.732f, -4.548f, -6.354f, 6.354f, 4.548f, 2.732f, 0.911f, -0.911f,
			-2.732f, -4.548f, -6.354f, 6.354f, 4.548f, 2.732f, 0.911f, -0.911f, -2.732f, -4.548f, -6.354f };
		lidar3dTemplate_.rotCorrections.assign(kRotCorrections.begin(), kRotCorrections.end());
		lidar3dTemplate_.centerAngle = 5.0f;
		lidar3dTemplate_.textureHeightFactor = 32;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(0, 0.06611f, 0.05863f);
		lidar3dTemplate_.nearClipPlane = 1.0f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.5f;
		break;
	}
	case Ouster64:
	{
		lidar3dTemplate_.name = "Ouster64";
		lidar3dTemplate_.numLaserEmitter = 64;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 20.0f;	 // cm
		lidar3dTemplate_.maxDistance = 12000.0f; // cm
		lidar3dTemplate_.fieldOfView = 33.5f;
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.02;
		lidar3dTemplate_.measurementsPerRotation = 1800;

		const std::vector kVerticalRayAngles = { -16.083984375f, -15.46875f, -14.853515625f, -14.326171875f,
			-13.88671875f, -13.271484375f, -12.744140625f, -12.216796875f, -11.689453125f, -11.162109375f,
			-10.634765625f, -10.01953125f, -9.580078125f, -9.052734375f, -8.525390625f, -7.91015625f, -7.470703125f,
			-6.943359375f, -6.416015625f, -5.80078125f, -5.361328125f, -4.833984375f, -4.306640625f, -3.69140625f,
			-3.251953125f, -2.724609375f, -2.197265625f, -1.669921875f, -1.142578125f, -0.615234375f, -0.087890625f,
			0.439453125f, 0.87890625f, 1.494140625f, 2.021484375f, 2.548828125f, 2.98828125f, 3.515625f, 4.130859375f,
			4.658203125f, 5.09765625f, 5.625f, 6.15234375f, 6.767578125f, 7.20703125f, 7.734375f, 8.26171875f,
			8.876953125f, 9.31640625f, 9.84375f, 10.37109375f, 10.986328125f, 11.42578125f, 11.953125f, 12.48046875f,
			13.095703125f, 13.53515625f, 14.0625f, 14.677734375f, 15.205078125f, 15.732421875f, 16.259765625f, 16.875f,
			17.40234375f };
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector kRotCorrections = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
		lidar3dTemplate_.rotCorrections.assign(kRotCorrections.begin(), kRotCorrections.end());
		lidar3dTemplate_.centerAngle = 11.45f;
		lidar3dTemplate_.textureHeightFactor = 32;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(0, 0.0378f, 0.04191f);
		lidar3dTemplate_.nearClipPlane = 1.0f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.5f;
		break;
	}
	case SOS_ML_1:
	{
		lidar3dTemplate_.name = "ML-1";
		lidar3dTemplate_.numLaserEmitter = 50;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 50.0f;	// cm
		lidar3dTemplate_.maxDistance = 4095.0f; // cm
		lidar3dTemplate_.fieldOfView = 30.0f;
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.02;
		lidar3dTemplate_.measurementsPerRotation = 192;

		const std::vector kVerticalRayAngles = {
			15.0f,
			14.4f,
			13.8f,
			13.2f,
			12.6f,
			12.0f,
			11.4f,
			10.8f,
			10.2f,
			9.6f,
			9.0f,
			8.4f,
			7.8f,
			7.2f,
			6.6f,
			6.0f,
			5.4f,
			4.8f,
			4.2f,
			3.6f,
			3.0f,
			2.4f,
			1.8f,
			1.2f,
			0.6f,
			0.0f,
			-0.6f,
			-1.2f,
			-1.8f,
			-2.4f,
			-3.0f,
			-3.6f,
			-4.2f,
			-4.8f,
			-5.4f,
			-6.0f,
			-6.6f,
			-7.2f,
			-7.8f,
			-8.4f,
			-9.0f,
			-9.6f,
			-10.2f,
			-10.8f,
			-11.4f,
			-12.0f,
			-12.6f,
			-13.2f,
			-13.8f,
			-14.4f,
		};
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector kRotCorrections = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f };
		lidar3dTemplate_.rotCorrections.assign(kRotCorrections.begin(), kRotCorrections.end());
		lidar3dTemplate_.centerAngle = 0.0f;
		lidar3dTemplate_.textureHeightFactor = 32;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(0, 0.01f, 0.04191f);
		lidar3dTemplate_.nearClipPlane = 1.0f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.5f;
		break;
	}
	case SOS_ML_2:
	{
		lidar3dTemplate_.name = "ML-2";
		lidar3dTemplate_.numLaserEmitter = 50;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 50.0f;	// cm
		lidar3dTemplate_.maxDistance = 4095.0f; // cm
		lidar3dTemplate_.fieldOfView = 45.0f;
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.02;
		lidar3dTemplate_.measurementsPerRotation = 384;

		const std::vector kVerticalRayAngles = { 21.6f, 20.7f, 19.8f, 18.9f, 18.0f, 17.1f, 16.2f, 15.3f, 14.4f, 13.5f,
			12.6f, 11.7f, 10.8f, 9.9f, 9.0f, 8.1f, 7.2f, 6.3f, 5.4f, 4.5f, 3.6f, 2.7f, 1.8f, 0.9f, 0.0f, -0.9f, -1.8f,
			-2.7f, -3.6f, -2.7f, -3.6f, -4.5f, -5.4f, -6.3f, -7.2f, -8.1f, -9.0f, -9.9f, -10.8f, -11.7f, -12.6f, -13.5f,
			-14.4f, -15.3f, -16.2f, -17.1f, -18.0f, -18.9f, -19.8f, -20.7f };
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector kRotCorrections = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f };
		lidar3dTemplate_.rotCorrections.assign(kRotCorrections.begin(), kRotCorrections.end());
		lidar3dTemplate_.centerAngle = 0.0f;
		lidar3dTemplate_.textureHeightFactor = 32;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(0, 0.01f, 0.04191f);
		lidar3dTemplate_.nearClipPlane = 1.0f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.5f;
		break;
	}
	case Ouster32OS1:
	{
		lidar3dTemplate_.name = "Ouster32";
		lidar3dTemplate_.numLaserEmitter = 32;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 20.0f;	 // cm
		lidar3dTemplate_.maxDistance = 12000.0f; // cm
		lidar3dTemplate_.fieldOfView = 45.0f;
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.02;
		lidar3dTemplate_.measurementsPerRotation = 1024;

		const std::vector kVerticalRayAngles = { -22.5f, -21.0483871f, -19.59677419f, -18.14516129f, -16.69354839f,
			-15.24193548f, -13.79032258f, -12.33870968f, -10.88709677f, -9.435483871f, -7.983870968f, -6.532258065f,
			-5.080645161f, -3.629032258f, -2.177419355f, -0.725806452f, 0.725806452f, 2.177419355f, 3.629032258f,
			5.080645161f, 6.532258065f, 7.983870968f, 9.435483871f, 10.88709677f, 12.33870968f, 13.79032258f,
			15.24193548f, 16.69354839f, 18.14516129f, 19.59677419f, 21.0483871f, 22.5f };
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector kRotCorrections = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f };
		lidar3dTemplate_.rotCorrections.assign(kRotCorrections.begin(), kRotCorrections.end());
		lidar3dTemplate_.centerAngle = 11.45f;
		lidar3dTemplate_.textureHeightFactor = 32;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(0, 0.0378f, 0.04191f);
		lidar3dTemplate_.nearClipPlane = 1.0f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.5f;
		break;
	}
	case Ouster64OS1:
	{
		lidar3dTemplate_.name = "Ouster OS-1";
		lidar3dTemplate_.numLaserEmitter = 64;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 20.0f;	 // cm
		lidar3dTemplate_.maxDistance = 12000.0f; // cm
		lidar3dTemplate_.fieldOfView = 45.0f;
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.02;
		lidar3dTemplate_.measurementsPerRotation = 2048;

		const std::vector kVerticalRayAngles = { 21.42f, 20.82f, 20.18f, 19.58f, 18.92f, 18.3f, 17.64f, 17.02f, 16.33f,
			15.72f, 15.04f, 14.38f, 13.68f, 13.05f, 12.34f, 11.69f, 10.98f, 10.33f, 9.62f, 8.94f, 8.22f, 7.56f, 6.84f,
			6.15f, 5.42f, 4.76f, 4.03f, 3.34f, 2.6f, 1.94f, 1.21f, 0.51f, -0.21f, -0.9f, -1.62f, -2.32f, -3.05f, -3.75f,
			-4.44f, -5.14f, -5.85f, -6.55f, -7.28f, -7.94f, -8.65f, -9.34f, -10.05f, -10.7f, -11.4f, -12.08f, -12.77f,
			-13.44f, -14.12f, -14.76f, -15.45f, -16.09f, -16.75f, -17.39f, -18.05f, -18.69f, -19.31f, -19.94f, -20.59f,
			-21.18f };
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector kRotCorrections = { 1.5f, -4.16f, 1.5f, -4.16f, 1.49f, -4.17f, 1.49f, -4.16f, 1.47f, -4.16f,
			1.49f, -4.18f, 1.47f, -4.17f, 1.47f, -4.19f, 1.47f, -4.18f, 1.47f, -4.2f, 1.45f, -4.19f, 1.46f, -4.2f,
			1.43f, -4.2f, 1.45f, -4.22f, 1.41f, -4.21f, 1.44f, -4.22f, 1.42f, -4.24f, 1.43f, -4.24f, 1.4f, -4.27f,
			1.42f, -4.25f, 1.41f, -4.26f, 1.38f, -4.26f, 1.39f, -4.28f, 1.37f, -4.28f, 1.38f, -4.28f, 1.37f, -4.3f,
			1.37f, -4.3f, 1.37f, -4.31f, 1.37f, -4.3f, 1.36f, -4.32f, 1.36f, -4.32f, 1.35f, -4.32f };
		lidar3dTemplate_.rotCorrections.assign(kRotCorrections.begin(), kRotCorrections.end());
		lidar3dTemplate_.centerAngle = 5.0f;
		lidar3dTemplate_.textureHeightFactor = 32;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(0, 0.06611f, 0.05863f);
		lidar3dTemplate_.nearClipPlane = 1.0f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.25f;
		break;
	}
	case H800_Left:
	{
		lidar3dTemplate_.name = "H800 (Left)";
		lidar3dTemplate_.numLaserEmitter = 8;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 10.0f;	 // cm
		lidar3dTemplate_.maxDistance = 20000.0f; // cm
		lidar3dTemplate_.fieldOfView = 16.0f;
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.02;
		lidar3dTemplate_.measurementsPerRotation = 788;

		const std::vector kVerticalRayAngles = { -8.0f, -6.0f, -4.0f, -2.0f, 0.0f, 2.0f, 4.0f, 6.0f };
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector kRotCorrections = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
		lidar3dTemplate_.rotCorrections.assign(kRotCorrections.begin(), kRotCorrections.end());
		lidar3dTemplate_.centerAngle = 0.0f;
		lidar3dTemplate_.textureHeightFactor = 32;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(-0.03898f, 0.0275f, 0.01188f);
		lidar3dTemplate_.nearClipPlane = 1.5f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.25f;
		lidar3dTemplate_.FiringSequenceTime = 0.0000127f;
		break;
	}
	case H800_Right:
	{
		lidar3dTemplate_.name = "H800 (Right)";
		lidar3dTemplate_.numLaserEmitter = 8;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 10.0f;	 // cm
		lidar3dTemplate_.maxDistance = 20000.0f; // cm
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.02;
		lidar3dTemplate_.measurementsPerRotation = 788;

		const std::vector kVerticalRayAngles = { -8.0f, -6.0f, -4.0f, -2.0f, 0.0f, 2.0f, 4.0f, 6.0f };
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector rotCorrections = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
		lidar3dTemplate_.rotCorrections.assign(rotCorrections.begin(), rotCorrections.end());
		lidar3dTemplate_.centerAngle = 0.0f;
		lidar3dTemplate_.textureHeightFactor = 32;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(-0.03898f, 0.0275f, 0.01188f);
		lidar3dTemplate_.nearClipPlane = 1.5f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.25f;
		lidar3dTemplate_.FiringSequenceTime = 0.0000127f;
		break;
	}
	case M1600:
	{
		lidar3dTemplate_.name = "M1600";
		lidar3dTemplate_.numLaserEmitter = 16;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 10.0f;	// cm
		lidar3dTemplate_.maxDistance = 3000.0f; // cm
		lidar3dTemplate_.fieldOfView = 32.0f;
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.02;
		lidar3dTemplate_.measurementsPerRotation = 406;

		const std::vector kVerticalRayAngles = { -16.0f, -14.0f, -12.0f, -10.0f, -8.0f, -6.0f, -4.0f, -2.0f, 0.0f, 2.0f,
			4.0f, 6.0f, 8.0f, 10.0f, 12.0f, 14.0f };
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector kRotCorrections = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			0.0f, 0.0f, 0.0f, 0.0f };
		lidar3dTemplate_.rotCorrections.assign(kRotCorrections.begin(), kRotCorrections.end());
		lidar3dTemplate_.centerAngle = 0.0f;
		lidar3dTemplate_.textureHeightFactor = 32;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(-0.039f, 0.0275f, 0.0916f);
		lidar3dTemplate_.nearClipPlane = 1.5f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.25f;
		lidar3dTemplate_.FiringSequenceTime = 0.00002464f;
		break;
	}
	case VLP32c:
	{
		lidar3dTemplate_.name = "VLP-32c (ULTRA Puck)";
		lidar3dTemplate_.numLaserEmitter = 32;
		lidar3dTemplate_.numDataBlocks = 12;
		lidar3dTemplate_.numDataChannel = 32;
		lidar3dTemplate_.minDistance = 50.0f;	 // cm
		lidar3dTemplate_.maxDistance = 20000.0f; // cm
		lidar3dTemplate_.fieldOfView = 40.0f;
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution = 0.02;
		lidar3dTemplate_.measurementsPerRotation = 1800;

		const std::vector kVerticalRayAngles = {
			-25.0f,
			-1.0f,
			-1.667f,
			-15.639f,
			-11.31f,
			0.0f,
			-0.667f,
			-8.843f,
			-7.254f,
			0.333f,
			-0.333f,
			-6.148f,
			-5.333f,
			1.333f,
			0.667f,
			-4.0f,
			-4.667f,
			1.667f,
			1.0f,
			-3.667f,
			-3.333f,
			3.333f,
			2.333f,
			-2.667f,
			-3.0f,
			7.0f,
			4.667f,
			-2.333f,
			-2.0f,
			15.0f,
			10.333f,
			-1.333f,
		};
		lidar3dTemplate_.verticalRayAngles.assign(kVerticalRayAngles.begin(), kVerticalRayAngles.end());

		const std::vector kRotCorrections = {
			1.4f,
			-4.2f,
			1.4f,
			-1.4f,
			1.4f,
			-1.4f,
			4.2f,
			-1.4f,
			1.4f,
			-4.2f,
			1.4f,
			-1.4f,
			4.2f,
			-1.4f,
			4.2f,
			-1.4f,
			1.4f,
			-4.2f,
			1.4f,
			-4.2f,
			4.2f,
			-1.4f,
			1.4f,
			-1.4f,
			1.4f,
			-1.4f,
			1.4f,
			-4.2f,
			4.2f,
			-1.4f,
			1.4f,
			-1.4f,
		};
		lidar3dTemplate_.rotCorrections.assign(kRotCorrections.begin(), kRotCorrections.end());
		lidar3dTemplate_.centerAngle = 0.0f;
		lidar3dTemplate_.textureHeightFactor = 32;
		lidar3dTemplate_.textureWidthFactor = 2;
		lidar3dTemplate_.sensorOffset = Eigen::Vector3f(0, 0.03734f, 0.0424f);
		lidar3dTemplate_.nearClipPlane = 2.0f; // cm
		lidar3dTemplate_.VelodyneUnit = 0.25f;
		break;
	}
	default:
		break;
	}
}

void VDSensorLiDAR::SetLidarFrequency(Lidar3dConfig* _SensorConfig)
{
	switch (_SensorConfig->lidar3dFrequency)
	{
	case HZ05:
	{
		lidar3dTemplate_.rotationFrequency = 5.0f;
		lidar3dTemplate_.angleResolution *= lidar3dTemplate_.rotationFrequency;

		break;
	}
	case HZ10:
	{
		lidar3dTemplate_.rotationFrequency = 10.0f;
		lidar3dTemplate_.angleResolution *= lidar3dTemplate_.rotationFrequency;
		break;
	}
	case HZ15:
	{
		lidar3dTemplate_.rotationFrequency = 15.0f;
		lidar3dTemplate_.angleResolution *= lidar3dTemplate_.rotationFrequency;
		break;
	}
	case HZ20:
	{
		lidar3dTemplate_.rotationFrequency = 20.0f;
		lidar3dTemplate_.angleResolution *= lidar3dTemplate_.rotationFrequency;
		break;
	}
	case HZ25:
	{
		lidar3dTemplate_.rotationFrequency = 25.0f;
		lidar3dTemplate_.angleResolution *= lidar3dTemplate_.rotationFrequency;
		break;
	}
	default:
		break;
	}
}

void VDSensorLiDAR::SetLidarReturnMode(Lidar3dConfig* _SensorConfig)
{
	switch (_SensorConfig->lidar3dReturnMode)
	{
	case Strongest:
	{
		ReturnMode = Strongest;
		break;
	}
	case LastReturn:
	{
		ReturnMode = LastReturn;
		break;
	}
	case DualReturn:
	{
		ReturnMode = DualReturn;
		break;
	}
	default:
		break;
	}
}

bool VDSensorLiDAR::ShootLaser(SensorPose& pose, float horizontalAngleIn, float verticalAngleIn,
	Lidar3dTemplate paramIn, Eigen::Vector3f& pointOut, float& intensityOut)
{
	FVector start_ = pose.location_;
	// Ray Forward Vector
	FRotator lidarRayForwardVec_(verticalAngleIn, horizontalAngleIn, 0);
	FRotator resultRot_ = UKismetMathLibrary::ComposeRotators(lidarRayForwardVec_, pose.rotation_);
	FVector end_ = paramIn.maxDistance * UKismetMathLibrary::GetForwardVector(resultRot_) + start_;

	FHitResult hitResult = FHitResult(ForceInit);

	FCollisionQueryParams traceParams =
		FCollisionQueryParams(TEXT("LaserTrace"), false, rootComponent->GetAttachParentActor());
	traceParams.bReturnPhysicalMaterial = false;
	traceParams.bTraceComplex = false;

	bool bIsHit = world->LineTraceSingleByChannel(hitResult, start_, end_, ECC_Visibility, traceParams);
	if (bIsHit)
	{
		FVector gnssNoiseVector_ = FVector(
			lidarNoise.GaussianNoise(0.0, 1.0), lidarNoise.GaussianNoise(0.0, 1.0), lidarNoise.GaussianNoise(0.0, 1.0));
		FVector bodyLoc_ = rootComponent->GetComponentTransform().GetLocation() + gnssNoiseVector_;
		Eigen::Vector3f pointForDraw = ToVector3r(hitResult.ImpactPoint - bodyLoc_, 1, false);
		pointOut = ToLeftHandToRightHandPosition(ToVector3r(hitResult.ImpactPoint - bodyLoc_, 1, false));
		intensityOut = hitResult.Distance / lidar3dTemplate_.maxDistance;

		// Sensor Draw (Change Sensor Coordinate Sys), DrawDebug Point
		if (IsInGameThread())
		{
			world->PersistentLineBatcher->DrawPoint(ToFVector(pointForDraw, 1.0f, false) + bodyLoc_, FColor::Red,
				2.0f,  // size
				false, // persistent (never goes away)
				0.1f   // point leaves a trail on moving object
			);
		}

		return true;
	}
	else
		return false;
}

void VDSensorLiDAR::GetPointCloud(SensorPose& pose, double deltaTimeIn, std::vector<float>& pointCloudOut)
{
	pointCloudOut.clear();

	// uint32 total_points_to_scan = FMath::RoundHalfFromZero(params.points_per_second );
	const int kTotalpointsPerRotation = lidar3dTemplate_.measurementsPerRotation * lidar3dTemplate_.numLaserEmitter;

	const uint32 kPointsToScanWithOneLaser = FMath::RoundHalfFromZero(
		kTotalpointsPerRotation * deltaTimeIn / static_cast<float>(lidar3dTemplate_.numLaserEmitter));
	if (kPointsToScanWithOneLaser <= 0)
	{
		return;
	}

	const float kAngleDistanceOfTick = lidar3dTemplate_.rotationFrequency * 360.0f * deltaTimeIn;
	const float kAngleDistanceOfLaserMeasure = kAngleDistanceOfTick / kPointsToScanWithOneLaser;

	const int kThreadNum = lidar3dTemplate_.numLaserEmitter;
	// const int ThreadNum = 15;
	const int kDivideEnd = FMath::FloorToInt(static_cast<float>(kTotalpointsPerRotation / kThreadNum));

	FCriticalSection Mutex;
	auto LockedPhysObject = FPhysicsObjectExternalInterface::LockRead(world->GetPhysicsScene());
	{
		// ************************ ParallelFor first Calculate ************************//
		// ParallelFor(
		// ThreadNum,
		// [&](int32 PFIndex) {
		// 	TRACE_CPUPROFILER_EVENT_SCOPE(ParallelForTask);
		//
		// 	for (uint32 Index = 0; Index < pointsToScanWithOneLaser; Index++)
		// 	{
		// 		const float HAngle = std::fmod(CurrentHorizontalAngle + Index * angleDistanceOfLaserMeasure, 360.0f);
		// 		const float VAngle = lidar3dTemplate.verticalRayAngles[PFIndex];
		//
		// 		Eigen::Vector3f point;
		//
		// 		float intensity = -1.0f;
		//
		// 		if (ShootLaser(poseIn, orientationIn, quatIn, HAngle, VAngle, lidar3dTemplate, point, intensity))
		// 		{
		// 			pointCloudOut.emplace_back(point.x());
		// 			pointCloudOut.emplace_back(point.y());
		// 			pointCloudOut.emplace_back(point.z());
		// 			pointCloudOut.emplace_back(intensity);
		// 		}
		// 	}
		// },
		// true,
		// true
		// );

		//************************ ParallelFor Second Calculate ************************//
		// ParallelFor(
		// ThreadNum,
		// [&](int32 PFIndex) {
		// 	TRACE_CPUPROFILER_EVENT_SCOPE(ParallelForTask);
		// 	int StartAt = PFIndex * DivideEnd;
		// 	if (StartAt >= totalpointsPerRotation) {
		// 	  return;
		// 	}
		//
		// 	int EndAt = StartAt + DivideEnd;
		// 	if (PFIndex == (ThreadNum - 1)) {
		// 	  EndAt = totalpointsPerRotation;
		// 	}
		//
		// 	for (int32 Index = StartAt; Index < EndAt; Index++)
		// 	{
		// 		const float HAngle = std::fmod(CurrentHorizontalAngle + (Index / lidar3dTemplate.numLaserEmitter) *
		// angleDistanceOfLaserMeasure, 360.0f); 		const float VAngle = lidar3dTemplate.verticalRayAngles[Index %
		// lidar3dTemplate.numLaserEmitter];
		//
		// 		Eigen::Vector3f point;
		//
		// 		float intensity = -1.0f;
		//
		// 		if (ShootLaser(poseIn, orientationIn, quatIn, HAngle, VAngle, lidar3dTemplate, point, intensity))
		// 		{
		// 			pointCloudOut.emplace_back(point.x());
		// 			pointCloudOut.emplace_back(point.y());
		// 			pointCloudOut.emplace_back(point.z());
		// 			pointCloudOut.emplace_back(intensity);
		// 		}
		// 	}
		// },
		// true,
		// true
		// );

		//************************ Simple Calculate ************************//
		for (uint32 i = 0u; i < lidar3dTemplate_.numLaserEmitter; i++)
		{
			for (uint32 Index = 0u; Index < kPointsToScanWithOneLaser; Index++)
			{
				const float hAngle = std::fmod(currentHorizontalAngle + Index * kAngleDistanceOfLaserMeasure, 360.0f);
				const float vAngle = lidar3dTemplate_.verticalRayAngles[i];

				Eigen::Vector3f point;

				float intensity = -1.0f;

				if (ShootLaser(pose, hAngle, vAngle, lidar3dTemplate_, point, intensity))
				{
					pointCloudOut.emplace_back(point.x());
					pointCloudOut.emplace_back(point.y());
					pointCloudOut.emplace_back(point.z());
					pointCloudOut.emplace_back(intensity);
				}
			}
		}
	}

	LockedPhysObject.Release();

	currentHorizontalAngle = std::fmod(currentHorizontalAngle + kAngleDistanceOfTick, 360.0f);
}

/**
 * [TEMP] @ghshin Async Thread 관련 함수, 리팩토링 후 client -> vdplugin 에서 옮기게 되어
 *  관련 함수도 따라 이동됨.
 */

void VDSensorLiDAR::InitAndRunThread(const float& timespanIn)
{
	const FTimespan& kTimeSpan = FTimespan::FromMilliseconds(timespanIn);
	sensorThread = new VDSensorThreadProcess(kTimeSpan, TEXT("LidarThread"), this);

	if (sensorThread)
	{
		sensorThread->Init();
		UE_LOG(LogTemp, Warning, TEXT("Lidar thread initialized!"));
	}
}

void VDSensorLiDAR::UpdateThreadProcess()
{
	// ----- Process ------- //
}

void VDSensorLiDAR::ReleaseThread()
{
	if (sensorThread)
	{
		sensorThread->Stop();
	}

	delete sensorThread;

	UE_LOG(LogTemp, Warning, TEXT("Lidar thread deleted!"));
}
