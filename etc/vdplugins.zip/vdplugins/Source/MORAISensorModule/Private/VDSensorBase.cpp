#include "VDSensorBase.h"

// void VDSensorBase::SetUEClass(const VDUEClassSet _ueClassSet)
//{
//	SetWorld(_ueClassSet.world);
//	SetRootComponent(_ueClassSet.root);
// }

VDSensorBase::VDSensorBase()
{
	world = nullptr;
	rootComponent = nullptr;
}

void VDSensorBase::SetWorld(const UWorld* worldIn)
{
	if (world == worldIn)
	{
		WarningLog(TEXT("World is already defined."));
	}
	else if (world != nullptr)
	{
		world = worldIn;
		WarningLog(TEXT("World is already defined but it is different. World is changed."));
	}
	else
	{
		world = worldIn;
	}
}

void VDSensorBase::SetRootComponent(const USceneComponent* rootIn)
{
	if (rootComponent == rootIn)
	{
		WarningLog(TEXT("RootComponent is already defined."));
	}
	else if (rootComponent != nullptr)
	{
		rootComponent = rootIn;
		WarningLog(TEXT("RootComponent is already defined but it is different. RootComponent is changed."));
	}
	else
	{
		rootComponent = rootIn;
	}
}

bool VDSensorBase::HasRootComponent()
{
	if (rootComponent == nullptr)
	{
		ErrorLog(TEXT("RootComponent is not defined."));
		return false;
	}
	return true;
}

bool VDSensorBase::HasWorld()
{
	if (world == nullptr)
	{
		ErrorLog(TEXT("World is not defined."));
		return false;
	}
	return true;
}

void VDSensorBase::InfoLog(const FString logIn)
{
	GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Cyan, logIn);
}

void VDSensorBase::WarningLog(const FString logIn)
{
	GEngine->AddOnScreenDebugMessage(-1, 1.5f, FColor::Yellow, logIn);
}

void VDSensorBase::ErrorLog(const FString logIn)
{
	GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Red, logIn);
}
