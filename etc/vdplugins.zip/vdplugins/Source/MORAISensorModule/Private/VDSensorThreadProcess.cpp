﻿#include "VDSensorThreadProcess.h"

#include "VDSensorBase.h"

VDSensorThreadProcess::VDSensorThreadProcess(
	const FTimespan& threadSleepTimeIn, const TCHAR* threadNameIn, VDSensorBase* vdSensorIn) :
VDSensorThreadBase(threadSleepTimeIn, threadNameIn),
vdSensor(vdSensorIn)
{
}

VDSensorThreadProcess::~VDSensorThreadProcess()
{
	UE_LOG(LogTemp, Log, TEXT("On destroying MSensorThreadProcess"));
}

void VDSensorThreadProcess::Process()
{
	if (!vdSensor)
	{
		return;
	}

	vdSensor->UpdateThreadProcess();
}

bool VDSensorThreadProcess::SensorWorkerThreadInit()
{
	return true;
}

void VDSensorThreadProcess::SensorThreadShutdown() {}
