#include "VDAltimeter/VDSensorAltimeter.h"

typedef VDSensorBase Super;

void VDSensorAltimeter::Update(const float deltaTimeIn)
{
	Super::Update(deltaTimeIn);
	if (HasRootComponent() && HasWorld())
	{
		FVector start_ = rootComponent->GetComponentTransform().GetLocation();
		// [TEMP] : Magic Number (200000.0f)
		FVector end_ = start_ + rootComponent->GetUpVector() * -200000.0f;

		FCollisionQueryParams collisionParams_;
		collisionParams_.AddIgnoredActor(rootComponent->GetOwner());

		FHitResult hitResult_;
		bool bIsHit = world->LineTraceSingleByChannel(hitResult_, start_, end_, ECC_Visibility, collisionParams_);

		if (bIsHit)
		{
			// [DEBUG]: Visualization
			// UE_LOG(LogTemp, Log, TEXT("Hit_Distance : %f"),HitResult.Distance);
			// if (distance > HitResult.Distance)
			//	continue;
			// DrawDebugLine(GetWorld(), start, HitResult.ImpactPoint, FColor::Red, true, -1, 0, 10);
			// HitResult.GetActor()->GetUniqueID;
			sensorData_.distance = hitResult_.Distance;
		}
	}
}
