#include "VDGroudTruth/VDIntruderDetector.h"

VDIntruderDetector::~VDIntruderDetector()
{
	if (mapUtmOrigin || intruderDetectNoise)
	{
		delete mapUtmOrigin;
		mapUtmOrigin = nullptr;

		delete intruderDetectNoise;
		intruderDetectNoise = nullptr;
	}
}

void VDIntruderDetector::Initialize()
{
	mapUtmOrigin = new FVector(595429.088, 4135888.208, 0.0); // 임시로 Sanfrancisco 원점 사용. (0.0, 0.0, 0.0);

	if (HasRootComponent())
	{
		ignoreActors.Init(rootComponent->GetOwner(), 1);
	}
	numObj = 0;
	memset(&intruderDetectionPacket_, 0, sizeof(IntruderDetectionPacket));
	memset(&algObject_, 0, sizeof(algObject_));

	/* TODO: @gyshin: VDGNSS Reference
	 * Initialize() SetEllipsoidModel(EllipsoidModel::WGS84); */
	SetEllipsoidModel(EllipsoidModel::WGS84);
	intruderDetectNoise = new VDNoise();
}

void VDIntruderDetector::Release()
{
	if (mapUtmOrigin || intruderDetectNoise)
	{
		delete mapUtmOrigin;
		mapUtmOrigin = nullptr;

		delete intruderDetectNoise;
		intruderDetectNoise = nullptr;
	}
}

void VDIntruderDetector::Update(const float deltaTimeIn)
{
	memset(&intruderDetectionPacket_, 0, sizeof(intruderDetectionPacket_));

	if (HasRootComponent() && HasWorld())
	{
		sensorOrigin = rootComponent->GetComponentTransform().GetLocation();

		sensorForwardVector = rootComponent->GetForwardVector();

		UGameplayStatics::GetAllActorsWithTag(world, FName(TEXT("CLASSIFICATION_MANNED")), outActors);

		FString debugMessage;

		debugMessage += FString::Printf(TEXT("/*************** Intruder Detector ***************/ ")) + LINE_TERMINATOR;

		numObj = 0;

		if (&outActors != NULL)
		{
			for (AActor* overlappedActor : outActors)
			{
				overlappedActor->ActorGetDistanceToCollision(
					overlappedActor->GetActorLocation(), ECC_Visibility, closestPoint);

				overlappedActor->GetAttachedActors(attachedActors);

				if (attachedActors.IsEmpty()) // Static Object -> 추후 삭제
				{
					directionAngle = 0.0f;
					pitchAngle = 0.0f;

					location_ = overlappedActor->GetActorLocation();
					rot_ = { overlappedActor->GetActorRotation().Roll, overlappedActor->GetActorRotation().Pitch,
						overlappedActor->GetActorRotation().Yaw };
					quat_ = overlappedActor->GetActorQuat();

					directionAngle = overlappedActor->GetActorRotation().Yaw + 90.0f;
					if (directionAngle > 360.0f)
						directionAngle -= 360.0f;
					else if (directionAngle < 0.0f)
						directionAngle += 360.0f;

					pitchAngle = overlappedActor->GetActorRotation().Pitch;
					if (pitchAngle > 360.0f)
						pitchAngle -= 360.0f;
					else if (pitchAngle < 0.0f)
						pitchAngle += 360.0f;

					VDALG::CalculateVelocity(location_, quat_, numObj, algObject_, deltaTimeIn);
				}
				else // Dynamic Object
				{
					directionAngle = 0.0f;
					pitchAngle = 0.0f;
					location_ = attachedActors[0]->GetRootComponent()->GetComponentLocation();
					rot_ = { attachedActors[0]->GetActorRotation().Roll, attachedActors[0]->GetActorRotation().Pitch,
						attachedActors[0]->GetActorRotation().Yaw };
					quat_ = attachedActors[0]->GetRootComponent()->GetComponentQuat();

					directionAngle = attachedActors[0]->GetRootComponent()->GetComponentRotation().Yaw + 90.0f;
					if (directionAngle > 360.0f)
						directionAngle -= 360.0f;
					else if (directionAngle < 0.0f)
						directionAngle += 360.0f;

					pitchAngle = attachedActors[0]->GetRootComponent()->GetComponentRotation().Pitch;
					if (pitchAngle > 360.0f)
						pitchAngle -= 360.0f;
					else if (pitchAngle < 0.0f)
						pitchAngle += 360.0f;

					VDALG::CalculateVelocity(location_, quat_, numObj, algObject_, deltaTimeIn);
				}

				WGSData* wgsPosition_ = new WGSData();

				// 위도, 경도 계산
				WGSData llData_ = CalculateLongLat(mapUtmOrigin, location_ * TOMETER, wgsPosition_);

				FVector originToObject_ = { (location_ - sensorOrigin).X, (location_ - sensorOrigin).Y,
					(location_ - sensorOrigin).Z };

				if (*overlappedActor->Tags.GetData() == FName("CLASSIFICATION_MANNED"))
				{
					intruderDetectionPacket_.IntruderDetectionInfo[numObj].heading_true_rad = directionAngle * DEGTORAD;
					intruderDetectionPacket_.IntruderDetectionInfo[numObj].heading_degraded = false;

					intruderDetectionPacket_.IntruderDetectionInfo[numObj].alt_pres_ft =
						originToObject_.Z * TOMETER * METERTOFEET + intruderDetectNoise->GaussianNoise(mean, stdev);

					intruderDetectionPacket_.IntruderDetectionInfo[numObj].lat_deg =
						llData_.latitude + intruderDetectNoise->GaussianNoise(mean, stdev);
					intruderDetectionPacket_.IntruderDetectionInfo[numObj].lon_deg =
						llData_.longitude + intruderDetectNoise->GaussianNoise(mean, stdev);
					intruderDetectionPacket_.IntruderDetectionInfo[numObj].vel_ew_kts =
						algObject_.algInfo_[numObj].currentVelocity_.X * MPSTOKNOT
						+ intruderDetectNoise->GaussianNoise(mean, stdev);
					;
					intruderDetectionPacket_.IntruderDetectionInfo[numObj].vel_ns_kts =
						-1.0 * algObject_.algInfo_[numObj].currentVelocity_.Y * MPSTOKNOT
						+ intruderDetectNoise->GaussianNoise(mean, stdev);
					intruderDetectionPacket_.IntruderDetectionInfo[numObj].alt_hae_ft =
						originToObject_.Z * TOMETER * METERTOFEET + intruderDetectNoise->GaussianNoise(mean, stdev);
					intruderDetectionPacket_.IntruderDetectionInfo[numObj].alt_rate_hae_fps =
						algObject_.algInfo_[numObj].currentVelocity_.Z * METERTOFEET
						+ intruderDetectNoise->GaussianNoise(mean, stdev);
					intruderDetectionPacket_.IntruderDetectionInfo[numObj].nacp = 11; // altitude 계산 방법 다시 고려
					intruderDetectionPacket_.IntruderDetectionInfo[numObj].nacv = 4;
					intruderDetectionPacket_.IntruderDetectionInfo[numObj].vfom_m = 0;
					intruderDetectionPacket_.IntruderDetectionInfo[numObj].alt_agl_ft = 1;
					intruderDetectionPacket_.IntruderDetectionInfo[numObj].UniqueID = overlappedActor->GetUniqueID();

					debugMessage += FString::Printf(TEXT("vel_ew_kts (%f) "),
										intruderDetectionPacket_.IntruderDetectionInfo[numObj].vel_ew_kts)
						+ LINE_TERMINATOR;
					debugMessage += FString::Printf(TEXT("vel_ns_kts (%f) "),
										intruderDetectionPacket_.IntruderDetectionInfo[numObj].vel_ns_kts)
						+ LINE_TERMINATOR;
				}
				numObj += 1;
				delete wgsPosition_;
			}
		}

		FVector2D textScale_ = FVector2D::UnitVector;
		GEngine->AddOnScreenDebugMessage(1, 0, FColor::Green, *debugMessage, false, textScale_);
	}
}

void VDIntruderDetector::SetWorld(const UWorld* worldIn)
{
	if (world == worldIn)
	{
		return;
	}
	else if (world != nullptr)
	{
		world = worldIn;
	}
	else
	{
		world = worldIn;
	}
}

void VDIntruderDetector::SetRootComponent(const USceneComponent* rootIn)
{
	if (rootComponent == rootIn)
	{
		return;
	}
	else if (rootComponent != nullptr)
	{
		rootComponent = rootIn;
	}
	else
	{
		rootComponent = rootIn;
	}
}

WGSData VDIntruderDetector::CalculateLongLat(const FVector* mapOriginIn, FVector targetPoseIn, WGSData* wgsPositionIn)
{
	UTMData utmPosition_ = VDGNSSConverter::UeToUtmPosition(targetPoseIn, *mapOriginIn);
	utmPosition_.zone = 10;
	VDGNSSConverter::UtmToWgsPosition(*wgsPositionIn, ellipsoidModelId, utmPosition_, targetPoseIn.Z);
	return *wgsPositionIn;
}

bool VDIntruderDetector::HasRootComponent()
{
	if (rootComponent == nullptr)
	{
		// [TEMP] debug message
		// ErrorLog(TEXT("RootComponent is not defined."));
		return false;
	}
	return true;
}

bool VDIntruderDetector::HasWorld()
{
	if (world == nullptr)
	{
		// [TEMP] debug message
		// ErrorLog(TEXT("World is not defined."));
		return false;
	}
	return true;
}

void VDIntruderDetector::InfoLog(const FString logIn)
{
	GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Cyan, logIn);
}

void VDIntruderDetector::WarningLog(const FString logIn)
{
	GEngine->AddOnScreenDebugMessage(-1, 1.5f, FColor::Yellow, logIn);
}

void VDIntruderDetector::ErrorLog(const FString logIn)
{
	GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Red, logIn);
}
