﻿#include "VDCamera/VDCaptureComponent.h"

#include "VDSensorConfig/VDCameraSensorConfig.h"

UVDCaptureComponent::UVDCaptureComponent(const FObjectInitializer& objectInitializerIn) : Super(objectInitializerIn)
{
	SetVisibility(true);
	SetHiddenInGame(false);
	bCaptureEveryFrame = true;
	bCaptureOnMovement = false;
	// bAlwaysPersistRenderingState = true; // Always deactivate when bCaptureEveryFrame is true;
	PrimitiveRenderMode = ESceneCapturePrimitiveRenderMode::PRM_RenderScenePrimitives;
	CaptureSource = ESceneCaptureSource::SCS_FinalToneCurveHDR;
	DetailMode = EDetailMode::DM_Low;
}

UVDCaptureComponent::~UVDCaptureComponent()
{
	for (auto renderTarget : textureRenderTargets)
	{
		renderTarget->ReleaseResource();
	}
	for (auto instance : materialInstances)
	{
		instance->DestroyNonNativeProperties();
	}
	textureRenderTargets.Empty();
	materialInstances.Empty();

	// UE_LOG(LogTemp, Log, TEXT("On destroying UVDCaptureComponent"));
}

void UVDCaptureComponent::Initialize(const Eigen::Vector2i& resolutionIn)
{
	RegisterComponent();

	InitTextureRenderTargets(resolutionIn);
	InitMaterialInstanceDynamics();

	Activate();
	UpdateContent();
}

void UVDCaptureComponent::SetCameraType(VD_SENSOR::CameraType cameraTypeIn)
{
	TextureTarget = textureRenderTargets[static_cast<int>(cameraTypeIn)];

	switch (cameraTypeIn)
	{
	case VD_SENSOR::CameraType::RGB:
		VD_SENSOR::CameraSettings::RgbCamera::ApplyMaterialInstanceDynamic(
			materialInstances, this->PostProcessSettings);
		break;
	case VD_SENSOR::CameraType::DEPTH:
		VD_SENSOR::CameraSettings::DepthCamera::ApplyMaterialInstanceDynamic(
			materialInstances, this->PostProcessSettings);
		break;
	default:
		VD_SENSOR::CameraSettings::RgbCamera::ApplyMaterialInstanceDynamic(
			materialInstances, this->PostProcessSettings);
	}
}

void UVDCaptureComponent::ResizeAllTargetsResolution(const uint32_t& widthIn, const uint32_t& heightIn)
{
	if (!textureRenderTargets.IsEmpty())
	{
		for (UTextureRenderTarget2D* textureTarget : textureRenderTargets)
		{
			textureTarget->ResizeTarget(widthIn, heightIn);
		}
	}
}

void UVDCaptureComponent::InitTextureRenderTargets(const Eigen::Vector2i& resolutionIn)
{
	if (!textureRenderTargets.IsEmpty())
	{
		textureRenderTargets.Empty();
	}

	textureRenderTargets.Init(nullptr, static_cast<int>(VD_SENSOR::CameraType::TOTAL));

	textureRenderTargets[static_cast<int>(VD_SENSOR::CameraType::RGB)] = NewObject<UTextureRenderTarget2D>();
	VD_SENSOR::CameraSettings::RgbCamera::InitTextureRenderTarget(
		resolutionIn, textureRenderTargets[static_cast<int>(VD_SENSOR::CameraType::RGB)]);

	textureRenderTargets[static_cast<int>(VD_SENSOR::CameraType::DEPTH)] = NewObject<UTextureRenderTarget2D>();
	VD_SENSOR::CameraSettings::DepthCamera::InitTextureRenderTarget(
		resolutionIn, textureRenderTargets[static_cast<int>(VD_SENSOR::CameraType::DEPTH)]);
}

void UVDCaptureComponent::InitMaterialInstanceDynamics()
{
	materialInstances.Init(nullptr, static_cast<int>(VD_SENSOR::MaterialType::TOTAL));
	static UMaterialInstance* distortionMatInstance =
		Cast<UMaterialInstance>(StaticLoadObject(UMaterialInstance::StaticClass(), this,
			*VD_SENSOR::materialFilePathMap.Find(VD_SENSOR::MaterialType::DISTORTION)));
	materialInstances[static_cast<int>(VD_SENSOR::MaterialType::DISTORTION)] =
		UMaterialInstanceDynamic::Create(distortionMatInstance, this);

	static UMaterialInstance* depthMatInstance = Cast<UMaterialInstance>(StaticLoadObject(
		UMaterialInstance::StaticClass(), this, *VD_SENSOR::materialFilePathMap.Find(VD_SENSOR::MaterialType::DEPTH)));
	materialInstances[static_cast<int>(VD_SENSOR::MaterialType::DEPTH)] =
		UMaterialInstanceDynamic::Create(depthMatInstance, this);

	static UMaterialInstance* cfaMatInstance = Cast<UMaterialInstance>(StaticLoadObject(
		UMaterialInstance::StaticClass(), this, *VD_SENSOR::materialFilePathMap.Find(VD_SENSOR::MaterialType::CFA)));
	materialInstances[static_cast<int>(VD_SENSOR::MaterialType::CFA)] =
		UMaterialInstanceDynamic::Create(cfaMatInstance, this);

	static UMaterialInstance* disableToneMapperMat =
		Cast<UMaterialInstance>(StaticLoadObject(UMaterialInstance::StaticClass(), this,
			*VD_SENSOR::materialFilePathMap.Find(VD_SENSOR::MaterialType::NO_TONEMAP)));
	materialInstances[static_cast<int>(VD_SENSOR::MaterialType::NO_TONEMAP)] =
		UMaterialInstanceDynamic::Create(disableToneMapperMat, this);
}
