#pragma once

#include "VDCamera/VDSensorCamera.h"

#include "Kismet/KismetMathLibrary.h"

using Super = VDSensorBase;

VDSensorCamera::~VDSensorCamera()
{
	UE_LOG(LogTemp, Log, TEXT("On destroying VDSensorCamera"));

	if (sceneCaptureComponent || imageExporter)
	{
		sceneCaptureComponent->DestroyComponent();
		sceneCaptureComponent = nullptr;

		delete imageExporter;
		imageExporter = nullptr;
	}
}

void VDSensorCamera::Initialize()
{
	Super::Initialize();
	sceneCaptureComponent = NewObject<UVDCaptureComponent>(rootComponent->GetAttachmentRoot());
	sceneCaptureComponent->AttachToComponent(
		const_cast<USceneComponent*>(rootComponent), FAttachmentTransformRules::KeepRelativeTransform);
	sceneCaptureComponent->Initialize({ resolution_[0], resolution_[1] });
	imageExporter = NewObject<UVDImageExporter>();
	imageExporter->AddToRoot();

	// Set Default Camera Type
	SetCameraType(currentCameraType);

	UpdateDerivedData();

	InitAndRunThread(1.0f);
}

void VDSensorCamera::Release()
{
	Super::Release();

	ReleaseThread();
	if (sceneCaptureComponent || imageExporter)
	{
		sceneCaptureComponent->DestroyComponent();
		sceneCaptureComponent = nullptr;

		delete imageExporter;
		imageExporter = nullptr;
	}
}

void VDSensorCamera::Update(const float deltaTimeIn)
{
	Super::Update(deltaTimeIn);

	if (IsActivatedAutoSave() && accumulatedDeltaTime >= imageExporter->GetSensorPeriod())
	{
		imageExporter->EnqueueRenderRequest(sceneCaptureComponent->GetCurrentTextureTarget());
		accumulatedDeltaTime = 0.0f;
	}

	accumulatedDeltaTime =
		accumulatedDeltaTime < std::numeric_limits<decltype(accumulatedDeltaTime)>().max() - deltaTimeIn
		? accumulatedDeltaTime + deltaTimeIn
		: deltaTimeIn;
}

void VDSensorCamera::UpdateDerivedData()
{
	if (IsActivatedAutoSave())
	{
		imageExporter->ClearRenderRequest();
	}

	// validate incorrect focal length value
	const float kMaxFocalLength = std::max(lensSettings_.minFocalLength, lensSettings_.maxFocalLength);
	currentFocalLength = std::clamp(currentFocalLength, lensSettings_.minFocalLength, kMaxFocalLength);

	// validate incorrect principal point values
	principalPoint_[0] = std::clamp(principalPoint_[0], kEpsilon, static_cast<float>(resolution_[0]) - kEpsilon);
	principalPoint_[1] = std::clamp(principalPoint_[1], kEpsilon, static_cast<float>(resolution_[1]) - kEpsilon);

	filmbackSettings_.RecalcSensorAspectRatio();
	fieldOfView = GetHorizontalFov();
	sceneCaptureComponent->FOVAngle = GetOverScanFov();

	/* [TEMP] @gishin: Depth value 오차를 줄이기 위해, 사용했던 Near & Far clipping plane 설정
	 * TVD-2082 에서 다시 활용하기 위해 남겨둠 */
	// if(vdCamera->GetCurrentCameraType() == VD_SENSOR::CameraType::DEPTH)
	// {
	// 	const float HalfXFOV = FMath::DegreesToRadians(sceneCaptureComponent->FOVAngle) * 0.5f;
	// 	const float kDepthmin = kDepthRange[0] > 0.0f? kDepthRange[0]: 1e-8;
	// 	FMatrix projMat = FReversedZPerspectiveMatrix(HalfXFOV, kResolution[0], kResolution[1], kDepthmin,
	// kDepthRange[1]); 	sceneCaptureComponent->CustomProjectionMatrix = projMat;
	// 	sceneCaptureComponent->bUseCustomProjectionMatrix = true;
	// }
	// else
	// {
	// 	sceneCaptureComponent->bUseCustomProjectionMatrix = false;
	// }

	UpdateMaterialData();

	sceneCaptureComponent->TextureTarget->UpdateResourceImmediate(true);
	sceneCaptureComponent->UpdateContent();
}

void VDSensorCamera::UpdateMaterialData() const
{
	const float kCameraViewHFov = GetCameraViewHorizontalFov();
	const float kCameraViewFocalLength = ConvertCameraViewHorizontalFovToFocalLength(kCameraViewHFov);
	const float kExtendedHorizontalFOV = GetOverScanFov();
	const float kExtendedFocalLength = ConvertCameraViewHorizontalFovToFocalLength(kExtendedHorizontalFOV);

	TObjectPtr<UMaterialInstanceDynamic> lensDistortionMaterialInstance =
		sceneCaptureComponent->GetMaterialInstanceDynamic(VD_SENSOR::MaterialType::DISTORTION);
	check(lensDistortionMaterialInstance != nullptr);
	const auto [kRadials, kTangentials] = distortion_;

	lensDistortionMaterialInstance->SetScalarParameterValue(TEXT("dist_k1"), kRadials[0]);
	lensDistortionMaterialInstance->SetScalarParameterValue(TEXT("dist_k2"), kRadials[1]);
	lensDistortionMaterialInstance->SetScalarParameterValue(TEXT("dist_k3"), kRadials[2]);
	lensDistortionMaterialInstance->SetScalarParameterValue(TEXT("dist_p1"), kTangentials[0]);
	lensDistortionMaterialInstance->SetScalarParameterValue(TEXT("dist_p2"), kTangentials[1]);
	lensDistortionMaterialInstance->SetScalarParameterValue(TEXT("kOriginalFocalLength"), kCameraViewFocalLength);
	lensDistortionMaterialInstance->SetScalarParameterValue(TEXT("kExtendedFocalLength"), kExtendedFocalLength);
	lensDistortionMaterialInstance->SetScalarParameterValue(TEXT("resolution_x"), static_cast<float>(resolution_[0]));
	lensDistortionMaterialInstance->SetScalarParameterValue(TEXT("resolution_y"), static_cast<float>(resolution_[1]));
	lensDistortionMaterialInstance->SetScalarParameterValue(TEXT("principalpoint_x"), principalPoint_[0]);
	lensDistortionMaterialInstance->SetScalarParameterValue(TEXT("principalpoint_y"), principalPoint_[1]);

	TObjectPtr<UMaterialInstanceDynamic> depthMaterialInstance =
		sceneCaptureComponent->GetMaterialInstanceDynamic(VD_SENSOR::MaterialType::DEPTH);
	check(depthMaterialInstance != nullptr);
	const Eigen::Vector2f kDepthRangeMeterToCm = depthRange * 100.0f;
	depthMaterialInstance->SetScalarParameterValue(TEXT("min_depth"), kDepthRangeMeterToCm[0]);
	depthMaterialInstance->SetScalarParameterValue(TEXT("max_depth"), kDepthRangeMeterToCm[1]);

	TObjectPtr<UMaterialInstanceDynamic> cfaMaterialInstance =
		sceneCaptureComponent->GetMaterialInstanceDynamic(VD_SENSOR::MaterialType::CFA);
	check(cfaMaterialInstance != nullptr);

	cfaMaterialInstance->SetScalarParameterValue(TEXT("color_filter"), static_cast<float>(currentCFA));
	cfaMaterialInstance->SetScalarParameterValue(TEXT("resolution_x"), resolution_[0]);
	cfaMaterialInstance->SetScalarParameterValue(TEXT("resolution_y"), resolution_[1]);
}

TObjectPtr<UTextureRenderTarget2D> VDSensorCamera::GetCurrentTextureTarget() const
{
	return sceneCaptureComponent->GetCurrentTextureTarget();
}

void VDSensorCamera::SaveRenderTarget(const FString& pathIn, const FString& fileNameIn) const
{
	if (!imageExporter->SaveRenderTarget(pathIn, fileNameIn, sceneCaptureComponent->GetCurrentTextureTarget()))
	{
		UE_LOG(LogTemp, Warning, TEXT("Failed to save the captured scene"));
	}
}

void VDSensorCamera::SetCameraType(const VD_SENSOR::CameraType& cameraTypeIn)
{
	currentCameraType = cameraTypeIn;
	sceneCaptureComponent->SetCameraType(cameraTypeIn);
}

Eigen::Matrix4f VDSensorCamera::GetCameraViewIntrinsicMatrix() const
{
	/** Mathematic camera model for lens distortion/undistortion. (Reference: TPerspectiveMatrix)
	 *
	 * Camera matrix =
	 *  | F.X  0  C.x  0  |
	 *  |  0  F.Y C.Y  0  |
	 *  |  0   0   A   1  |
	 *  |  0   0   B   0  |
	 *
	 *  A = Far clip plane / (Far clip plane - Near clip plane)
	 *  B = -Near clip plane * Far clip plane / (Far clip plane - Near clip plane)
	 *
	 *  c.f. In the case of ReversedZ method, A and B equations should be changed like,
	 *        A = Near clip plane / (Near clip plane - Far clip plane)
	 *        B = -Far clip plane * Near clip plane / (Near clip plane - Far clip plane)
	 *
	 *       (The ReversedZ used to convert the output z-buffer into a depth value in UE)
	 */
	const float& kFx = ConvertCameraViewHorizontalFovToFocalLength(GetCameraViewHorizontalFov());
	const float& kFy = ConvertCameraViewVerticalFovToFocalLength(GetCameraViewVerticalFov());
	const float& kA =
		(depthRange[0] == depthRange[1]) ? (1.0f - Z_PRECISION) : depthRange[1] / (depthRange[1] - depthRange[0]);
	const float& kB = -depthRange[0]
		* ((depthRange[0] == depthRange[1]) ? (1.0f - Z_PRECISION) : depthRange[1] / (depthRange[1] - depthRange[0]));

	return (Eigen::Matrix4f() << kFx, 0.0f, principalPoint_[0], 0.0f, 0.0f, kFy, principalPoint_[1], 0.0f, 0.0f, 0.0f,
		kA, 1.0f, 0.0f, 0.0f, kB, 0.0f)
		.finished();
}

float VDSensorCamera::ConvertUnitPixel2MM(const float& focalLengthPixelUnitIn) const
{
	const float kPixelSizeXInPixelUnit = filmbackSettings_.sensorWidth / static_cast<float>(resolution_[0]);
	const float kPixelSizeYInPixelUnit = filmbackSettings_.sensorHeight / static_cast<float>(resolution_[1]);

	return kPixelSizeXInPixelUnit > kPixelSizeYInPixelUnit ? focalLengthPixelUnitIn * kPixelSizeYInPixelUnit
														   : focalLengthPixelUnitIn * kPixelSizeXInPixelUnit;
}

float VDSensorCamera::ConvertUnitMM2Pixel(const float& focalLengthMMUnitIn) const
{
	const float kPixelSizeXInMMUnit = static_cast<float>(resolution_[0]) / filmbackSettings_.sensorWidth;
	const float kPixelSizeYInMMUnit = static_cast<float>(resolution_[1]) / filmbackSettings_.sensorHeight;

	return kPixelSizeXInMMUnit <= kPixelSizeYInMMUnit ? focalLengthMMUnitIn * kPixelSizeYInMMUnit
													  : focalLengthMMUnitIn * kPixelSizeXInMMUnit;
}

void VDSensorCamera::SetBrownConradyLensDistortionParams(
	const VD_SENSOR::VDBrownConradyLensDistortionParams& distParamsIn)
{
	distortion_ = distParamsIn;

	UpdateDerivedData();
}

void VDSensorCamera::SetResolution(const uint32_t& widthIn, const uint32_t& heightIn)
{
	// TODO: Set limited resolution through a policy
	const uint32_t kWidth = std::clamp(widthIn, 0u, std::numeric_limits<uint32_t>().max());
	const uint32_t kHeight = std::clamp(heightIn, 0u, std::numeric_limits<uint32_t>().max());

	sceneCaptureComponent->ResizeAllTargetsResolution(kWidth, kHeight);

	resolution_ = Eigen::Vector2i { kWidth, kHeight };

	// Reset current principal points
	principalPoint_ = Eigen::Vector2f { static_cast<float>(kWidth) * 0.5f, static_cast<float>(kHeight) * 0.5f };

	UpdateDerivedData();
}

void VDSensorCamera::SetFocalLength(const float& focalLengthIn)
{
	const float kFocalLength = std::clamp(focalLengthIn, kEpsilon, std::numeric_limits<float>().max());

	currentFocalLength = ConvertUnitPixel2MM(kFocalLength);

	UpdateDerivedData();
}

void VDSensorCamera::SetPrincipalPoints(const float& principalPointsXIn, const float& principalPointsYIn)
{
	const float kPrincipalPointsX =
		std::clamp(principalPointsXIn, std::numeric_limits<float>().min(), std::numeric_limits<float>().max());
	const float kPrincipalPointsY =
		std::clamp(principalPointsYIn, std::numeric_limits<float>().min(), std::numeric_limits<float>().max());

	principalPoint_ = Eigen::Vector2f { kPrincipalPointsX, kPrincipalPointsY };

	UpdateDerivedData();
}

void VDSensorCamera::SetHorizontalFov(const float& fieldOfViewIn)
{
	const float kFov = std::clamp(fieldOfViewIn, kEpsilon, std::numeric_limits<float>().max());

	currentFocalLength = 0.5f * filmbackSettings_.sensorWidth / std::tan(Deg2Rad(kFov) * 0.5f);

	UpdateDerivedData();
}

float VDSensorCamera::GetHorizontalFov(const float& scaleIn) const
{
	if (currentFocalLength > 0.0f)
	{
		return Rad2Deg(2.0f * std::atan(scaleIn * filmbackSettings_.sensorWidth / (2.0f * currentFocalLength)));
	}
	return 0.0f;
}

void VDSensorCamera::SetVerticalFov(const float& fieldOfViewIn)
{
	const float& kFov = std::clamp(fieldOfViewIn, kEpsilon, std::numeric_limits<float>().max());

	currentFocalLength = 0.5f * filmbackSettings_.sensorHeight / std::tan(Deg2Rad(kFov) * 0.5f);

	UpdateDerivedData();
}

float VDSensorCamera::GetVerticalFov(const float& scaleIn) const
{
	if (currentFocalLength > 0.0f)
	{
		return Rad2Deg(2.0f * std::atan(scaleIn * filmbackSettings_.sensorHeight / (2.0f * currentFocalLength)));
	}
	return 0.0f;
}

float VDSensorCamera::GetCameraViewHorizontalFov(const float& scaleIn) const
{
	check(0.0f <= scaleIn && scaleIn <= std::numeric_limits<float>().max()
		&& "Input scale variable must be in the range of positivie float expression.");

	if (currentFocalLength > 0.0f)
	{
		const float& kResolutionAspectRatio =
			resolution_[1] > 0 ? static_cast<float>(resolution_[0]) / static_cast<float>(resolution_[1]) : 0.0f;

		if (kResolutionAspectRatio >= filmbackSettings_.sensorAspectRatio)
		{
			return GetHorizontalFov(scaleIn);
		}
		const float kSqueezeFactor = kResolutionAspectRatio / filmbackSettings_.sensorAspectRatio;
		const float kCroppedResolutionWidth = filmbackSettings_.sensorWidth * kSqueezeFactor;
		const float kCameraFov =
			Rad2Deg(2.0f * std::atan(scaleIn * kCroppedResolutionWidth / (2.0f * currentFocalLength)));
		return kCameraFov;
	}
	return 0.0f;
}

float VDSensorCamera::ConvertCameraViewHorizontalFovToFocalLength(const float& fovIn) const
{
	check(1e-5f <= fovIn && fovIn <= std::numeric_limits<float>().max()
		&& "Input field of view must be in the range of float expression.");

	if (fovIn > 0.0f)
	{
		const float kResolutionAspectRatio =
			resolution_[1] > 0 ? static_cast<float>(resolution_[0]) / static_cast<float>(resolution_[1]) : 0.0f;

		if (kResolutionAspectRatio >= filmbackSettings_.sensorAspectRatio)
		{
			return 0.5f * ConvertUnitMM2Pixel(filmbackSettings_.sensorWidth) / std::tan(Deg2Rad(0.5f * fovIn));
		}
		const float kDeSqueezeFactor = kResolutionAspectRatio / filmbackSettings_.sensorAspectRatio;
		const float kDeCroppedResolutionWidth = filmbackSettings_.sensorWidth * kDeSqueezeFactor;
		return 0.5f * ConvertUnitMM2Pixel(kDeCroppedResolutionWidth) / std::tan(Deg2Rad(0.5f * fovIn));
	}
	return 0.0f;
}

float VDSensorCamera::GetCameraViewVerticalFov(const float& scaleIn) const
{
	if (currentFocalLength > 0.0f)
	{
		const float kResolutionAspectRatio =
			resolution_[1] > 0 ? static_cast<float>(resolution_[0]) / static_cast<float>(resolution_[1]) : 0.0f;

		if (kResolutionAspectRatio < filmbackSettings_.sensorAspectRatio)
		{
			return GetVerticalFov(scaleIn);
		}
		const float kSqueezeFactor = filmbackSettings_.sensorAspectRatio / kResolutionAspectRatio;
		const float kCroppedResolutionHeight = filmbackSettings_.sensorHeight * kSqueezeFactor;
		const float kCameraFov =
			Rad2Deg(2.0f * std::atan(scaleIn * kCroppedResolutionHeight / (2.0f * currentFocalLength)));

		return kCameraFov;
	}
	return 0.0f;
}

float VDSensorCamera::ConvertCameraViewVerticalFovToFocalLength(const float& fovIn) const
{
	check(1e-5f <= fovIn && fovIn <= std::numeric_limits<float>().max()
		&& "Input field of view must be in the range of float expression.");

	if (fovIn > 0.0f)
	{
		const float kResolutionAspectRatio =
			resolution_[1] > 0 ? static_cast<float>(resolution_[0]) / static_cast<float>(resolution_[1]) : 0.0f;

		if (kResolutionAspectRatio >= filmbackSettings_.sensorAspectRatio)
		{
			return 0.5f * ConvertUnitMM2Pixel(filmbackSettings_.sensorHeight) / std::tan(Deg2Rad(0.5f * fovIn));
		}
		const float kDeSqueezeFactor = filmbackSettings_.sensorAspectRatio / kResolutionAspectRatio;
		const float kDeCroppedResolutionWidth = filmbackSettings_.sensorHeight * kDeSqueezeFactor;
		return 0.5f * ConvertUnitMM2Pixel(kDeCroppedResolutionWidth) / std::tan(Deg2Rad(0.5f * fovIn));
	}
	return 0.0f;
}

void VDSensorCamera::SetFilmbackSize(const float& sensorWidthIn, const float& sensorHeightIn)
{
	check(sensorWidthIn > 0.0f && sensorHeightIn > 0.0f && "Input Sensor size must be positive values");

	filmbackSettings_.sensorWidth = std::clamp(sensorWidthIn, 0.0f, std::numeric_limits<float>().max());
	filmbackSettings_.sensorHeight = std::clamp(sensorHeightIn, 0.0f, std::numeric_limits<float>().max());

	UpdateDerivedData();
}

void VDSensorCamera::SetColorFilterArray(const VD_SENSOR::ColorFilterArray& cfaIn)
{
	if (currentCameraType != VD_SENSOR::CameraType::RGB) return;

	currentCFA = cfaIn;

	sceneCaptureComponent->TextureTarget->bForceLinearGamma = currentCFA != VD_SENSOR::ColorFilterArray::NONE;

	UpdateDerivedData();
}

void VDSensorCamera::SetDepthRange(const float& minDepthIn, const float& maxDepthIn)
{
	if (minDepthIn == maxDepthIn) return;

	const float& kMinDepth = std::clamp(minDepthIn, 0.0f, std::numeric_limits<float>().max());
	const float& kMaxDepth = std::clamp(maxDepthIn, 0.0f, std::numeric_limits<float>().max());

	depthRange =
		kMinDepth < kMaxDepth ? Eigen::Vector2f { kMinDepth, kMaxDepth } : Eigen::Vector2f { kMaxDepth, kMinDepth };

	UpdateDerivedData();
}

bool VDSensorCamera::IsActivatedAutoSave() const
{
	check(imageExporter != nullptr
		&& "Failed to check that auto-save is activated because imageExporter is cuurrently nullptr");
	return imageExporter->IsActivatedAutoSave();
}

void VDSensorCamera::ActivateAutoSave() const
{
	check(imageExporter != nullptr && "Failed to enable auto-save because imageExporter is currently nullptr");
	imageExporter->ActivateAutoSave();
}

void VDSensorCamera::DeactivatedAutoSave() const
{
	check(imageExporter != nullptr && "Failed to disable auto-save because imageExporter is currently nullptr");
	imageExporter->DeactivateAutoSave();
}

Eigen::Vector2f VDSensorCamera::LensUndistortViewportUVIntoViewSpace(
	float kResolutionAspectRatio, Eigen::Vector2f DistortedViewportUV) const
{
	Eigen::Vector2f kViewPosition_ { DistortedViewportUV[0] - principalPoint_[0] / static_cast<float>(resolution_[0]),
		DistortedViewportUV[1] - principalPoint_[1] / static_cast<float>(resolution_[1]) };
	kViewPosition_[1] = kViewPosition_[1] * kResolutionAspectRatio;
	return kViewPosition_;
}

float VDSensorCamera::GetOverScanFov() const
{
	const float kResolutionAspectRatio =
		resolution_[1] > 0 ? static_cast<float>(resolution_[0]) / static_cast<float>(resolution_[1]) : 0.0f;

	// Get the position in the view space at z'=1 of different key point in the distorted Viewport UV coordinate system.
	// This very approximative to know the required overscan scale factor of the undistorted viewport, but works really
	// well in practice.
	//
	//  Undistorted UV position in the view space:
	//
	//        0        1        2
	//
	//        7        0        3 --> View space's X
	//
	//        6        5        4
	//                 | View space's Y

	const Eigen::Vector2f kUndistortCornerPos0_ { LensUndistortViewportUVIntoViewSpace(
		kResolutionAspectRatio, Eigen::Vector2f { 0.0f, 0.0f }) };
	const Eigen::Vector2f kUndistortCornerPos1_ { LensUndistortViewportUVIntoViewSpace(
		kResolutionAspectRatio, Eigen::Vector2f { 0.5f, 0.0f }) };
	const Eigen::Vector2f kUndistortCornerPos2_ { LensUndistortViewportUVIntoViewSpace(
		kResolutionAspectRatio, Eigen::Vector2f { 1.0f, 0.0f }) };
	const Eigen::Vector2f kUndistortCornerPos3_ { LensUndistortViewportUVIntoViewSpace(
		kResolutionAspectRatio, Eigen::Vector2f { 1.0f, 0.5f }) };
	const Eigen::Vector2f kUndistortCornerPos4_ { LensUndistortViewportUVIntoViewSpace(
		kResolutionAspectRatio, Eigen::Vector2f { 1.0f, 1.0f }) };
	const Eigen::Vector2f kUndistortCornerPos5_ { LensUndistortViewportUVIntoViewSpace(
		kResolutionAspectRatio, Eigen::Vector2f { 0.5f, 1.0f }) };
	const Eigen::Vector2f kUndistortCornerPos6_ { LensUndistortViewportUVIntoViewSpace(
		kResolutionAspectRatio, Eigen::Vector2f { 0.0f, 1.0f }) };
	const Eigen::Vector2f kUndistortCornerPos7_ { LensUndistortViewportUVIntoViewSpace(
		kResolutionAspectRatio, Eigen::Vector2f { 0.0f, 0.5f }) };

	// Find min and max of the inner square of undistorted Viewport in the view space at z'=1.
	const float kMinInnerViewportRectX =
		std::max(std::max(kUndistortCornerPos0_[0], kUndistortCornerPos6_[0]), kUndistortCornerPos7_[0]);
	const float kMinInnerViewportRectY =
		std::max(std::max(kUndistortCornerPos0_[1], kUndistortCornerPos1_[1]), kUndistortCornerPos2_[1]);
	const float kMaxInnerViewportRectX =
		std::max(std::max(kUndistortCornerPos2_[0], kUndistortCornerPos3_[0]), kUndistortCornerPos4_[0]);
	const float kMaxInnerViewportRectY =
		std::max(std::max(kUndistortCornerPos4_[1], kUndistortCornerPos5_[1]), kUndistortCornerPos6_[1]);

	check(kMinInnerViewportRectX < 0.0f);
	check(kMinInnerViewportRectY < 0.0f);
	check(kMaxInnerViewportRectX > 0.0f);
	check(kMaxInnerViewportRectY > 0.0f);

	// Compute the required undistorted viewport scale on each axes.
	const float kOverscanScaleFactorX = 2.0f * std::max(-kMinInnerViewportRectX, kMaxInnerViewportRectX);
	const float kOverscanScaleFactorY = 2.0f * std::max(-kMinInnerViewportRectY, kMaxInnerViewportRectY);

	const float kViewportScaleUpFactorPerView =
		std::max(GetCameraViewHorizontalFov(kOverscanScaleFactorX), GetCameraViewVerticalFov(kOverscanScaleFactorY));

	/*
	 * [TEMP] @gishin Lens distortion over-scan factor
	 * Scale up by 2% more the undistorted viewport size in the view space to work
	 * around the fact that odd undistorted positions might not exactly be at the minimal
	 * in case of a tangential distorted barrel lens distortion.
	 */
	constexpr float kViewportScaleUpConstMultiplier = 1.0f;

	return kViewportScaleUpFactorPerView * kViewportScaleUpConstMultiplier;
}

void VDSensorCamera::DrawFrustumImageView() const
{
	float hFov = GetHorizontalFov() * 0.5f;
	float vFov = GetVerticalFov() * 0.5f;

	FRotator rotA_(vFov, hFov, 0);
	FRotator rotB_(vFov, -hFov, 0);
	FRotator rotC_(-vFov, hFov, 0);
	FRotator rotD_(-vFov, -hFov, 0);

	FRotator resultRotA_ = UKismetMathLibrary::ComposeRotators(rotA_, rootComponent->GetComponentTransform().Rotator());
	FRotator resultRotB_ = UKismetMathLibrary::ComposeRotators(rotB_, rootComponent->GetComponentTransform().Rotator());
	FRotator resultRotC_ = UKismetMathLibrary::ComposeRotators(rotC_, rootComponent->GetComponentTransform().Rotator());
	FRotator resultRotD_ = UKismetMathLibrary::ComposeRotators(rotD_, rootComponent->GetComponentTransform().Rotator());

	hFov = Deg2Rad(hFov);
	vFov = Deg2Rad(vFov);
	FVector sensorOrigin_ = rootComponent->GetComponentTransform().GetLocation();

	constexpr float nearDistance = 0.0f;
	constexpr float farDistance = 1000.0f;

	const double endBase = farDistance / std::cos(hFov) / std::cos(vFov);
	FVector endA_ = endBase * UKismetMathLibrary::GetForwardVector(resultRotA_) + sensorOrigin_;
	FVector endB_ = endBase * UKismetMathLibrary::GetForwardVector(resultRotB_) + sensorOrigin_;
	FVector endC_ = endBase * UKismetMathLibrary::GetForwardVector(resultRotC_) + sensorOrigin_;
	FVector endD_ = endBase * UKismetMathLibrary::GetForwardVector(resultRotD_) + sensorOrigin_;

	const double nearBase = nearDistance / std::cos(hFov) / std::cos(vFov);

	FVector nearA_ = nearBase * UKismetMathLibrary::GetForwardVector(resultRotA_) + sensorOrigin_;
	FVector nearB_ = nearBase * UKismetMathLibrary::GetForwardVector(resultRotB_) + sensorOrigin_;
	FVector nearC_ = nearBase * UKismetMathLibrary::GetForwardVector(resultRotC_) + sensorOrigin_;
	FVector nearD_ = nearBase * UKismetMathLibrary::GetForwardVector(resultRotD_) + sensorOrigin_;

	DrawDebugLine(world, nearA_, endA_, FColor::Purple, false, -1, 0, 10.0f);
	DrawDebugLine(world, endA_, endB_, FColor::Purple, false, -1, 0, 10.0f);
	DrawDebugLine(world, nearA_, nearB_, FColor::Purple, false, -1, 0, 10.0f);

	DrawDebugLine(world, nearB_, endB_, FColor::Purple, false, -1, 0, 10.0f);
	DrawDebugLine(world, endB_, endD_, FColor::Purple, false, -1, 0, 10.0f);
	DrawDebugLine(world, nearB_, nearD_, FColor::Purple, false, -1, 0, 10.0f);

	DrawDebugLine(world, nearC_, endC_, FColor::Purple, false, -1, 0, 10.0f);
	DrawDebugLine(world, endD_, endC_, FColor::Purple, false, -1, 0, 10.0f);
	DrawDebugLine(world, nearD_, nearC_, FColor::Purple, false, -1, 0, 10.0f);

	DrawDebugLine(world, nearD_, endD_, FColor::Purple, false, -1, 0, 10.0f);
	DrawDebugLine(world, endC_, endA_, FColor::Purple, false, -1, 0, 10.0f);
	DrawDebugLine(world, nearC_, nearA_, FColor::Purple, false, -1, 0, 10.0f);
}

void VDSensorCamera::DrawFrustumResolutionView() const
{
	float hFov = GetCameraViewHorizontalFov() * 0.5f;
	float vFov = GetCameraViewVerticalFov() * 0.5f;

	// DrawFrustum
	FRotator rotA_(vFov, hFov, 0);
	FRotator rotB_(vFov, -hFov, 0);
	FRotator rotC_(-vFov, hFov, 0);
	FRotator rotD_(-vFov, -hFov, 0);

	FRotator resultRotA_ = UKismetMathLibrary::ComposeRotators(rotA_, rootComponent->GetComponentTransform().Rotator());
	FRotator resultRotB_ = UKismetMathLibrary::ComposeRotators(rotB_, rootComponent->GetComponentTransform().Rotator());
	FRotator resultRotC_ = UKismetMathLibrary::ComposeRotators(rotC_, rootComponent->GetComponentTransform().Rotator());
	FRotator resultRotD_ = UKismetMathLibrary::ComposeRotators(rotD_, rootComponent->GetComponentTransform().Rotator());

	hFov = Deg2Rad(hFov);
	vFov = Deg2Rad(vFov);
	FVector sensorOrigin_ = rootComponent->GetComponentTransform().GetLocation();

	constexpr float nearDistance = 0.0f;
	constexpr float farDistance = 1000.0f;

	const double endBase = farDistance / std::cos(hFov) / std::cos(vFov);
	FVector endA_ = endBase * UKismetMathLibrary::GetForwardVector(resultRotA_) + sensorOrigin_;
	FVector endB_ = endBase * UKismetMathLibrary::GetForwardVector(resultRotB_) + sensorOrigin_;
	FVector endC_ = endBase * UKismetMathLibrary::GetForwardVector(resultRotC_) + sensorOrigin_;
	FVector endD_ = endBase * UKismetMathLibrary::GetForwardVector(resultRotD_) + sensorOrigin_;

	const double nearBase = nearDistance / std::cos(hFov) / std::cos(vFov);
	FVector nearA_ = nearBase * UKismetMathLibrary::GetForwardVector(resultRotA_) + sensorOrigin_;
	FVector nearB_ = nearBase * UKismetMathLibrary::GetForwardVector(resultRotB_) + sensorOrigin_;
	FVector nearC_ = nearBase * UKismetMathLibrary::GetForwardVector(resultRotC_) + sensorOrigin_;
	FVector nearD_ = nearBase * UKismetMathLibrary::GetForwardVector(resultRotD_) + sensorOrigin_;

	DrawDebugLine(world, nearA_, endA_, FColor::Red, false, -1, 0, 10.0f);
	DrawDebugLine(world, endA_, endB_, FColor::Red, false, -1, 0, 10.0f);
	DrawDebugLine(world, nearA_, nearB_, FColor::Red, false, -1, 0, 10.0f);

	DrawDebugLine(world, nearB_, endB_, FColor::Red, false, -1, 0, 10.0f);
	DrawDebugLine(world, endB_, endD_, FColor::Red, false, -1, 0, 10.0f);
	DrawDebugLine(world, nearB_, nearD_, FColor::Red, false, -1, 0, 10.0f);

	DrawDebugLine(world, nearC_, endC_, FColor::Red, false, -1, 0, 10.0f);
	DrawDebugLine(world, endD_, endC_, FColor::Red, false, -1, 0, 10.0f);
	DrawDebugLine(world, nearD_, nearC_, FColor::Red, false, -1, 0, 10.0f);

	DrawDebugLine(world, nearD_, endD_, FColor::Red, false, -1, 0, 10.0f);
	DrawDebugLine(world, endC_, endA_, FColor::Red, false, -1, 0, 10.0f);
	DrawDebugLine(world, nearC_, nearA_, FColor::Red, false, -1, 0, 10.0f);
}

/* Async 스레드 관련 */
void VDSensorCamera::InitAndRunThread(const float& threadSleepTimeIn)
{
	ReleaseThread();

	const FTimespan kThreadSleepTime = FTimespan::FromMilliseconds(threadSleepTimeIn);
	sensorThread = new VDSensorThreadProcess(kThreadSleepTime, TEXT("CameraThread"), this);
	// FRunnableThread will trigger Run() immediately after Init() has been successfully executed.
	sensorThread->Init();
	// UE_LOG(LogTemp, Warning, TEXT("Camera thread initialized!"));
}

void VDSensorCamera::UpdateThreadProcess()
{
	if (!IsActivatedAutoSave()) return;
	imageExporter->PopRenderRequest();
}

void VDSensorCamera::ReleaseThread()
{
	if (sensorThread)
	{
		sensorThread->Stop();
		delete sensorThread;
		sensorThread = nullptr;
	}
}
