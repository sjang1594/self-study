﻿#include "VDCamera/VDImageExporter.h"

#include "ImageUtils.h"

UVDImageExporter::UVDImageExporter(const FObjectInitializer& objectInitializerIn) : Super(objectInitializerIn)
{
	bAutoSave = false;
	bUsePNG = true;
	sensorPeriod = 1.0f;
	numDigits = 9;
	imgCounter = 0u;

	saveDirPath = FPaths::ProjectSavedDir();
}

bool UVDImageExporter::SaveRenderTarget(
	const FString& pathIn, const FString& fileNameIn, const TObjectPtr<UTextureRenderTarget2D> textureTargetIn)
{
	check(IsValid(textureTargetIn));

	FTextureRenderTargetResource* resource = textureTargetIn->GameThread_GetRenderTargetResource();
	const FIntPoint imageSize(textureTargetIn->GetSurfaceWidth(), textureTargetIn->GetSurfaceHeight());
	TArray<FColor> outBMP;
	outBMP.AddZeroed(imageSize.X * imageSize.Y);

	auto saveImageToDisk = [&](const ERawImageFormat::Type& format, const auto& bmpOut) -> void {
		check(bmpOut.Num() > 0 && imageSize.X > 0 && imageSize.Y > 0);
		FImageView resultImage((void*) bmpOut.GetData(), imageSize.X, imageSize.Y, format);
		RunAsyncImageSaveTask(pathIn, fileNameIn, resultImage);
	};

	switch (textureTargetIn->GetFormat())
	{
	case EPixelFormat::PF_R8G8B8A8:
	{
		const FReadSurfaceDataFlags kReadPixelFlags(RCM_UNorm);
		if (resource->ReadPixels(outBMP, kReadPixelFlags))
		{
			saveImageToDisk(ERawImageFormat::BGRA8, outBMP);
			return true;
		}
	}
	case EPixelFormat::PF_FloatRGBA: // Not used
	{
		TArray<FFloat16Color> floatOutBMP;
		floatOutBMP.AddZeroed(imageSize.X * imageSize.Y);
		if (resource->ReadFloat16Pixels(floatOutBMP))
		{
			saveImageToDisk(ERawImageFormat::RGBA16F, floatOutBMP);
			return true;
		}
	}
	case EPixelFormat::PF_G8:
	{
		const FReadSurfaceDataFlags kReadPixelFlags(RCM_UNorm);
		if (resource->ReadPixels(outBMP, kReadPixelFlags))
		{
			saveImageToDisk(ERawImageFormat::G8, outBMP);
			return true;
		}
	}
	default:
	{
		const FReadSurfaceDataFlags kReadPixelFlags(RCM_UNorm);
		if (resource->ReadPixels(outBMP, kReadPixelFlags))
		{
			saveImageToDisk(ERawImageFormat::BGRA8, outBMP);
			return true;
		}
	}
	}
	return false;
}

void UVDImageExporter::EnqueueRenderRequest(const TObjectPtr<UTextureRenderTarget2D>& textureTargetIn)
{
	check(IsValid(textureTargetIn));

	FTextureRenderTargetResource* renderTargetResource = textureTargetIn->GameThread_GetRenderTargetResource();

	FRenderRequestStruct* renderRequest_ = new FRenderRequestStruct;
	renderRequest_->width = renderTargetResource->GetSizeX();
	renderRequest_->height = renderTargetResource->GetSizeY();
	renderRequest_->dataFormat = textureTargetIn->GetFormat();

	FReadSurfaceContext readSurfaceContext_ = { renderTargetResource->GetTextureRHI(), &(renderRequest_->image),
		FIntRect(0, 0, renderTargetResource->GetSizeX(), renderTargetResource->GetSizeY()),
		FReadSurfaceDataFlags(RCM_UNorm, CubeFace_MAX) };

	renderRequestQueue.Enqueue(MoveTemp(renderRequest_));

	ENQUEUE_RENDER_COMMAND(SceneDrawCompletion)
	([readSurfaceContext_](FRHICommandListImmediate& RHICmdList) {
		FIntPoint resolution = readSurfaceContext_.SrcRenderTarget->GetSizeXY();
		RHICmdList.ReadSurfaceData(readSurfaceContext_.SrcRenderTarget, FIntRect(0, 0, resolution.X, resolution.Y),
			*readSurfaceContext_.OutData, readSurfaceContext_.Flags);
	});
	FlushRenderingCommands();
	renderRequest_->bIsReadyToExport = true;
}

void UVDImageExporter::PopRenderRequest()
{
	if (!renderRequestQueue.IsEmpty())
	{
		FRenderRequestStruct* nextRenderRequest_ = nullptr;

		if (renderRequestQueue.Peek(nextRenderRequest_) && nextRenderRequest_->bIsReadyToExport)
		{
			check(nextRenderRequest_->image.GetAllocatedSize() > 0 && nextRenderRequest_->width > 0
				&& nextRenderRequest_->height > 0);
			TArray<FColor> outBMP = nextRenderRequest_->image;
			FImageView resultImage((void*) outBMP.GetData(), nextRenderRequest_->width, nextRenderRequest_->height, 1,
				ERawImageFormat::BGRA8, EGammaSpace::sRGB);
			FString fileName = "img_" + ToStringWithLeadingZeros(imgCounter, numDigits);
			fileName += bUsePNG ? ".png" : ".jpeg";
			RunAsyncImageSaveTask(saveDirPath, fileName, resultImage);
			imgCounter++;
			renderRequestQueue.Pop();
			nextRenderRequest_ = nullptr;
		}
	}
}

uint8_t* UVDImageExporter::EncodeByteArray(const TObjectPtr<UTextureRenderTarget2D> textureTargetIn)
{
	check(IsValid(textureTargetIn));

	FRenderTarget* resource = textureTargetIn->GameThread_GetRenderTargetResource();
	const FIntPoint imageSize(textureTargetIn->GetSurfaceWidth(), textureTargetIn->GetSurfaceHeight());
	const EPixelFormat format = textureTargetIn->GetFormat();
	const int imageBytesNum = CalculateImageBytes(textureTargetIn->SizeX, textureTargetIn->SizeY, 0, format);

	TArray<uint8_t> sensorData;

	sensorData.AddZeroed(imageBytesNum);

	switch (format)
	{
	case EPixelFormat::PF_R8G8B8A8:
	{
		if (resource->ReadPixelsPtr(reinterpret_cast<FColor*>(sensorData.GetData())))
		{
			uint8_t* ret = sensorData.GetData();
			return MoveTemp(ret);
		}
	}
	case EPixelFormat::PF_FloatRGBA: // Not used
	{
		TArray<FFloat16Color> outBMP;
		outBMP.AddZeroed(imageSize.X * imageSize.Y);
		if (resource->ReadFloat16Pixels(outBMP))
		{
			FMemory::Memcpy(sensorData.GetData(), outBMP.GetData(), imageBytesNum);
			uint8_t* ret = sensorData.GetData();
			return MoveTemp(ret);
		}
	}
	case EPixelFormat::PF_G8:
	{
		if (resource->ReadPixelsPtr(reinterpret_cast<FColor*>(sensorData.GetData())))
		{
			uint8_t* ret = sensorData.GetData();
			return MoveTemp(ret);
		}
		TArray<FColor> outBMP;
		outBMP.AddZeroed(imageSize.X * imageSize.Y);
		const FReadSurfaceDataFlags kReadPixelFlags(RCM_UNorm);
		if (resource->ReadPixels(outBMP, kReadPixelFlags))
		{
			FMemory::Memcpy(sensorData.GetData(), outBMP.GetData(), imageBytesNum);
			uint8_t* ret = sensorData.GetData();
			return MoveTemp(ret);
		}
	}
	default:
		if (resource->ReadPixelsPtr(reinterpret_cast<FColor*>(sensorData.GetData())))
		{
			uint8_t* ret = sensorData.GetData();
			return MoveTemp(ret);
		}
	}
	sensorData.Empty();
	UE_LOG(LogTemp, Warning, TEXT("ReadPixels is not working. Data is Empty."));
	uint8_t* ret = sensorData.GetData();
	return MoveTemp(ret);
}

TArray<float> UVDImageExporter::DecodeDepthIntToFloat(const TArray<FColor>& intDepthIn)
{
	TArray<float> outBmp;
	outBmp.AddZeroed(intDepthIn.GetAllocatedSize());

	ParallelFor(outBmp.Num(), [&](int idx) {
		TRACE_CPUPROFILER_EVENT_SCOPE(ParallelForTask);
		FColor encodedColor = static_cast<FColor>(intDepthIn[idx]);
		FVector3f decodedColor = FVector3f(1.0, 1.0f / 256.0, 1.0f / (256.0 * 256.0));
		float ret = static_cast<float>(encodedColor.R) * decodedColor.X;
		ret += static_cast<float>(encodedColor.G) * decodedColor.Y;
		ret += static_cast<float>(encodedColor.B) * decodedColor.Z;
		outBmp[idx] = ret * (256.0 * 256.0 * 256.0) / (256.0 * 256.0 * 256.0 - 1.0);
	});
	return outBmp;
}

void UVDImageExporter::SetSensorPeriod(const float& sensorPeriodIn)
{
	if (sensorPeriod <= 0.0f) return;

	sensorPeriod = sensorPeriodIn;
}

FString UVDImageExporter::ToStringWithLeadingZeros(const int& integer, const int& maxDigits)
{
	const FString& kCurrentImageNumber = FString::FromInt(integer);
	const size_t& kStringSize = kCurrentImageNumber.Len();
	const int& kStringDelta = maxDigits - kStringSize;
	if (kStringDelta < 0)
	{
		UE_LOG(LogTemp, Error, TEXT("MaxDigits of ImageCounter Overflow!"));
		return kCurrentImageNumber;
	}

	FString leadingZeros = "";
	for (size_t i = 0; i < kStringDelta; i++)
	{
		leadingZeros += "0";
	}

	return leadingZeros + kCurrentImageNumber;
}

void UVDImageExporter::RunAsyncImageSaveTask(
	const FString& pathIn, const FString& fileNameIn, const FImageView& outBmpIn)
{
	(new FAutoDeleteAsyncTask<AsyncSaveImageToDiskTask>(pathIn, fileNameIn, outBmpIn))->StartBackgroundTask();
}

AsyncSaveImageToDiskTask::AsyncSaveImageToDiskTask(
	const FString& directoryPathIn, const FString& fileNameIn, const FImageView& outBmpIn)
{
	imageCopy = outBmpIn;
	FileName = FPaths::Combine(directoryPathIn, fileNameIn);
}

void AsyncSaveImageToDiskTask::DoWork() const
{
	FImageUtils::SaveImageByExtension(*FileName, imageCopy);
}
