#include "VDGNSS/VDGNSSConverter.h"

bool VDGNSSConverter::GetEllipsoidInfo(EllipsoidModel eidIn, EllipsoidModelData& dataOut)
{
	bool bResult = false;
	if (ellipsoidModelDb.find(eidIn) != ellipsoidModelDb.end())
	{
		memcpy(&dataOut, &ellipsoidModelDb.at(eidIn), sizeof(dataOut));
		bResult = true;
	}
	return bResult;
}

void VDGNSSConverter::UtmToWgs(WGSData& coreDataOut, EllipsoidModelData ellipIn, UTMData utmIn, double altitudeIn)
{
	/* Lat and Long are in degrees
	 * North latitudes and East Longitudes are positive. */
	double a = ellipIn.equatorialRadius;
	double ee = 2 / ellipIn.inverseFlattening - 1 / (ellipIn.inverseFlattening * ellipIn.inverseFlattening);
	double EE = ee / (1 - ee);
	double e1 = (1 - sqrt(1 - ee)) / (1 + sqrt(1 - ee));
	double N1, T1, C1, R1, D, M, mu, phi1Rad;
	double x = utmIn.easting - 500000.0; // remove 500,000 meter offset for longitude
	double y = utmIn.northing;
	double longOrigin = utmIn.zone * 6 - 183; // origin in middle of zone

	M = y / kK0;
	mu = M / (a * (1 - ee / 4 - 3 * ee * ee / 64 - 5 * ee * ee * ee / 256));

	phi1Rad = mu + (3 * e1 / 2 - 27 * e1 * e1 * e1 / 32) * sin(2 * mu)
		+ (21 * e1 * e1 / 16 - 55 * e1 * e1 * e1 * e1 / 32) * sin(4 * mu) + (151 * e1 * e1 * e1 / 96) * sin(6 * mu);
	N1 = a / sqrt(1 - ee * sin(phi1Rad) * sin(phi1Rad));
	T1 = tan(phi1Rad) * tan(phi1Rad);
	C1 = EE * cos(phi1Rad) * cos(phi1Rad);
	R1 = a * (1 - ee) / pow(1 - ee * sin(phi1Rad) * sin(phi1Rad), 1.5);
	D = x / (N1 * kK0);

	coreDataOut.latitude = phi1Rad
		- (N1 * tan(phi1Rad) / R1)
			* (D * D / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * EE) * D * D * D * D / 24
				+ (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * EE - 3 * C1 * C1) * D * D * D * D * D * D / 720);
	coreDataOut.latitude *= rad2Deg;
	coreDataOut.longitude =
		(D - (1 + 2 * T1 + C1) * D * D * D / 6
			+ (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * EE + 24 * T1 * T1) * D * D * D * D * D / 120)
		/ cos(phi1Rad);
	coreDataOut.longitude = longOrigin + coreDataOut.longitude * rad2Deg;
	coreDataOut.altitude = altitudeIn;
}

void VDGNSSConverter::WgsToUtm(UTMData& coreDataOut, EllipsoidModelData ellipIn, WGSData wgsIn, double altitudeIn)
{
	double a = ellipIn.equatorialRadius;
	double ee = 2 / ellipIn.inverseFlattening - 1 / (ellipIn.inverseFlattening * ellipIn.inverseFlattening);
	wgsIn.longitude -= int((wgsIn.longitude + 180) / 360) * 360;
	double N, T, C, A, M;
	double latRad = wgsIn.latitude * deg2Rad;
	double longRad = wgsIn.longitude * deg2Rad;

	coreDataOut.zone = int((wgsIn.longitude + 186) / 6);
	if (wgsIn.latitude >= 56.0 && wgsIn.latitude < 64.0 && wgsIn.longitude >= 3.0 && wgsIn.longitude < 12.0)
		coreDataOut.zone = 32;
	if (wgsIn.latitude >= 72.0 && wgsIn.latitude < 84.0)
	{
		if (wgsIn.longitude >= 0.0 && wgsIn.longitude < 9.0)
			coreDataOut.zone = 31;
		else if (wgsIn.longitude >= 9.0 && wgsIn.longitude < 21.0)
			coreDataOut.zone = 33;
		else if (wgsIn.longitude >= 21.0 && wgsIn.longitude < 33.0)
			coreDataOut.zone = 35;
		else if (wgsIn.longitude >= 33.0 && wgsIn.longitude < 42.0)
			coreDataOut.zone = 37;
	}
	double longOrigin = coreDataOut.zone * 6 - 183;
	double longOriginRad = longOrigin * deg2Rad;

	double EE = ee / (1 - ee);

	N = a / sqrt(1 - ee * sin(latRad) * sin(latRad));
	T = tan(latRad) * tan(latRad);
	C = EE * cos(latRad) * cos(latRad);
	A = cos(latRad) * (longRad - longOriginRad);

	M = a
		* ((1 - ee / 4 - 3 * ee * ee / 64 - 5 * ee * ee * ee / 256) * latRad
			- (3 * ee / 8 + 3 * ee * ee / 32 + 45 * ee * ee * ee / 1024) * sin(2 * latRad)
			+ (15 * ee * ee / 256 + 45 * ee * ee * ee / 1024) * sin(4 * latRad)
			- (35 * ee * ee * ee / 3072) * sin(6 * latRad));

	coreDataOut.easting =
		kK0 * N * (A + (1 - T + C) * A * A * A / 6 + (5 - 18 * T + T * T + 72 * C - 58 * EE) * A * A * A * A * A / 120)
		+ 500000.0;

	coreDataOut.northing = kK0
		* (M
			+ N * tan(latRad)
				* (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A * A * A * A / 24
					+ (61 - 58 * T + T * T + 600 * C - 330 * EE) * A * A * A * A * A * A / 720));
}

bool VDGNSSConverter::UtmToWgsPosition(WGSData& coreDataOut, EllipsoidModel eidIn, UTMData utmIn, double altitudeIn)
{
	bool bResult = false;
	EllipsoidModelData eData_;
	if (GetEllipsoidInfo(eidIn, eData_))
	{
		UtmToWgs(coreDataOut, eData_, utmIn, altitudeIn);
		bResult = true;
	}
	return bResult;
}

bool VDGNSSConverter::WgsToUtmPosition(UTMData& coreDataOut, EllipsoidModel eidIn, WGSData wgsIn, double altitudeIn)
{
	bool bResult = false;
	EllipsoidModelData eData_;
	if (GetEllipsoidInfo(eidIn, eData_))
	{
		WgsToUtm(coreDataOut, eData_, wgsIn, altitudeIn);
		bResult = true;
	}

	return bResult;
}

void VDGNSSConverter::UeToUtmPosition(const FVector uePositionIn, UTMData& utmPositionOut, const FVector mapUtmOriginIn)
{
	utmPositionOut.easting = uePositionIn.X + mapUtmOriginIn.X;
	utmPositionOut.northing = -1.0f * uePositionIn.Y + mapUtmOriginIn.Y;
	//_UTMPosition.zone = xx;
}

UTMData VDGNSSConverter::UeToUtmPosition(const FVector uePositionIn, const FVector mapUtmOriginIn)
{
	UTMData utmPosition_;
	UeToUtmPosition(uePositionIn, utmPosition_, mapUtmOriginIn);
	return utmPosition_;
}
