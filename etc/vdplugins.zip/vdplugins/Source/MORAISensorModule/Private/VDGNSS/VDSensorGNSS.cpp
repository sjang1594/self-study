#include "VDGNSS/VDSensorGNSS.h"

typedef VDSensorBase Super;

VDSensorGNSS::~VDSensorGNSS()
{
	if (sensorData_ != nullptr)
	{
		delete sensorData_;
		sensorData_ = nullptr;
	}

	if ((!bIsMapUtmOriginInit) && (mapUtmOrigin != nullptr))
	{
		delete mapUtmOrigin;
		bIsMapUtmOriginInit = false;
	}
}

void VDSensorGNSS::Initialize()
{
	Super::Initialize();
	/* [SUPERNAL / UAM] */
	if (!HasMapUtmOrigin())
	{
		if (bIsJsbSimLoad)
		{
			SetDefaultMapUtmOrigin();
		}
		else
		{
			UTMData* utmPosition_ = new UTMData();
			WGSData wgs;
			wgs.SetData(eastOffset, northOffset, altitude);
			VDGNSSConverter::WgsToUtmPosition(*utmPosition_, ellipsoidModelId, wgs, wgs.altitude);
			mapUtmOrigin = new FVector(utmPosition_->easting, utmPosition_->northing, 0.0);
			WarningLog(TEXT("Map UTM Origin is not defined. It is set to Duluth Airport Origin(Approximated)."));
			delete utmPosition_;
		}
	}
	//
}

void VDSensorGNSS::Release()
{
	Super::Release();
	if (sensorData_ != nullptr)
	{
		delete sensorData_;
		sensorData_ = nullptr;
	}

	if ((!bIsMapUtmOriginInit) && (mapUtmOrigin != nullptr))
	{
		delete mapUtmOrigin;
		bIsMapUtmOriginInit = false;
	}
}

void VDSensorGNSS::Update(const float deltaTimeIn)
{
	Super::Update(deltaTimeIn);

	if (HasRootComponent())
	{
		/* [NSR] */
		if (!bIsJsbSimLoad)
		{
			FVector gnssNoiseVector_ = FVector(gnssNoise.GaussianNoise(0.0, 0.1));
			FVector uePosition_ = rootComponent->GetComponentTransform().GetLocation() / 100 + gnssNoiseVector_;
			UTMData utmPosition_ = UeToUtmPosition(uePosition_, *mapUtmOrigin);
			utmPosition_.zone = 15; // TODO: Magic number ..
			WGSData* wgsPosition_ = new WGSData();
			VDGNSSConverter::UtmToWgsPosition(*wgsPosition_, ellipsoidModelId, utmPosition_, uePosition_.Z);
			sensorData_->latitude = wgsPosition_->latitude;
			sensorData_->longitude = wgsPosition_->longitude;
			sensorData_->altitude = wgsPosition_->altitude;
			sensorData_->eastOffset = mapUtmOrigin->X;
			sensorData_->northOffset = mapUtmOrigin->Y;
			delete wgsPosition_;
		}
		else
		{
			/* [SUPERNAL / UAM] */
			if (HasMapUtmOrigin())
			{
				// TODO: why setting default UTM origin is redefined ? //
				SetDefaultMapUtmOrigin();
				FVector uePosition_ = rootComponent->GetComponentTransform().GetLocation() / 100;
				UTMData utmPosition_ = UeToUtmPosition(uePosition_, *mapUtmOrigin);
				// TODO: Magic number
				utmPosition_.zone = 10;
				WGSData* wgsPosition_ = new WGSData();
				VDGNSSConverter::UtmToWgsPosition(*wgsPosition_, ellipsoidModelId, utmPosition_, uePosition_.Z);
				sensorData_->latitude = wgsPosition_->latitude;
				sensorData_->longitude = wgsPosition_->longitude;
				sensorData_->altitude = wgsPosition_->altitude;
				sensorData_->eastOffset = mapUtmOrigin->X;
				sensorData_->northOffset = mapUtmOrigin->Y;
				delete wgsPosition_;
			}
		}

		// [DEBUG] //
		UE_LOG(LogTemp, Log, TEXT("GNSS Data : %f, %f, %f, %f, %f"), sensorData_->latitude, sensorData_->longitude,
			sensorData_->altitude, sensorData_->eastOffset, sensorData_->northOffset);
	}
}

void VDSensorGNSS::SetUtmOrigin(const FVector* originIn)
{
	mapUtmOrigin = originIn;
	bIsMapUtmOriginInit = true;
}

FVector VDSensorGNSS::GetUtmOrigin()
{
	if (mapUtmOrigin != nullptr)
	{
		return *mapUtmOrigin;
	}
	return FVector(mapUtmOrigin->X, mapUtmOrigin->Y, mapUtmOrigin->Z);
}

void VDSensorGNSS::SetMapOffset(double eastOffsetIn, double northOffsetIn, double altIn)
{
	eastOffset = eastOffsetIn;
	northOffset = northOffsetIn;
	altitude = altIn;
}

// Set San Fransisco Map / Duluth Utm Origin as default for Map [SUPERNAL / UAM] //
void VDSensorGNSS::SetDefaultMapUtmOrigin()
{
	mapUtmOrigin = new FVector(595429.088, 4135888.208, 0.0);
	// WarningLog(TEXT("Map UTM Origin is not defined. It is set to Duluth Airport Origin(Approximated)."));
}

void VDSensorGNSS::SetMapUtmOrigin() {}

void VDSensorGNSS::UeToUtmPosition(const FVector& uePositionIn, UTMData& utmPositionOut, const FVector& mapUtmOriginIn)
{
	utmPositionOut.easting = uePositionIn.X + mapUtmOriginIn.X;
	utmPositionOut.northing = -1.0f * uePositionIn.Y + mapUtmOriginIn.Y;
	utmPositionOut.easting = uePositionIn.X + mapUtmOriginIn.X;
	utmPositionOut.northing = -1.0f * uePositionIn.Y + mapUtmOriginIn.Y;
	//_UTMPosition.zone = xx;
}

UTMData VDSensorGNSS::UeToUtmPosition(const FVector& uePositionIn, const FVector& mapUTMOriginIn)
{
	UTMData utmPosition_;
	UeToUtmPosition(uePositionIn, utmPosition_, mapUTMOriginIn);
	return utmPosition_;
}
