#include "VDRADAR/VDSensorATAR.h"

#include "DrawDebugHelpers.h"

typedef VDSensorBase Super;

VDSensorATAR::~VDSensorATAR()
{
	if (atarNoise)
	{
		delete atarNoise;
		atarNoise = nullptr;
	}
}

void VDSensorATAR::Initialize()
{
	Super::Initialize();
	if (HasRootComponent())
	{
		ignoreActors.Init(rootComponent->GetOwner(), 1);
	}

	numObj = 0;
	memset(&atarPacket_, 0, sizeof(atarPacket_));
	memset(&algObject_, 0, sizeof(algObject_));
	atarNoise = new VDNoise();
	farDistance = 10000.0f;
	nearDistance = 100.0f;
	hFov = 115.0f;
	vFov = 15.0f;
}

void VDSensorATAR::Release()
{
	Super::Release();
	if (atarNoise)
	{
		delete atarNoise;
		atarNoise = nullptr;
	}
}

void VDSensorATAR::Update(const float deltaTimeIn)
{
	Super::Update(deltaTimeIn);

	memset(&atarPacket_, 0, sizeof(atarPacket_));
	memset(&ownshipInfo_, 0, sizeof(ownshipInfo_));

	if (!IsJsbSimResourceLoad())
	{
		return;
	}

	// TODO: rootComponent & HasRootComponent() same functionality
	if (rootComponent == nullptr)
	{
		ErrorLog(TEXT("RootComponent is not defined in OwnShip Sensor."));
		return;
	}

	if (HasRootComponent() && HasWorld())
	{
		ownshipInfo_.heading_true_rad = float(*jsbSimYaw);
		ownshipInfo_.heading_degraded = false;
		ownshipInfo_.alt_pres_ft = 0;
		ownshipInfo_.lat_deg = float(*jsbSimLatitude);
		ownshipInfo_.lon_deg = float(*jsbSimLongitude);
		ownshipInfo_.vel_ew_kts = float(*jsbSimVelocityEastFps);
		ownshipInfo_.vel_ns_kts = float(*jsbSimVelocityNorthFps);
		ownshipInfo_.alt_hae_ft = float(*jsbSimAltitudeAslFt);
		ownshipInfo_.alt_rate_hae_fps = float(*jsbSimAltitudeRateFps);
		ownshipInfo_.nacp = 11;
		ownshipInfo_.nacv = 4;
		ownshipInfo_.vfom_m = 0;
		ownshipInfo_.alt_agl_ft = float(*jsbSimAltitudeAglFt);

		sensorOrigin_ = rootComponent->GetComponentTransform().GetLocation();

		FRotator sensorForwardVector_(0, 0, 0); // vertical, horizontal,0
		FRotator sensorUpVector_(90, 0, 0);		// vertical, horizontal,0

		FRotator fResultRot_ =
			UKismetMathLibrary::ComposeRotators(sensorForwardVector_, rootComponent->GetComponentTransform().Rotator());
		FRotator uResultRot_ =
			UKismetMathLibrary::ComposeRotators(sensorUpVector_, rootComponent->GetComponentTransform().Rotator());

		FVector fEnd_ = farDistance * UKismetMathLibrary::GetForwardVector(fResultRot_) + sensorOrigin_;
		FVector uEnd_ = farDistance * UKismetMathLibrary::GetForwardVector(uResultRot_) + sensorOrigin_;

		UGameplayStatics::GetAllActorsWithTag(world, FName(TEXT("CLASSIFICATION_MANNED")), outActors);

		FString debugMessage;

		debugMessage += FString::Printf(TEXT("/*************** ATAR ***************/ ")) + LINE_TERMINATOR;

		numObj = 0;

		if (&outActors != NULL)
		{
			for (AActor* overlappedActor : outActors)
			{
				overlappedActor->GetAttachedActors(attachedActors);

				if (attachedActors.IsEmpty()) // Static Object
				{
					overlappedActor->ActorGetDistanceToCollision(
						overlappedActor->GetActorLocation(), ECC_Visibility, closestPoint_);
					location_ = overlappedActor->GetActorLocation();
					rot_ = { overlappedActor->GetActorRotation().Roll, overlappedActor->GetActorRotation().Pitch,
						overlappedActor->GetActorRotation().Yaw };
					quat_ = overlappedActor->GetActorQuat();

					VDALG::CalculateVelocity(location_, quat_, numObj, algObject_, deltaTimeIn);
				}
				else // Dynamic Object
				{
					attachedActors[0]->ActorGetDistanceToCollision(location_, ECC_Visibility, closestPoint_);
					location_ = attachedActors[0]->GetActorLocation();
					rot_ = { attachedActors[0]->GetRootComponent()->GetComponentRotation().Roll,
						attachedActors[0]->GetRootComponent()->GetComponentRotation().Pitch,
						attachedActors[0]->GetRootComponent()->GetComponentRotation().Yaw };
					quat_ = attachedActors[0]->GetRootComponent()->GetComponentQuat();

					VDALG::CalculateVelocity(location_, quat_, numObj, algObject_, deltaTimeIn);
				}

				FVector forwardVector_ = { (fEnd_ - sensorOrigin_).X, (fEnd_ - sensorOrigin_).Y, 0 };

				FVector originToObject_ = { (location_ - sensorOrigin_).X, (location_ - sensorOrigin_).Y, 0 };
				FVector vOriginToObject_ = { (location_ - sensorOrigin_).X, (location_ - sensorOrigin_).Y,
					(location_ - sensorOrigin_).Z };

				distance = vOriginToObject_.Size() * CMTOMETER;

				if (FMath::Abs(distance) < farDistance)
				{
					FVector upVector_ = uEnd_ - sensorOrigin_;
					;

					hDot = FVector::DotProduct(forwardVector_.GetSafeNormal(), originToObject_.GetSafeNormal());
					hAngle = FMath::RadiansToDegrees(FMath::Acos(hDot));
					FVector cross =
						FVector::CrossProduct(forwardVector_.GetSafeNormal(), originToObject_.GetSafeNormal());

					vDot = FVector::DotProduct(upVector_.GetSafeNormal(), vOriginToObject_.GetSafeNormal());
					vAngle = 90 - FMath::RadiansToDegrees(FMath::Acos(vDot));
					FVector vCross_ =
						FVector::CrossProduct(upVector_.GetSafeNormal(), vOriginToObject_.GetSafeNormal());

					if (cross.Z < 0)
					{
						horizontalAngle = hAngle;
					}
					else if (cross.Z > 0)
					{
						// [TEMP]
						// TurnAngle = 360 - angle;
						horizontalAngle = -hAngle;
					}

					if (FMath::Abs(horizontalAngle) < (hFov / 2) && FMath::Abs(vAngle) < (vFov / 2))
					{
						if (*overlappedActor->Tags.GetData() == FName("CLASSIFICATION_MANNED"))
						{
							atarPacket_.ATARInfo[numObj].trackId =
								overlappedActor->GetUniqueID(); // TODO: remove dynamic cast
							atarPacket_.ATARInfo[numObj].track_status = 0;
							atarPacket_.ATARInfo[numObj].classification = CLASSIFICATION_MANNED;

							atarPacket_.ATARInfo[numObj].range_ft =
								vOriginToObject_.Size() * TOMETER * METERTOFEET + atarNoise->GaussianNoise(mean, stdev);
							atarPacket_.ATARInfo[numObj].azimuth_rad =
								-1.0 * horizontalAngle * DEGTORAD + atarNoise->GaussianNoise(mean, stdev);
							atarPacket_.ATARInfo[numObj].dgr_fps =
								algObject_.algInfo_[numObj].currentVelocity_.X * METERTOFEET
								- ownshipInfo_.vel_ns_kts * KNOTTOMPS * METERTOFEET
								+ atarNoise->GaussianNoise(mean, stdev);
							atarPacket_.ATARInfo[numObj].dxgr_fps =
								-1.0f * algObject_.algInfo_[numObj].currentVelocity_.Y * METERTOFEET
								- ownshipInfo_.vel_ew_kts * KNOTTOMPS * METERTOFEET
								+ atarNoise->GaussianNoise(mean, stdev);
							atarPacket_.ATARInfo[numObj].rel_z_ft =
								(location_.Z - sensorOrigin_.Z) * TOMETER * METERTOFEET
								+ atarNoise->GaussianNoise(mean, stdev);
							atarPacket_.ATARInfo[numObj].rel_dz_fps =
								algObject_.algInfo_[numObj].currentVelocity_.Z * METERTOFEET
								- ownshipInfo_.alt_rate_hae_fps + atarNoise->GaussianNoise(mean, stdev);

							debugMessage += FString::Printf(TEXT("num_obj : %d "), numObj) + LINE_TERMINATOR;
							debugMessage +=
								FString::Printf(TEXT("track_id (%f) : "), atarPacket_.ATARInfo[numObj].trackId)
								+ LINE_TERMINATOR;
							debugMessage +=
								FString::Printf(TEXT("range_ft (%f) : "), atarPacket_.ATARInfo[numObj].range_ft)
								+ LINE_TERMINATOR;
							debugMessage +=
								FString::Printf(TEXT("azimuth_rad (%f) : "), atarPacket_.ATARInfo[numObj].azimuth_rad)
								+ LINE_TERMINATOR;
							debugMessage +=
								FString::Printf(TEXT("dgr_fps (%f) : "), atarPacket_.ATARInfo[numObj].dgr_fps)
								+ LINE_TERMINATOR;
							debugMessage +=
								FString::Printf(TEXT("dxgr_fps (%f) : "), atarPacket_.ATARInfo[numObj].dxgr_fps)
								+ LINE_TERMINATOR;
							debugMessage +=
								FString::Printf(TEXT("rel_z_ft (%f) : "), atarPacket_.ATARInfo[numObj].rel_z_ft)
								+ LINE_TERMINATOR;
							debugMessage +=
								FString::Printf(TEXT("rel_dz_fps (%f) : "), atarPacket_.ATARInfo[numObj].rel_dz_fps)
								+ LINE_TERMINATOR;
						}
					}
				}
				numObj += 1;
			}
		}

		FVector2D textScale_ = FVector2D::UnitVector;
		GEngine->AddOnScreenDebugMessage(1, 0, FColor::Green, *debugMessage, false, textScale_);

		if (bDrawFrustum)
		{
			// DrawFrustum
			FRotator rotA_(vFov / 2, hFov / 2, 0);
			FRotator rotB_(vFov / 2, -hFov / 2, 0);
			FRotator rotC_(-vFov / 2, hFov / 2, 0);
			FRotator rotD_(-vFov / 2, -hFov / 2, 0);

			FRotator resultRotA_ =
				UKismetMathLibrary::ComposeRotators(rotA_, rootComponent->GetComponentTransform().Rotator());
			FRotator resultRotB_ =
				UKismetMathLibrary::ComposeRotators(rotB_, rootComponent->GetComponentTransform().Rotator());
			FRotator resultRotC_ =
				UKismetMathLibrary::ComposeRotators(rotC_, rootComponent->GetComponentTransform().Rotator());
			FRotator resultRotD_ =
				UKismetMathLibrary::ComposeRotators(rotD_, rootComponent->GetComponentTransform().Rotator());

			FVector endA_ = farDistance / cos(hFov / 2 * DEGTORAD) / cos(vFov / 2 * DEGTORAD)
					* UKismetMathLibrary::GetForwardVector(resultRotA_)
				+ sensorOrigin_;
			FVector endB_ = farDistance / cos(hFov / 2 * DEGTORAD) / cos(vFov / 2 * DEGTORAD)
					* UKismetMathLibrary::GetForwardVector(resultRotB_)
				+ sensorOrigin_;
			FVector endC_ = farDistance / cos(hFov / 2 * DEGTORAD) / cos(vFov / 2 * DEGTORAD)
					* UKismetMathLibrary::GetForwardVector(resultRotC_)
				+ sensorOrigin_;
			FVector endD_ = farDistance / cos(hFov / 2 * DEGTORAD) / cos(vFov / 2 * DEGTORAD)
					* UKismetMathLibrary::GetForwardVector(resultRotD_)
				+ sensorOrigin_;

			FVector nearA_ = nearDistance / cos(hFov / 2 * DEGTORAD) / cos(vFov / 2 * DEGTORAD)
					* UKismetMathLibrary::GetForwardVector(resultRotA_)
				+ sensorOrigin_;
			FVector nearB_ = nearDistance / cos(hFov / 2 * DEGTORAD) / cos(vFov / 2 * DEGTORAD)
					* UKismetMathLibrary::GetForwardVector(resultRotB_)
				+ sensorOrigin_;
			FVector nearC_ = nearDistance / cos(hFov / 2 * DEGTORAD) / cos(vFov / 2 * DEGTORAD)
					* UKismetMathLibrary::GetForwardVector(resultRotC_)
				+ sensorOrigin_;
			FVector nearD_ = nearDistance / cos(hFov / 2 * DEGTORAD) / cos(vFov / 2 * DEGTORAD)
					* UKismetMathLibrary::GetForwardVector(resultRotD_)
				+ sensorOrigin_;

			DrawDebugLine(world, nearA_, endA_, FColor::Purple, false, -1, 0, 10.0);
			DrawDebugLine(world, endA_, endB_, FColor::Purple, false, -1, 0, 10.0);
			DrawDebugLine(world, nearA_, nearB_, FColor::Purple, false, -1, 0, 10.0);

			DrawDebugLine(world, nearB_, endB_, FColor::Purple, false, -1, 0, 10.0);
			DrawDebugLine(world, endB_, endD_, FColor::Purple, false, -1, 0, 10.0);
			DrawDebugLine(world, nearB_, nearD_, FColor::Purple, false, -1, 0, 10.0);

			DrawDebugLine(world, nearC_, endC_, FColor::Purple, false, -1, 0, 10.0);
			DrawDebugLine(world, endD_, endC_, FColor::Purple, false, -1, 0, 10.0);
			DrawDebugLine(world, nearD_, nearC_, FColor::Purple, false, -1, 0, 10.0);

			DrawDebugLine(world, nearD_, endD_, FColor::Purple, false, -1, 0, 10.0);
			DrawDebugLine(world, endC_, endA_, FColor::Purple, false, -1, 0, 10.0);
			DrawDebugLine(world, nearC_, nearA_, FColor::Purple, false, -1, 0, 10.0);
		}
	}
}

void VDSensorATAR::SetDynamicsModel(const double* yawIn, const double* altitudeAslFtIn, const double* latIn,
	const double* longIn, const double* velNorthFpsIn, const double* velEastFpsIn, const double* altitudeRateFpsIn,
	const double* altitudeAglFtIn)
{
	jsbSimYaw = yawIn;
	jsbSimAltitudeAslFt = altitudeAslFtIn;
	jsbSimLatitude = latIn;
	jsbSimLongitude = longIn;
	jsbSimVelocityNorthFps = velNorthFpsIn;
	jsbSimVelocityEastFps = velEastFpsIn;
	jsbSimAltitudeRateFps = altitudeRateFpsIn;
	jsbSimAltitudeAglFt = altitudeAglFtIn;
}

bool VDSensorATAR::IsJsbSimResourceLoad()
{
	if ((jsbSimYaw == nullptr) || (jsbSimLatitude == nullptr) || (jsbSimLongitude == nullptr)
		|| (jsbSimVelocityEastFps == nullptr) || (jsbSimVelocityNorthFps == nullptr) || (jsbSimAltitudeAslFt == nullptr)
		|| (jsbSimAltitudeRateFps == nullptr) || (jsbSimAltitudeAglFt == nullptr))
	{
		ErrorLog(TEXT("Dynamics Model Resource is not defined in OwnShip Sensor."));
		return false;
	}
	return true;
}
