#include "VDRADAR/VDSensorADSB.h"

typedef VDSensorBase Super;

VDSensorADSB::~VDSensorADSB()
{
	if (mapUtmOrigin || adsbNoise)
	{
		delete mapUtmOrigin;
		mapUtmOrigin = nullptr;
		delete adsbNoise;
		adsbNoise = nullptr;
	}
}

void VDSensorADSB::Initialize()
{
	Super::Initialize();
	adsbNoise = new VDNoise();
	// mapUtmOrigin = nullptr;

	if (HasRootComponent())
	{
		ignoreActors.Init(rootComponent->GetOwner(), 1);
	}

	numObj = 0;
	memset(&adsbPacket_, 0, sizeof(adsbPacket_));
	memset(&algObject_, 0, sizeof(algObject_));

	mapUtmOrigin = new FVector(595429.088, 4135888.208, 0.0); // 임시로 Sanfrancisco 원점 사용. (0.0, 0.0, 0.0);
	SetEllipsoidModel(EllipsoidModel::WGS84);
}

void VDSensorADSB::Release()
{
	Super::Release();
	if (mapUtmOrigin || adsbNoise)
	{
		delete mapUtmOrigin;
		mapUtmOrigin = nullptr;
		delete adsbNoise;
		adsbNoise = nullptr;
	}
}

void VDSensorADSB::Update(const float deltaTimeIn)
{
	Super::Update(deltaTimeIn);

	memset(&adsbPacket_, 0, sizeof(adsbPacket_));
	memset(&ownshipInfo_, 0, sizeof(ownshipInfo_));

	if (!IsJsbSimResourceLoad())
	{
		ErrorLog(TEXT("Dynamics Model Resource is not defined in ADS-B."));
		return;
	}

	if (rootComponent == nullptr)
	{
		ErrorLog(TEXT("RootComponent is not defined in ADS-B."));
		return;
	}

	if (HasRootComponent() && HasWorld())
	{
		// *********** OwnShip Info ************* //
		ownshipInfo_.heading_true_rad = float(*jsbSimYaw);
		ownshipInfo_.heading_degraded = false;
		ownshipInfo_.alt_pres_ft = 0;
		ownshipInfo_.lat_deg = float(*jsbSimLatitude);
		ownshipInfo_.lon_deg = float(*jsbSimLongitude);
		ownshipInfo_.vel_ew_kts = float(*jsbSimVelocityEastFps);
		ownshipInfo_.vel_ns_kts = float(*jsbSimVelocityNorthFps);
		ownshipInfo_.alt_hae_ft = float(*jsbSimAltitudeAslFt);
		ownshipInfo_.alt_rate_hae_fps = float(*jsbSimAltitudeRateFps);
		ownshipInfo_.nacp = 11;
		ownshipInfo_.nacv = 4;
		ownshipInfo_.vfom_m = 0;
		ownshipInfo_.alt_agl_ft = float(*jsbSimAltitudeAglFt);

		sensorOrigin_ = rootComponent->GetComponentTransform().GetLocation();
		sensorForwardVector_ = rootComponent->GetForwardVector();

		FRotator fVector_(0, 0, 0); // vertical, horizontal,0
		// FRotator uVector(90, 0, 0); // vertical, horizontal,0

		FRotator fResultRot_ =
			UKismetMathLibrary::ComposeRotators(fVector_, rootComponent->GetComponentTransform().Rotator());
		// FRotator uResultRot = UKismetMathLibrary::ComposeRotators(uVector,
		// rootComponent->GetComponentTransform().Rotator());

		FVector fEnd_ = 10000.0f * UKismetMathLibrary::GetForwardVector(fResultRot_) + sensorOrigin_;
		// FVector uEnd = 10000.0f * UKismetMathLibrary::GetForwardVector(uResultRot) + SensorOrigin;

		UGameplayStatics::GetAllActorsWithTag(world, FName(TEXT("CLASSIFICATION_MANNED")), outActors);

		FString debugMessage;

		debugMessage += FString::Printf(TEXT("/*************** ADSB ***************/ ")) + LINE_TERMINATOR;

		numObj = 0;
		if (!outActors.IsEmpty())
		{
			for (AActor* overlappedActor : outActors)
			{
				overlappedActor->ActorGetDistanceToCollision(
					overlappedActor->GetActorLocation(), ECC_Visibility, closestPoint_);

				overlappedActor->GetAttachedActors(attachedActors);

				if (attachedActors.IsEmpty()) // Static Object -> 추후 삭제
				{
					location_ = overlappedActor->GetActorLocation();
					rot_ = { overlappedActor->GetActorRotation().Roll, overlappedActor->GetActorRotation().Pitch,
						overlappedActor->GetActorRotation().Yaw };
					quat_ = overlappedActor->GetActorQuat();

					VDALG::CalculateVelocity(location_, quat_, numObj, algObject_, deltaTimeIn);
				}
				else // Dynamic Object
				{
					location_ = attachedActors[0]->GetActorLocation();
					rot_ = { attachedActors[0]->GetActorRotation().Roll, attachedActors[0]->GetActorRotation().Pitch,
						attachedActors[0]->GetActorRotation().Yaw };
					quat_ = attachedActors[0]->GetRootComponent()->GetComponentQuat();

					VDALG::CalculateVelocity(location_, quat_, numObj, algObject_, deltaTimeIn);
				}

				distance = FVector::Dist(sensorOrigin_, closestPoint_) * CMTOMETER;

				WGSData* wgsPosition_ = new WGSData();

				WGSData llData_ = CalculateLongLat(mapUtmOrigin, location_ * TOMETER, wgsPosition_);

				FVector forwardVector_ = { (fEnd_ - sensorOrigin_).X, (fEnd_ - sensorOrigin_).Y, 0 };

				FVector originToObject_ = (location_ - sensorOrigin_);
				FVector hOriginToObject_ = { (location_ - sensorOrigin_).X, (location_ - sensorOrigin_).Y, 0 };

				hDot = FVector::DotProduct(forwardVector_.GetSafeNormal(), hOriginToObject_.GetSafeNormal());
				hAngle = FMath::RadiansToDegrees(FMath::Acos(hDot));
				FVector cross_ =
					FVector::CrossProduct(forwardVector_.GetSafeNormal(), hOriginToObject_.GetSafeNormal());

				if (cross_.Z < 0)
				{
					horizontalAngle = hAngle;
				}
				else if (cross_.Z > 0)
				{
					// TurnAngle = 360 - angle; //360���� ���ԵǸ� ����� ���� �����ϰ� �ȴ�.
					horizontalAngle = -hAngle;
				}

				if (*overlappedActor->Tags.GetData() == FName("CLASSIFICATION_MANNED"))
				{
					adsbPacket_.ADSBInfo[numObj].non_icao = 0;
					adsbPacket_.ADSBInfo[numObj].lat_deg = llData_.latitude + adsbNoise->GaussianNoise(mean, stdev);
					adsbPacket_.ADSBInfo[numObj].lon_deg = llData_.longitude + adsbNoise->GaussianNoise(mean, stdev);
					adsbPacket_.ADSBInfo[numObj].vel_ew_kts = algObject_.algInfo_[numObj].currentVelocity_.X * MPSTOKNOT
						+ adsbNoise->GaussianNoise(mean, stdev);
					adsbPacket_.ADSBInfo[numObj].vel_ns_kts =
						-1.0f * algObject_.algInfo_[numObj].currentVelocity_.Y * MPSTOKNOT
						+ adsbNoise->GaussianNoise(mean, stdev);
					adsbPacket_.ADSBInfo[numObj].baro_alt_ft = ownshipInfo_.alt_hae_ft
						+ (location_ - sensorOrigin_).Z * TOMETER * METERTOFEET
						+ adsbNoise->GaussianNoise(mean, stdev); // baro meter로 변경 필요 // TODO 아직 필요한지?
					// 어떤 값인 지 확인 필요. // TODO : 아직 화인 필요한지?
					adsbPacket_.ADSBInfo[numObj].is_alt_geo_hae = false;
					adsbPacket_.ADSBInfo[numObj].quant_ft = 25;
					adsbPacket_.ADSBInfo[numObj].nic = 0;
					adsbPacket_.ADSBInfo[numObj].externally_validated = 0;
					adsbPacket_.ADSBInfo[numObj].r_slant = originToObject_.Size() * CMTOMETER * METERTOFEET;
					adsbPacket_.ADSBInfo[numObj].Chi_rel = horizontalAngle * DEGTORAD;
					adsbPacket_.ADSBInfo[numObj].UniqueID = overlappedActor->GetUniqueID();

					debugMessage += FString::Printf(TEXT("num_obj : %d "), numObj) + LINE_TERMINATOR;

					debugMessage += FString::Printf(TEXT("non_icao (%d) : "), adsbPacket_.ADSBInfo[numObj].non_icao)
						+ LINE_TERMINATOR;
					debugMessage += FString::Printf(TEXT("lat_deg (%f) : "), adsbPacket_.ADSBInfo[numObj].lat_deg)
						+ LINE_TERMINATOR;
					debugMessage += FString::Printf(TEXT("lon_deg (%f) : "), adsbPacket_.ADSBInfo[numObj].lon_deg)
						+ LINE_TERMINATOR;
					debugMessage += FString::Printf(TEXT("vel_ew_kts (%f) : "), adsbPacket_.ADSBInfo[numObj].vel_ew_kts)
						+ LINE_TERMINATOR;
					debugMessage += FString::Printf(TEXT("vel_ns_kts (%f) : "), adsbPacket_.ADSBInfo[numObj].vel_ns_kts)
						+ LINE_TERMINATOR;
					debugMessage +=
						FString::Printf(TEXT("baro_alt_ft (%f) : "), adsbPacket_.ADSBInfo[numObj].baro_alt_ft)
						+ LINE_TERMINATOR;
					debugMessage +=
						FString::Printf(TEXT("is_alt_geo_hae (%f) : "), adsbPacket_.ADSBInfo[numObj].is_alt_geo_hae)
						+ LINE_TERMINATOR;
					debugMessage += FString::Printf(TEXT("quant_ft (%d) : "), adsbPacket_.ADSBInfo[numObj].quant_ft)
						+ LINE_TERMINATOR;
					debugMessage +=
						FString::Printf(TEXT("nic (%d) : "), adsbPacket_.ADSBInfo[numObj].nic) + LINE_TERMINATOR;
					debugMessage += FString::Printf(TEXT("externally_validated (%d) : "),
										adsbPacket_.ADSBInfo[numObj].externally_validated)
						+ LINE_TERMINATOR;
				}
				numObj += 1;
				delete wgsPosition_;
			}
		}
		FVector2D textScale_ = FVector2D::UnitVector;
		GEngine->AddOnScreenDebugMessage(1, 0, FColor::Green, *debugMessage, false, textScale_);
	}
}

void VDSensorADSB::SetDynamicsModel(const double* yawIn, const double* altitudeAslFtIn, const double* latIn,
	const double* longIn, const double* velNorthFpsIn, const double* velEastFpsIn, const double* altitudeRateFpsIn,
	const double* altitudeAglFtIn)
{
	jsbSimYaw = yawIn;
	jsbSimAltitudeAslFt = altitudeAslFtIn;
	jsbSimLatitude = latIn;
	jsbSimLongitude = longIn;
	jsbSimVelocityNorthFps = velNorthFpsIn;
	jsbSimVelocityEastFps = velEastFpsIn;
	jsbSimAltitudeRateFps = altitudeRateFpsIn;
	jsbSimAltitudeAglFt = altitudeAglFtIn;
}

WGSData VDSensorADSB::CalculateLongLat(const FVector* mapOriginIn, FVector targetPoseIn, WGSData* wgsPositionIn)
{
	UTMData utmPosition_ = VDGNSSConverter::UeToUtmPosition(targetPoseIn, *mapOriginIn);
	utmPosition_.zone = 10; // TODO: change the magic number
	VDGNSSConverter::UtmToWgsPosition(*wgsPositionIn, ellipsoidModelId, utmPosition_, targetPoseIn.Z);
	return *wgsPositionIn;
}

bool VDSensorADSB::IsJsbSimResourceLoad()
{
	if ((jsbSimYaw == nullptr) || (jsbSimLatitude == nullptr) || (jsbSimLongitude == nullptr)
		|| (jsbSimVelocityEastFps == nullptr) || (jsbSimVelocityNorthFps == nullptr) || (jsbSimAltitudeAslFt == nullptr)
		|| (jsbSimAltitudeRateFps == nullptr) || (jsbSimAltitudeAglFt == nullptr))
	{
		ErrorLog(TEXT("Dynamics Model Resource is not defined in ADS-B."));
		return false;
	}
	return true;
}
