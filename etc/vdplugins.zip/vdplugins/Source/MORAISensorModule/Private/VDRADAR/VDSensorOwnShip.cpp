#include "VDRADAR/VDSensorOwnShip.h"

typedef VDSensorBase Super;

VDSensorOwnShip::~VDSensorOwnShip() {}
void VDSensorOwnShip::Initialize()
{
	Super::Initialize();

	mapUtmOrigin = new FVector(595429.088, 4135888.208, 0.0); // [TEMP] Sanfrancisco 좌표계 사용 (0.0, 0.0, 0.0);;

	if (HasRootComponent())
	{
		ignoreActors.Init(rootComponent->GetOwner(), 1);
	}
	memset(&ownshipInfo_, 0, sizeof(OwnShipInfo));
	ownshipNoise = new VDNoise();

	numObj = 0;

	SetEllipsoidModel(EllipsoidModel::WGS84);
}

void VDSensorOwnShip::Release()
{
	Super::Release();
	if (mapUtmOrigin || ownshipNoise)
	{
		delete mapUtmOrigin;
		mapUtmOrigin = nullptr;
		delete ownshipNoise;
		ownshipNoise = nullptr;
	}
}

void VDSensorOwnShip::Update(const float deltaTimeIn)
{
	Super::Update(deltaTimeIn);

	memset(&ownshipInfo_, 0, sizeof(OwnShipInfo));

	if (!IsJsbSimResourceLoad())
	{
		return;
	}

	if (rootComponent == nullptr)
	{
		ErrorLog(TEXT("RootComponent is not defined in OwnShip Sensor."));
		return;
	}

	if (HasRootComponent() && HasWorld())
	{
		FVector sensorOrigin_ = rootComponent->GetRelativeLocation();

		WGSData* wgsPosition_ = new WGSData();

		WGSData llData_ = CalculateLongLat(mapUtmOrigin, sensorOrigin_ * TOMETER, wgsPosition_);
		geoidHeight = VDGeoGraphic::GetInstance().operator()(llData_.latitude, llData_.longitude);

		ownshipInfo_.Address = 10601652; // OwnShip은 해당 숫자로 고정 ICAO NUMBER로 고정
		ownshipInfo_.heading_true_rad = float(*jsbSimYaw) * DEGTORAD + ownshipNoise->GaussianNoise(mean, stdev);
		ownshipInfo_.heading_degraded = false;
		ownshipInfo_.alt_pres_ft = float(*jsbSimAltitudeAslFt) + ownshipNoise->GaussianNoise(mean, stdev);
		ownshipInfo_.lat_deg = llData_.latitude + ownshipNoise->GaussianNoise(mean, stdev);
		ownshipInfo_.lon_deg = llData_.longitude + ownshipNoise->GaussianNoise(mean, stdev);
		ownshipInfo_.vel_ew_kts = float(*jsbSimVelocityNorthFps) * 0.592484 + ownshipNoise->GaussianNoise(mean, stdev);
		ownshipInfo_.vel_ns_kts = float(*jsbSimVelocityEastFps) * 0.592484 + ownshipNoise->GaussianNoise(mean, stdev);
		ownshipInfo_.alt_hae_ft =
			float(*jsbSimAltitudeAglFt) + geoidHeight * METERTOFEET + ownshipNoise->GaussianNoise(mean, stdev);
		ownshipInfo_.alt_rate_hae_fps = float(*jsbSimAltitudeRateFps) + ownshipNoise->GaussianNoise(mean, stdev);
		ownshipInfo_.nacp = 10;
		ownshipInfo_.nacv = 3;
		ownshipInfo_.vfom_m = 8;
		ownshipInfo_.alt_agl_ft = float(*jsbSimAltitudeAglFt) + ownshipNoise->GaussianNoise(mean, stdev);

		if (bDebugOwnShip)
		{
			FString debugMessage;

			debugMessage += FString::Printf(TEXT("/*************** OwnShip ***************/ ")) + LINE_TERMINATOR;

			debugMessage += FString::Printf(TEXT("Address (%d) : "), ownshipInfo_.Address) + LINE_TERMINATOR;
			debugMessage +=
				FString::Printf(TEXT("heading_true_rad (%f) : "), ownshipInfo_.heading_true_rad) + LINE_TERMINATOR;
			debugMessage +=
				FString::Printf(TEXT("heading_degraded (%f) : "), ownshipInfo_.heading_degraded) + LINE_TERMINATOR;
			debugMessage += FString::Printf(TEXT("alt_pres_ft (%f) : "), ownshipInfo_.alt_pres_ft) + LINE_TERMINATOR;
			debugMessage += FString::Printf(TEXT("lat_deg (%f) : "), ownshipInfo_.lat_deg) + LINE_TERMINATOR;
			debugMessage += FString::Printf(TEXT("lon_deg (%f) : "), ownshipInfo_.lon_deg) + LINE_TERMINATOR;
			debugMessage += FString::Printf(TEXT("vel_ew_kts (%f) : "), ownshipInfo_.vel_ew_kts) + LINE_TERMINATOR;
			debugMessage += FString::Printf(TEXT("vel_ns_kts (%f) : "), ownshipInfo_.vel_ns_kts) + LINE_TERMINATOR;
			debugMessage += FString::Printf(TEXT("alt_hae_ft (%f) : "), ownshipInfo_.alt_hae_ft) + LINE_TERMINATOR;
			debugMessage +=
				FString::Printf(TEXT("alt_rate_hae_fps (%f) : "), ownshipInfo_.alt_rate_hae_fps) + LINE_TERMINATOR;
			debugMessage += FString::Printf(TEXT("nacp (%d) : "), ownshipInfo_.nacp) + LINE_TERMINATOR;
			debugMessage += FString::Printf(TEXT("nacv (%d) : "), ownshipInfo_.nacv) + LINE_TERMINATOR;
			debugMessage += FString::Printf(TEXT("vfom_m (%f) : "), ownshipInfo_.vfom_m) + LINE_TERMINATOR;
			debugMessage += FString::Printf(TEXT("alt_agl_ft (%f) : "), ownshipInfo_.alt_agl_ft) + LINE_TERMINATOR;

			FVector2D textScale_ = FVector2D::UnitVector;
			GEngine->AddOnScreenDebugMessage(1, 0, FColor::Magenta, *debugMessage, false, textScale_);
		}
		delete wgsPosition_;
	}
}

void VDSensorOwnShip::SetDynamicsModel(const double* yawIn, const double* altitudeAslFtIn, const double* latIn,
	const double* longIn, const double* velNorthFpsIn, const double* velEastFpsIn, const double* altitudeRateFpsIn,
	const double* altitudeAglFtIn)
{
	jsbSimYaw = yawIn;
	jsbSimAltitudeAslFt = altitudeAslFtIn;
	jsbSimLatitude = latIn;
	jsbSimLongitude = longIn;
	jsbSimVelocityNorthFps = velNorthFpsIn;
	jsbSimVelocityEastFps = velEastFpsIn;
	jsbSimAltitudeRateFps = altitudeRateFpsIn;
	jsbSimAltitudeAglFt = altitudeAglFtIn;
}

WGSData VDSensorOwnShip::CalculateLongLat(const FVector* mapOriginIn, FVector targetPoseIn, WGSData* wgsPositionIn)
{
	UTMData utmPosition_ = VDGNSSConverter::UeToUtmPosition(targetPoseIn, *mapOriginIn);
	utmPosition_.zone = 10;
	VDGNSSConverter::UtmToWgsPosition(*wgsPositionIn, ellipsoidModelId, utmPosition_, targetPoseIn.Z);
	return *wgsPositionIn;
}

double VDSensorOwnShip::CalculatePressure(double heightIn)
{
	return 1013.25 * pow((1 - (heightIn * FEETTOMETER / 44307.694)), 5.2553);
}

bool VDSensorOwnShip::IsJsbSimResourceLoad()
{
	if ((jsbSimYaw == nullptr) || (jsbSimLatitude == nullptr) || (jsbSimLongitude == nullptr)
		|| (jsbSimVelocityEastFps == nullptr) || (jsbSimVelocityNorthFps == nullptr) || (jsbSimAltitudeAslFt == nullptr)
		|| (jsbSimAltitudeRateFps == nullptr) || (jsbSimAltitudeAglFt == nullptr))
	{
		ErrorLog(TEXT("Dynamics Model Resource is not defined in OwnShip Sensor."));
		return false;
	}
	return true;
}
