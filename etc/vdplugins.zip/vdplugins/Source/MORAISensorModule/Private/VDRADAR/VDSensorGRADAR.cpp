// 해당 RADAR는 Ground Station을 의미함.
#include "VDRADAR/VDSensorGRADAR.h"

VDSensorGRADAR::~VDSensorGRADAR()
{
	if (mapUtmOrigin || groundRadarNoise)
	{
		delete mapUtmOrigin;
		mapUtmOrigin = nullptr;
		delete groundRadarNoise;
		groundRadarNoise = nullptr;
	}
}

void VDSensorGRADAR::Initialize()
{
	mapUtmOrigin = new FVector(595429.088, 4135888.208, 0.0); // 임시로 Sanfrancisco 원점 사용. (0.0, 0.0, 0.0);

	if (HasRootComponent())
	{
		ignoreActors.Init(rootComponent->GetOwner(), 1);
	}

	numObj = 0;
	memset(&groundRadarPacket_, 0, sizeof(groundRadarPacket_));
	memset(&algObject_, 0, sizeof(algObject_));

	SetEllipsoidModel(EllipsoidModel::WGS84);
	groundRadarNoise = new VDNoise();
}

void VDSensorGRADAR::Release()
{
	if (mapUtmOrigin || groundRadarNoise)
	{
		delete mapUtmOrigin;
		mapUtmOrigin = nullptr;
		delete groundRadarNoise;
		groundRadarNoise = nullptr;
	}
}

void VDSensorGRADAR::Update(const float deltaTimeIn)
{
	memset(&groundRadarPacket_, 0, sizeof(groundRadarPacket_));

	if (rootComponent == nullptr)
	{
		ErrorLog(TEXT("RootComponent is not defined in OwnShip Sensor."));
		return;
	}

	if (HasRootComponent() && HasWorld())
	{
		sensorOrigin_ = rootComponent->GetComponentTransform().GetLocation();

		UGameplayStatics::GetAllActorsWithTag(world, FName(TEXT("CLASSIFICATION_MANNED")), outActors);

		FString debugMessage;

		debugMessage += FString::Printf(TEXT("/*************** Ground RADAR ***************/ ")) + LINE_TERMINATOR;

		numObj = 0;

		if (!outActors.IsEmpty())
		{
			for (AActor* overlappedActor : outActors)
			{
				overlappedActor->ActorGetDistanceToCollision(
					overlappedActor->GetActorLocation(), ECC_Visibility, closestPoint_);

				overlappedActor->GetAttachedActors(attachedActors);

				if (attachedActors.IsEmpty()) // Static Object -> 추후 삭제
				{
					location_ = overlappedActor->GetActorLocation();
					rot_ = { overlappedActor->GetActorRotation().Roll, overlappedActor->GetActorRotation().Pitch,
						overlappedActor->GetActorRotation().Yaw };
					quat_ = overlappedActor->GetActorQuat();

					VDALG::CalculateVelocity(location_, quat_, numObj, algObject_, deltaTimeIn);
				}
				else // Dynamic Object
				{
					location_ = attachedActors[0]->GetActorLocation();
					rot_ = { attachedActors[0]->GetActorRotation().Roll, attachedActors[0]->GetActorRotation().Pitch,
						attachedActors[0]->GetActorRotation().Yaw };
					quat_ = attachedActors[0]->GetRootComponent()->GetComponentQuat();

					VDALG::CalculateVelocity(location_, quat_, numObj, algObject_, deltaTimeIn);
				}

				distance = FVector::Dist(sensorOrigin_, closestPoint_) * CMTOMETER;

				WGSData* wgsPosition_ = new WGSData();

				// 위도, 경도 계산
				WGSData llData_ = CalculateLongLat(mapUtmOrigin, location_ * TOMETER, wgsPosition_);
				FVector originToObject_ = { (location_ - sensorOrigin_).X, (location_ - sensorOrigin_).Y,
					(location_ - sensorOrigin_).Z };

				groundRadarPacket_.GroundRADARInfo[numObj].track_id = overlappedActor->GetUniqueID();
				groundRadarPacket_.GroundRADARInfo[numObj].track_status = 1;
				groundRadarPacket_.GroundRADARInfo[numObj].externally_validated = 1;

				if (*overlappedActor->Tags.GetData() == FName("CLASSIFICATION_MANNED"))
				{
					groundRadarPacket_.GroundRADARInfo[numObj].classification = CLASSIFICATION_MANNED;

					groundRadarPacket_.GroundRADARInfo[numObj].lat_deg =
						llData_.latitude + groundRadarNoise->GaussianNoise(0, 0);
					groundRadarPacket_.GroundRADARInfo[numObj].lon_deg =
						llData_.longitude + groundRadarNoise->GaussianNoise(0, 0);
					groundRadarPacket_.GroundRADARInfo[numObj].vel_ew_kts =
						algObject_.algInfo_[numObj].currentVelocity_.X * MPSTOKNOT
						+ groundRadarNoise->GaussianNoise(0, 0);
					groundRadarPacket_.GroundRADARInfo[numObj].vel_ns_kts =
						-1.0 * algObject_.algInfo_[numObj].currentVelocity_.Y * MPSTOKNOT
						+ groundRadarNoise->GaussianNoise(0, 0);
					groundRadarPacket_.GroundRADARInfo[numObj].baro_alt_ft =
						originToObject_.Z * TOMETER * METERTOFEET + groundRadarNoise->GaussianNoise(0, 0);
					groundRadarPacket_.GroundRADARInfo[numObj].baro_alt_rate_fps =
						algObject_.algInfo_[numObj].currentVelocity_.Z * METERTOFEET
						+ groundRadarNoise->GaussianNoise(0, 0);
					groundRadarPacket_.GroundRADARInfo[numObj].geo_hae_ft = originToObject_.Z * TOMETER * METERTOFEET
						+ groundRadarNoise->GaussianNoise(0, 0); // altitude 계산 방법 다시 고려 // TODO 유효?
					groundRadarPacket_.GroundRADARInfo[numObj].geo_hae_rate_fps =
						algObject_.algInfo_[numObj].currentVelocity_.Z * METERTOFEET
						+ groundRadarNoise->GaussianNoise(0, 0);

					debugMessage +=
						FString::Printf(TEXT("vel_ew_kts (%f) "), groundRadarPacket_.GroundRADARInfo[numObj].vel_ew_kts)
						+ LINE_TERMINATOR;
					debugMessage +=
						FString::Printf(TEXT("vel_ns_kts (%f) "), groundRadarPacket_.GroundRADARInfo[numObj].vel_ns_kts)
						+ LINE_TERMINATOR;
				}
				numObj += 1;
				delete wgsPosition_;
			}
		}

		FVector2D textScale_ = FVector2D::UnitVector;
		GEngine->AddOnScreenDebugMessage(1, 0, FColor::Orange, *debugMessage, false, textScale_);
	}
}

void VDSensorGRADAR::SetWorld(const UWorld* worldIn)
{
	if (world == worldIn)
	{
		return;
	}
	else if (world != nullptr)
	{
		world = worldIn;
	}
	else
	{
		world = worldIn;
	}
}

void VDSensorGRADAR::SetRootComponent(const USceneComponent* rootIn)
{
	if (rootComponent == rootIn)
	{
		return;
	}
	else if (rootComponent != nullptr)
	{
		rootComponent = rootIn;
	}
	else
	{
		rootComponent = rootIn;
	}
}

WGSData VDSensorGRADAR::CalculateLongLat(const FVector* mapOriginIn, FVector targetPoseIn, WGSData* wgsPositionIn)
{
	UTMData utmPosition_ = VDGNSSConverter::UeToUtmPosition(targetPoseIn, *mapOriginIn);
	utmPosition_.zone = 10;
	VDGNSSConverter::UtmToWgsPosition(*wgsPositionIn, ellipsoidModelId, utmPosition_, targetPoseIn.Z);
	return *wgsPositionIn;
}

void CalculateVelocity(FVector poseIn, FQuat rotIn, int currentNumIn, AlgObject& algOut, const float deltaTimeIn)
{
	// TODO remove unused function
}

bool VDSensorGRADAR::HasRootComponent()
{
	if (rootComponent == nullptr)
	{
		return false;
	}
	return true;
}

bool VDSensorGRADAR::HasWorld()
{
	if (world == nullptr)
	{
		return false;
	}
	return true;
}

void VDSensorGRADAR::InfoLog(const FString logIn)
{
	GEngine->AddOnScreenDebugMessage(-1, 1.0f, FColor::Cyan, logIn);
}

void VDSensorGRADAR::WarningLog(const FString logIn)
{
	GEngine->AddOnScreenDebugMessage(-1, 1.5f, FColor::Yellow, logIn);
}

void VDSensorGRADAR::ErrorLog(const FString logIn)
{
	GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Red, logIn);
}
