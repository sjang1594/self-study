#include "VDRADAR/VDSensorRADAR.h"
#include "GameFramework/Actor.h"
#include "DrawDebugHelpers.h"
#include "Components/LineBatchComponent.h"
#include "Physics/Experimental/PhysScene_Chaos.h"
#include "VDNoise/RandomEngine.h"
#include "VDSensorPose/SensorPose.h"
#include "Runtime/Core/Public/Async/ParallelFor.h"

typedef VDSensorBase Super;

VDSensorRADAR::~VDSensorRADAR()
{
	CleanUp();
}

void VDSensorRADAR::Initialize()
{
	Super::Initialize();
	if (HasRootComponent())
	{
		ignoreActors.Init(rootComponent->GetOwner(), 1);
	}
	numObj = 0;

	InitNoise();
	InitConfiguration();

	// Set the trace parameters
	traceParams = FCollisionQueryParams(FName(TEXT("Laser_Trace")), true, rootComponent->GetOwner());
	traceParams.bTraceComplex = true;
	traceParams.bReturnPhysicalMaterial = true;
}

void VDSensorRADAR::Release()
{
	Super::Release();
	CleanUp();
}

void VDSensorRADAR::InitNoise()
{
	radarNoise = new VDNoise();
}

void VDSensorRADAR::SetNoise(VDNoise* noiseIn)
{
	if (noiseIn == nullptr) return;
	radarNoise = noiseIn;
}

void VDSensorRADAR::SetParam(const float& hFovIn, const float& vFovIn, const float& minDistanceIn,
	const float& maxDistanceIn, const float& meanIn, const float& stdDevIn)
{
	if (radarParam == nullptr)
	{
		InitConfiguration();
		radarParam->SetConfig(hFovIn, vFovIn, minDistanceIn, maxDistanceIn);
		radarParam->SetNoise(meanIn, stdDevIn);
	}
	else
	{
		radarParam->SetConfig(hFovIn, vFovIn, minDistanceIn, maxDistanceIn);
		radarParam->SetNoise(meanIn, stdDevIn);
	}
}

void VDSensorRADAR::SetParam(const VDRadarParam& configIn)
{
	InitConfiguration();
	radarParam->SetConfig(configIn.hFov, configIn.vFov, configIn.minDistance, configIn.maxDistance);
	radarParam->SetNoise(configIn.mean, configIn.stdDev);
}

void VDSensorRADAR::SendLineTraces(SensorPose& poseIn, float deltaTimeIn)
{
	TRACE_CPUPROFILER_EVENT_SCOPE(VDSensorRADAR::SendLineTrace);
	const FTransform& transform = rootComponent->GetComponentTransform();
	const FVector transformXAxis = transform.GetUnitAxis(EAxis::X);
	const FVector transformYAxis = transform.GetUnitAxis(EAxis::Y);
	const FVector transformZAxis = transform.GetUnitAxis(EAxis::Z);

	constexpr float kToMeter = 1e-2;
	// TODO: Get FOV in short range on 3D space, not the 2D Plane
	const float maxRx = FMath::Tan(FMath::DegreesToRadians(radarParam->hFov * 0.5f)) * range;
	const float maxRy = FMath::Tan(FMath::DegreesToRadians(radarParam->vFov * 0.5f)) * range;

	// DropOut List
	const int numPoints = static_cast<int>(pointsPerSecond * deltaTimeIn);

	// Generate the parameters of the rays in deterministic way
	radarData_.clear();
	radarData_.resize(numPoints);
	for (int i = 0; i < radarData_.size(); i++)
	{
		float beamAngle = FMath::RandRange(-azimuthBeamWidth / 2.0f, azimuthBeamWidth / 2.0f);
		beamAngle = FMath::DegreesToRadians(beamAngle);
		radarData_[i].radius = randomEngine->GetUniformFloat();
		radarData_[i].angle = randomEngine->GetUniformFloatRange(0.0f, kPIf) + beamAngle;
		radarData_[i].bHit = false;
	}

	FCriticalSection mutex;
	{
		TRACE_CPUPROFILER_EVENT_SCOPE(ParallelFor);
		// Lambda function to shoot the rays in parallel //
		ParallelFor(numPoints, [&](int32 idx) {
			TRACE_CPUPROFILER_EVENT_SCOPE(ParallelForTask);
			FHitResult hitResult(ForceInit);
			const float radius = radarData_[idx].radius;
			const float angle = radarData_[idx].angle;

			float sin, cos;
			FMath::SinCos(&sin, &cos, angle);

			const FVector endLocation = transform.GetLocation()
				+ transform.Rotator().RotateVector({ range, maxRx * radius * cos, maxRy * radius * sin });

			const bool bHit = world->LineTraceSingleByChannel(
				hitResult, transform.GetLocation(), endLocation, ECC_Visibility, traceParams);

			const TWeakObjectPtr<AActor> actor = hitResult.GetActor();
			if (bHit && actor.Get())
			{
				radarData_[idx].bHit = true;
				// Fill this data later
				radarData_[idx].relativeVelocity = CalculateRelativeVelocity(hitResult, transform.GetLocation());
				radarData_[idx].azimuthAndElevation =
					FMath::GetAzimuthAndElevation((endLocation - transform.GetLocation()).GetSafeNormal() * range,
						transformXAxis, transformYAxis, transformZAxis);
				radarData_[idx].distance = hitResult.Distance * kToMeter;
				radarData_[idx].hitLocation = hitResult.ImpactPoint;
				FLinearColor color;
				GetMaterialColor(actor.Get(), color);
				radarData_[idx].intensity = color;
			}
		});
	}
}

void VDSensorRADAR::DrawRadarData()
{
	if (radarData_.empty()) return;
	if (HasRootComponent() && HasWorld())
	{
		auto drawData = [&](std::vector<RayData>& radarData) {
			if (!(world->PersistentLineBatcher)) return;

			for (auto& ray : radarData)
			{
				if (ray.bHit)
				{
					Eigen::Vector3f pointForDraw =
						ToVector3r(ray.hitLocation - rootComponent->GetComponentLocation(), 1, false);
					world->PersistentLineBatcher->DrawPoint(
						ToFVector(pointForDraw, 1.0f, false) + rootComponent->GetComponentLocation(), ray.intensity,
						3.0f, 0.0f, 0.1f);
				}
			}
		};

		drawData(radarData_);
	}
}

void VDSensorRADAR::CleanUp()
{
	// Param & Noise Module
	if (radarParam || radarNoise)
	{
		delete radarParam;
		radarParam = nullptr;
		delete radarNoise;
		radarNoise = nullptr;
	}

	// random
	if (randomEngine)
	{
		delete randomEngine;
		randomEngine = nullptr;
	}

	// Sensor Data Related
	if (radarPointCloud_.size() > 0)
	{
		radarPointCloud_.clear();
	}

	if (radarData_.size() > 0)
	{
		radarData_.clear();
	}

	if (ignoreActors.Num() > 0)
	{
		ignoreActors.Empty();
	}

	if (outActors.Num() > 0)
	{
		outActors.Empty();
	}
}

float VDSensorRADAR::CalculateRelativeVelocity(const FHitResult& hitResultIn, const FVector& sensorPoseIn) const
{
	constexpr float kToMeter = 1e-2;
	const TWeakObjectPtr<AActor> hitActor = hitResultIn.GetActor();
	const FVector targetVelocity_ = hitActor->GetVelocity();
	const FVector targetLocation_ = hitResultIn.ImpactPoint;
	const FVector direction_ = (targetLocation_ - rootComponent->GetComponentLocation()).GetSafeNormal();
	const FVector deltaVelocity_ = targetVelocity_ - currentVelocity_;
	const float resultVelocity = kToMeter * FVector::DotProduct(deltaVelocity_, direction_);
	return resultVelocity;
}

void VDSensorRADAR::CalculateCurrentVelocity(const float deltaTimeIn)
{
	const FVector radarLocation_ = rootComponent->GetComponentLocation();
	currentVelocity_ = (radarLocation_ - prevLocation_) / deltaTimeIn;
	prevLocation_ = radarLocation_;
}

void VDSensorRADAR::GetMaterialColor(const AActor* actorIn, FLinearColor& colorOut)
{
	UMaterialInterface* material = nullptr;
	if (const USkeletalMeshComponent* skeletalMeshComponent = actorIn->FindComponentByClass<USkeletalMeshComponent>())
	{
		material = skeletalMeshComponent->GetMaterial(0);
		if (material)
		{
			material->GetVectorParameterValue(FName("Color"), colorOut);
		}
	}
	else if (const UStaticMeshComponent* staticMeshComponent = actorIn->FindComponentByClass<UStaticMeshComponent>())
	{
		material = staticMeshComponent->GetMaterial(0);
		if (material)
		{
			material->GetVectorParameterValue(FName("Color"), colorOut);
		}
	}
}

void VDSensorRADAR::InitConfiguration()
{
	if (radarParam != nullptr)
	{
		radarParam = nullptr;
	}
	radarParam = new VDRadarParam();
	horizontalLaserCount = FMath::Floor(radarParam->hFov / radarParam->dtAzimuthAngle);
	verticalLaserCount = FMath::Floor(radarParam->vFov / radarParam->dtElevationAngle);
	totalLaserCount = horizontalLaserCount * verticalLaserCount;
}

void VDSensorRADAR::Update(const float deltaTimeIn)
{
	TRACE_CPUPROFILER_EVENT_SCOPE(VDSensorRADAR::Update);
	Super::Update(deltaTimeIn);
	if (randomEngine == nullptr) return;
	if (HasRootComponent() && HasWorld())
	{
		// Reset the Radar Data
		radarData_.clear();
		// Calculate the current velocity
		CalculateCurrentVelocity(deltaTimeIn);

		// Define the sensor pose
		SensorPose sensorPose_(rootComponent->GetComponentTransform().GetLocation(),
			rootComponent->GetComponentTransform().Rotator(), rootComponent->GetComponentTransform().GetRotation());

		// Send the Ray Casting
		SendLineTraces(sensorPose_, deltaTimeIn);

		if (bShowPointCloud)
		{
			DrawRadarData();
		}

		// const FVector sphereSpawnLocation_ = rootComponent->GetComponentTransform().GetLocation() / 100;
		//  const FVector sensorForwardVector_ = rootComponent->GetForwardVector();
		//
		//  UGameplayStatics::GetAllActorsWithTag(world, FName(TEXT("AirPlane")), outActors);

		/*****/
		// std::vector<float> OutputData;
		//  if (&outActors == nullptr)
		//  {
		//  	for (const AActor* overlappedActor : outActors)
		//  	{
		//  		FVector closestPoint_;
		//  		overlappedActor->ActorGetDistanceToCollision(
		//  			overlappedActor->GetActorLocation(), ECC_Visibility, closestPoint_);
		//
		//  		distance = FVector::Dist(sphereSpawnLocation_, closestPoint_);
		//
		//  		if (distance > radius)
		//  		{
		//  			continue;
		//  		}
		//  		dot = FVector::DotProduct(
		//  			sensorForwardVector_, (overlappedActor->GetActorLocation() -
		//  sphereSpawnLocation_).GetSafeNormal()); 		angle = FMath::RadiansToDegrees(FMath::Acos(dot)); const
		//  FVector cross_ = FVector::CrossProduct( 			sensorForwardVector_,
		//  (overlappedActor->GetActorLocation() - sphereSpawnLocation_).GetSafeNormal());
		//
		//  		if (cross_.Z > 0)
		//  		{
		//  			turnAngle = angle;
		//  		}
		//  		else if (cross_.Z < 0)
		//  		{
		//  			turnAngle = -angle;
		//  		}
		//
		//  		sensorData_.id = rootComponent->GetOwner()->GetUniqueID();
		//  		sensorData_.numDetections = static_cast<int>(outActors.Num()) - 1;
		//  		sensorData_.detections_[numObj].detectionId = overlappedActor->GetUniqueID();
		//  		;
		//  		sensorData_.detections_[numObj].positionX = overlappedActor->GetActorLocation().X * 0.01f;
		//  		sensorData_.detections_[numObj].positionY = overlappedActor->GetActorLocation().Y * 0.01f;
		//  		sensorData_.detections_[numObj].altitude = overlappedActor->GetActorLocation().Z * 0.01f;
		//  		sensorData_.detections_[numObj].azimuth = turnAngle;
		//  		sensorData_.detections_[numObj].distance = distance;
		//
		//  		if (numObj < static_cast<int>(outActors.Num()) - 1)
		//  		{
		//  			numObj += 1;
		//  		}
		//  	}
		//  }
	}
}
