﻿#include "VDNoise/RandomEngine.h"

#include <limits>

uint64 URandomEngine::GeneratedRandomId()
{
	static thread_local std::mt19937_64 engine((std::random_device())());
	std::uniform_int_distribution<uint64> distribution(
		std::numeric_limits<uint64>::lowest(), std::numeric_limits<uint64>::max());
	return distribution(engine);
}

uint32 URandomEngine::GenerateRandomSeed()
{
	std::random_device rd;
	std::uniform_int_distribution<int32> distribution(
		std::numeric_limits<int32>::lowest(), std::numeric_limits<int32>::max());
	return distribution(rd);
}

int32 URandomEngine::GeneratedSeed()
{
	return GetUniformIntRange(std::numeric_limits<int32>::lowest(), std::numeric_limits<int32>::max());
}

void URandomEngine::Seed(int32 seed)
{
	engine.seed(seed);
}

float URandomEngine::GetUniformFloat()
{
	return std::uniform_real_distribution<float>()(engine);
}

float URandomEngine::GetUniformFloatRange(float minIn, float maxIn)
{
	return std::uniform_real_distribution<float>(minIn, maxIn)(engine);
}

int32 URandomEngine::GetUniformIntRange(int32 minIn, int32 maxIn)
{
	return std::uniform_int_distribution<int32>(minIn, maxIn)(engine);
}

bool URandomEngine::GetUniformBool()
{
	return (GetUniformIntRange(0, 1) == 1);
}

bool URandomEngine::GetBernoulliDistribution(float pIn)
{
	return std::bernoulli_distribution(pIn)(engine);
}

int32 URandomEngine::GetBinomialDistribution(int32 tIn, float pIn)
{
	return std::binomial_distribution<int32>(tIn, pIn)(engine);
}

int32 URandomEngine::GetPoissonDistribution(float meanIn)
{
	return std::poisson_distribution<int32>(meanIn)(engine);
}

float URandomEngine::GetExponentialDistribution(float lambdaIn)
{
	return std::exponential_distribution<float>(lambdaIn)(engine);
}

float URandomEngine::GetNormalDistribution(float meanIn, float stdDevIn)
{
	return std::normal_distribution<float>(meanIn, stdDevIn)(engine);
}

bool URandomEngine::GetBoolWidthWeight(float weightIn)
{
	return (weightIn >= GetUniformFloat());
}

int32 URandomEngine::GetIntWidthWeight(const TArray<float>& weightsOut)
{
	return std::discrete_distribution<int32>(weightsOut.GetData(), weightsOut.GetData() + weightsOut.Num())(engine);
}
