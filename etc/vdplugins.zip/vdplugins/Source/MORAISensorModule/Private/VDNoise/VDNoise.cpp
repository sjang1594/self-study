#include "VDNoise/VDNoise.h"

double VDNoise::GaussianNoise(double value)
{
	return rd.next() * value + value;
}

double VDNoise::GaussianNoise(double meanIn, double stdDevIn)
{
	return rd.next() * stdDevIn + meanIn;
}

double VDNoise::BiasInstabilityGMNoise(
	double lastGmNoiseIn, double correlationTimeIn, double gmNoiseMeanIn, double gmStdDevIn, double dtIn)
{
	const double kHour2Sec = 1.0 / 3600.0;
	double gmGaussianNoise = GaussianNoise(gmNoiseMeanIn,
		kHour2Sec * gmStdDevIn
			* sqrt(1 - exp(-2 * (float) dtIn / (float) correlationTimeIn))); // TODO: dynamic cast to c++ style

	// return gmNoise
	return (1 - dtIn / correlationTimeIn) * lastGmNoiseIn + gmGaussianNoise;
}

double VDNoise::RandomWalkNoise(double lastRwNoiseIn, double rwNoiseMeanIn, double rwStdDevIn, double dtIn)
{
	const double kSqrtHour2sec = 0.000004629;
	double rwGaussianNoise = GaussianNoise(rwNoiseMeanIn, kSqrtHour2sec * rwStdDevIn * sqrt((float) dtIn));
	// return rw_noise
	return lastRwNoiseIn + rwGaussianNoise;
}

double VDNoise::WhiteNoise(double whiteNoiseMeanIn, double wnStdDevIn, double dtIn)
{
	const double kSqrtHour2sec3 = 1.0 / 60.0;
	// return WN_GaussianNoise
	return GaussianNoise(whiteNoiseMeanIn, kSqrtHour2sec3 * wnStdDevIn / sqrt((float) dtIn));
}
