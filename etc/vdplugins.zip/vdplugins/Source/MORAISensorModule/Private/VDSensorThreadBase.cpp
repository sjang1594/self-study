﻿#include "VDSensorThreadBase.h"

VDSensorThreadBase::VDSensorThreadBase(const FTimespan& threadSleepTimeIn, const TCHAR* threadNameIn) :
bStopThread(false),
threadSleepTime(threadSleepTimeIn)
{
	paused.AtomicSet(false);
	hasStopped.AtomicSet(true);

	thread = FRunnableThread::Create(
		this, threadNameIn, 0U, EThreadPriority::TPri_TimeCritical, FPlatformAffinity::GetPoolThreadMask());
	if (thread == nullptr)
	{
		UE_LOG(LogTemp, Error, TEXT("Thread has not been created in Constructor"))
	}
}

VDSensorThreadBase::~VDSensorThreadBase()
{
	if (thread != nullptr)
	{
		thread->Kill(true);
		delete thread;
		thread = nullptr;

		UE_LOG(LogTemp, Warning, TEXT("Thread has been deleted in Destructor"));
	}
}

bool VDSensorThreadBase::Init()
{
	return true;
}

uint32 VDSensorThreadBase::Run()
{
	hasStopped.AtomicSet(false);

	while (!bStopThread)
	{
		if (paused)
		{
			if (!isVerifiedSuspended)
			{
				isVerifiedSuspended.AtomicSet(true);
			}

			//! Ready to resume on a moments notice though!
			FPlatformProcess::Sleep(threadSleepTime.GetTotalSeconds());

			continue;
		}

		Process();
	}

	hasStopped.AtomicSet(true);
	return 0;
}

void VDSensorThreadBase::Stop()
{
	SetPaused(true);
	bStopThread = true;
	FRunnable::Stop();
}

void VDSensorThreadBase::SetPaused(bool MakePaused)
{
	paused.AtomicSet(MakePaused);
	if (!MakePaused)
	{
		isVerifiedSuspended.AtomicSet(false);
	}
}

bool VDSensorThreadBase::IsThreadPaused()
{
	return paused;
}

bool VDSensorThreadBase::IsThreadVerifiedSuspended()
{
	return isVerifiedSuspended;
}

bool VDSensorThreadBase::ThreadHasStopped()
{
	return hasStopped;
}
